# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Reset: random target HY object + fixed grasp pose + random distractor poses."""

from __future__ import annotations

from typing import TYPE_CHECKING

import torch

from isaaclab.assets import RigidObject

from cxy_project.envs.g1_pick_place.multi_hy_constants import THREE_HY_ASSET_NAMES

if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedEnv


def randomize_multi_hy_target_and_poses(
    env: ManagerBasedEnv,
    env_ids: torch.Tensor | None,
    target_pose_local: tuple[float, float, float] = (-0.2, 0.38, 0.9996),
    distractor_x_range: tuple[float, float] = (0.32, 0.75),
    distractor_y_range: tuple[float, float] = (0.51, 0.59),
    distractor_z: float = 0.9996,
    asset_names: tuple[str, str, str] = THREE_HY_ASSET_NAMES,
):
    """Sample ``target_idx ∈ {0,1,2}``, place that asset at ``target_pose_local`` (env origin + offset).

    The other two assets get independent uniform XY in the distractor ranges (same *z*).
    Writes ``env._cxy_target_object_idx`` and root pose / zero velocity into sim.
    """
    if env_ids is None:
        env_ids = torch.arange(env.scene.num_envs, device="cpu")
    else:
        env_ids = env_ids.cpu()

    if env_ids.numel() == 0:
        return

    dev = env.device
    n_env = env.scene.num_envs
    eids = env_ids.to(dev, dtype=torch.long)
    n = eids.shape[0]

    if not hasattr(env, "_cxy_target_object_idx") or env._cxy_target_object_idx.shape[0] != n_env:
        env._cxy_target_object_idx = torch.zeros(n_env, dtype=torch.long, device=dev)

    pick = torch.randint(0, 3, (n,), device=dev, dtype=torch.long)
    env._cxy_target_object_idx[eids] = pick

    origins = env.scene.env_origins[eids]
    tx, ty, tz = target_pose_local
    target_w = origins + torch.tensor([tx, ty, tz], device=dev, dtype=torch.float32).unsqueeze(0).expand(n, 3)

    x_min, x_max = distractor_x_range
    y_min, y_max = distractor_y_range
    d1x = torch.rand(n, device=dev) * (x_max - x_min) + x_min
    d1y = torch.rand(n, device=dev) * (y_max - y_min) + y_min
    d2x = torch.rand(n, device=dev) * (x_max - x_min) + x_min
    d2y = torch.rand(n, device=dev) * (y_max - y_min) + y_min
    d1_w = origins + torch.stack([d1x, d1y, torch.full((n,), distractor_z, device=dev)], dim=-1)
    d2_w = origins + torch.stack([d2x, d2y, torch.full((n,), distractor_z, device=dev)], dim=-1)

    quat = torch.tensor([1.0, 0.0, 0.0, 0.0], device=dev, dtype=torch.float32).unsqueeze(0).expand(n, 4)
    zero_vel = torch.zeros(n, 6, device=dev, dtype=torch.float32)

    assets: list[RigidObject] = [env.scene[name] for name in asset_names]

    for t in range(3):
        mask = pick == t
        if not mask.any():
            continue
        sub_eids = eids[mask]
        others = sorted(j for j in range(3) if j != t)
        o0, o1 = others[0], others[1]

        # Target object t
        pose_t = torch.cat([target_w[mask], quat[mask]], dim=-1)
        assets[t].write_root_pose_to_sim(pose_t, env_ids=sub_eids)
        assets[t].write_root_velocity_to_sim(zero_vel[mask], env_ids=sub_eids)

        # Distractor o0 -> D1
        pose_d1 = torch.cat([d1_w[mask], quat[mask]], dim=-1)
        assets[o0].write_root_pose_to_sim(pose_d1, env_ids=sub_eids)
        assets[o0].write_root_velocity_to_sim(zero_vel[mask], env_ids=sub_eids)

        # Distractor o1 -> D2
        pose_d2 = torch.cat([d2_w[mask], quat[mask]], dim=-1)
        assets[o1].write_root_pose_to_sim(pose_d2, env_ids=sub_eids)
        assets[o1].write_root_velocity_to_sim(zero_vel[mask], env_ids=sub_eids)

