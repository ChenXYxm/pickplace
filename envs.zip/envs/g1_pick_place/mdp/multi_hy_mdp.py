# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""MDP terms for three-HY scenes: all quantities use the per-env target object index."""

from __future__ import annotations

import os
import warnings
from typing import TYPE_CHECKING

import numpy as np
import torch

from isaaclab.assets import Articulation, RigidObject
from isaaclab.managers import SceneEntityCfg
from isaaclab.sensors import ContactSensor
from isaaclab.utils.math import quat_apply, subtract_frame_transforms

from cxy_project.envs.g1_pick_place.multi_hy_constants import (
    RIGHT_FINGER_LINK_NAMES,
    THREE_HY_ASSET_NAMES,
    THREE_HY_FOLDER_NAMES,
)

if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedRLEnv


_pointnet_hy_cpu: torch.Tensor | None = None
_pointnet_hy_path: str | None = None


def _target_idx(env: ManagerBasedRLEnv) -> torch.Tensor:
    if not hasattr(env, "_cxy_target_object_idx"):
        warnings.warn(
            "_cxy_target_object_idx missing; using 0 (hy_cleaner_bottle) until multi-hy reset runs.",
            stacklevel=2,
        )
        return torch.zeros(env.num_envs, dtype=torch.long, device=env.device)
    idx = env._cxy_target_object_idx
    if idx.device != env.device:
        idx = idx.to(env.device)
    return idx.clamp(0, 2)


def _gather_target_root_pos_w(env: ManagerBasedRLEnv) -> torch.Tensor:
    stacked = torch.stack(
        [env.scene[n].data.root_pos_w[:, :3] for n in THREE_HY_ASSET_NAMES],
        dim=1,
    )
    t = _target_idx(env)
    ar = torch.arange(env.num_envs, device=t.device)
    return stacked[ar, t, :]


def _gather_target_root_lin_vel_w(env: ManagerBasedRLEnv) -> torch.Tensor:
    stacked = torch.stack([env.scene[n].data.root_lin_vel_w for n in THREE_HY_ASSET_NAMES], dim=1)
    t = _target_idx(env)
    ar = torch.arange(env.num_envs, device=t.device)
    return stacked[ar, t, :]


def _gather_target_root_ang_vel_w(env: ManagerBasedRLEnv) -> torch.Tensor:
    stacked = torch.stack([env.scene[n].data.root_ang_vel_w for n in THREE_HY_ASSET_NAMES], dim=1)
    t = _target_idx(env)
    ar = torch.arange(env.num_envs, device=t.device)
    return stacked[ar, t, :]


def _gather_target_root_quat_w(env: ManagerBasedRLEnv) -> torch.Tensor:
    stacked = torch.stack([env.scene[n].data.root_quat_w for n in THREE_HY_ASSET_NAMES], dim=1)
    t = _target_idx(env)
    ar = torch.arange(env.num_envs, device=t.device)
    return stacked[ar, t, :]

def _ensure_target_z0_cache(env: ManagerBasedRLEnv) -> torch.Tensor:
    """Per-env cached target object initial height (world z) for this episode.

    This is intended to be set during reset (see ``multi_hy_reset_events``). If missing, we lazily initialize
    it to the current target z to avoid crashes and keep rewards well-defined.
    """
    if not hasattr(env, "_cxy_target_z0") or env._cxy_target_z0.shape[0] != env.num_envs:
        env._cxy_target_z0 = _gather_target_root_pos_w(env)[:, 2].detach().clone()
        return env._cxy_target_z0
    z0 = env._cxy_target_z0
    if z0.device != env.device:
        z0 = z0.to(env.device)
        env._cxy_target_z0 = z0
    return z0


def _hy_contact_fallback_cfg(env: ManagerBasedRLEnv) -> tuple[bool, float, bool, float | None]:
    """(use_net_fallback, spatial_gate_m, use_horizontal_net, finger_z_min_w) from env cfg."""
    cfg = getattr(env, "cfg", None)
    use = getattr(cfg, "cxy_contact_net_fallback", True) if cfg is not None else True
    gate_m = float(getattr(cfg, "cxy_contact_spatial_gate_m", 0.22)) if cfg is not None else 0.22
    use_h = getattr(cfg, "cxy_contact_net_use_horizontal", True) if cfg is not None else True
    z_min = getattr(cfg, "cxy_contact_net_finger_z_min_w", None) if cfg is not None else None
    if z_min is not None:
        z_min = float(z_min)
    return use, gate_m, use_h, z_min


def _finger_net_mags_five_links(
    env: ManagerBasedRLEnv,
    sensor_names_15: list[str],
    *,
    horizontal_only: bool,
) -> torch.Tensor:
    """Net contact force magnitude per finger; same for o0/o1/o2 on a link, so use first object slice.

    If ``horizontal_only``, uses ``||(Fx, Fy)||`` so **dominant vertical** contact (typical table support
    from above) contributes less than **shear / squeeze** (more typical of manipuland grasp). Pure
    object normal can still have a Z component; disable via ``cxy_contact_net_use_horizontal`` if needed.
    """
    assert len(sensor_names_15) >= 5
    mags: list[torch.Tensor] = []
    for i in range(5):
        sensor: ContactSensor = env.scene.sensors[sensor_names_15[i]]
        net = sensor.data.net_forces_w
        n = net.shape[0]
        net_flat = net.reshape(n, -1, 3)
        if horizontal_only:
            comp = net_flat[..., :2]
        else:
            comp = net_flat
        mag = torch.norm(comp, dim=-1).max(dim=-1).values
        mags.append(mag)
    return torch.stack(mags, dim=-1)


def _finger_spatial_gate_to_target(env: ManagerBasedRLEnv, spatial_gate_m: float) -> torch.Tensor:
    """Per-finger gate in ``[0, 1]``: 1 when finger link is within ``spatial_gate_m`` of target root (world)."""
    robot: Articulation = env.scene["robot"]
    target_w = _gather_target_root_pos_w(env)
    gates: list[torch.Tensor] = []
    for link in RIGHT_FINGER_LINK_NAMES:
        idx = robot.data.body_names.index(link)
        p = robot.data.body_pos_w[:, idx]
        d = torch.norm(p - target_w, dim=-1)
        gates.append((d < spatial_gate_m).float())
    return torch.stack(gates, dim=-1)


def _finger_height_gate_world_z(env: ManagerBasedRLEnv, z_min_w: float) -> torch.Tensor:
    """Per-finger gate: 1 when link world *z* >= ``z_min_w`` (reduces net fallback while fingertips stay on table)."""
    robot: Articulation = env.scene["robot"]
    gates: list[torch.Tensor] = []
    for link in RIGHT_FINGER_LINK_NAMES:
        idx = robot.data.body_names.index(link)
        z = robot.data.body_pos_w[:, idx, 2]
        gates.append((z >= z_min_w).float())
    return torch.stack(gates, dim=-1)


def _finger_mags_target(
    env: ManagerBasedRLEnv,
    sensor_names_15: list[str],
) -> torch.Tensor:
    """Per-env, per-finger magnitudes for **target** contact.

    Uses filtered ``force_matrix_w`` when non-zero (CPU / supported GPU filters). When GPU reports zero
    filtered forces (``GPU contact filter ... is not supported``), optionally blends in **net** forces on
    each finger gated by proximity to the **target** object root (``cxy_contact_net_fallback``). Net
    magnitude can use **horizontal** components only (``cxy_contact_net_use_horizontal``) to reduce
    spurious signal from **table** contact. Optionally ``cxy_contact_net_finger_z_min_w`` gates by minimum
    world *z* per finger link (stricter anti-table).
    """
    assert len(sensor_names_15) == 15
    mags: list[torch.Tensor] = []
    for name in sensor_names_15:
        sensor: ContactSensor = env.scene.sensors[name]
        fm = sensor.data.force_matrix_w
        # print("fm: ", fm)
        # print("name: ", name)
        n = fm.shape[0]
        f_flat = fm.reshape(n, -1, 3)
        mag = torch.norm(f_flat, dim=-1).max(dim=-1).values
        mags.append(mag)
    full = torch.stack(mags, dim=-1)
    full = full.view(env.num_envs, 3, 5)
    t = _target_idx(env)
    ar = torch.arange(env.num_envs, device=t.device)
    matrix = full[ar, t, :]

    use_fb, gate_m, use_h, z_min_w = _hy_contact_fallback_cfg(env)
    if not use_fb:
        return matrix

    gate = _finger_spatial_gate_to_target(env, gate_m)
    if z_min_w is not None:
        gate = gate * _finger_height_gate_world_z(env, z_min_w)

    net_part = _finger_net_mags_five_links(env, sensor_names_15, horizontal_only=use_h) * gate
    # Prefer filtered forces when available; else net×proximity (GPU workaround).
    return torch.where(matrix > 1e-5, matrix, net_part)


def finger_object_contact_binary_multi_hy(
    env: ManagerBasedRLEnv,
    sensor_names_15: list[str],
    force_threshold: float,
) -> torch.Tensor:
    mags = _finger_mags_target(env, sensor_names_15)
    return (mags.max(dim=-1).values > force_threshold).float()


def object_height_tanh_multi_hy(
    env: ManagerBasedRLEnv,
    target_height: float,
    std: float,
    min_reward_height: float | None = None,
) -> torch.Tensor:
    z = _gather_target_root_pos_w(env)[:, 2]
    err = torch.abs(z - target_height)
    out = 1.0 - torch.tanh(err / std)
    if min_reward_height is not None:
        out = out * (z >= min_reward_height).float()
    return out


def wrist_object_distance_shaping_multi_hy(
    env: ManagerBasedRLEnv,
    std: float,
    wrist_link_name: str,
) -> torch.Tensor:
    robot: Articulation = env.scene["robot"]
    idx = robot.data.body_names.index(wrist_link_name)
    wrist_w = robot.data.body_pos_w[:, idx]
    obj_w = _gather_target_root_pos_w(env)
    dist = torch.norm(obj_w - wrist_w, dim=-1)
    return 1.0 - torch.tanh(dist / std)


def wrist_target_height_diff_excess_multi_hy(
    env: ManagerBasedRLEnv,
    wrist_link_name: str,
    max_abs_diff_m: float = 0.1,
) -> torch.Tensor:
    """``max(0, |z_wrist - z_target_root| - max_abs_diff_m)`` in world frame (meters).

    Use with a **negative** :class:`~isaaclab.managers.RewardTermCfg` weight to penalize large vertical separation
    between the wrist link and the **target** HY object root.
    """
    robot: Articulation = env.scene["robot"]
    idx = robot.data.body_names.index(wrist_link_name)
    z_w = robot.data.body_pos_w[:, idx, 2]
    z_o = _gather_target_root_pos_w(env)[:, 2]
    diff = torch.abs(z_w - z_o)
    return torch.clamp(diff - max_abs_diff_m, min=0.0)


def multi_finger_contact_shaping_multi_hy(
    env: ManagerBasedRLEnv,
    sensor_names_15: list[str],
    force_threshold: float,
    tanh_scale: float = 2.0,
) -> torch.Tensor:
    mags = _finger_mags_target(env, sensor_names_15)
    count = (mags > force_threshold).float().sum(dim=-1)
    return torch.tanh(count / tanh_scale)


def thumb_opposition_contact_bonus_multi_hy(
    env: ManagerBasedRLEnv,
    thumb_sensor_name: str,
    other_digit_sensor_names: list[str],
    force_threshold: float,
    sensor_names_15: list[str],
) -> torch.Tensor:
    """Uses stem names to pick rows from the target-object 5-finger slice (thumb + 4 others)."""
    mags = _finger_mags_target(env, sensor_names_15)
    stems_order = ("contact_r_thumb4", "contact_r_index2", "contact_r_middle2", "contact_r_ring2", "contact_r_little2")
    thumb_i = stems_order.index(thumb_sensor_name) if thumb_sensor_name in stems_order else 0
    other_is = [stems_order.index(s) for s in other_digit_sensor_names if s in stems_order]
    thumb_ok = mags[:, thumb_i] > force_threshold
    others_ok = torch.stack([mags[:, i] > force_threshold for i in other_is], dim=-1).any(dim=-1)
    return (thumb_ok & others_ok).float()


def grasp_lift_object_velocity_penalty_multi_hy(
    env: ManagerBasedRLEnv,
    sensor_names_15: list[str],
    force_threshold: float,
    min_height: float,
    lin_vel_coeff: float = 1.0,
    ang_vel_coeff: float = 0.05,
) -> torch.Tensor:
    contact = finger_object_contact_binary_multi_hy(env, sensor_names_15, force_threshold)
    lifted = (_gather_target_root_pos_w(env)[:, 2] >= min_height).float()
    mask = contact * lifted
    lv = torch.sum(torch.square(_gather_target_root_lin_vel_w(env)), dim=-1)
    av = torch.sum(torch.square(_gather_target_root_ang_vel_w(env)), dim=-1)
    return mask * (lin_vel_coeff * lv + ang_vel_coeff * av)


def lift_height_with_finger_contact_multi_hy(
    env: ManagerBasedRLEnv,
    target_height: float,
    height_std: float,
    sensor_names_15: list[str],
    force_threshold: float,
    min_reward_height: float | None = None,
) -> torch.Tensor:
    h = object_height_tanh_multi_hy(env, target_height, height_std, min_reward_height=min_reward_height)
    c = finger_object_contact_binary_multi_hy(env, sensor_names_15, force_threshold)
    return h * c


def object_upward_velocity_when_finger_contact_multi_hy(
    env: ManagerBasedRLEnv,
    sensor_names_15: list[str],
    force_threshold: float,
    std: float,
) -> torch.Tensor:
    vz = _gather_target_root_lin_vel_w(env)[:, 2]
    c = finger_object_contact_binary_multi_hy(env, sensor_names_15, force_threshold)
    up = torch.clamp(vz, min=0.0)
    return c * torch.tanh(up / std)


def object_upward_velocity_target_only_multi_hy(
    env: ManagerBasedRLEnv,
    std: float,
) -> torch.Tensor:
    """Reward positive world *z* linear velocity of the **target** object (no contact sensors)."""
    vz = _gather_target_root_lin_vel_w(env)[:, 2]
    up = torch.clamp(vz, min=0.0)
    return torch.tanh(up / std)

def object_upward_velocity_until_height_delta_multi_hy(
    env: ManagerBasedRLEnv,
    delta_h: float,
    std: float,
) -> torch.Tensor:
    """Lift-phase reward: upward velocity until target height exceeds z0 + delta_h."""
    z = _gather_target_root_pos_w(env)[:, 2]
    z0 = _ensure_target_z0_cache(env)
    lift_phase = (z <= (z0 + float(delta_h))).float()
    return lift_phase * object_upward_velocity_target_only_multi_hy(env, std=std)


def object_vel_stability_after_height_delta_multi_hy(
    env: ManagerBasedRLEnv,
    delta_h: float,
    std: float,
) -> torch.Tensor:
    """Hold-phase reward: once target is above z0 + delta_h, reward small linear speed ||v|| with a Gaussian."""
    z = _gather_target_root_pos_w(env)[:, 2]
    z0 = _ensure_target_z0_cache(env)
    hold_phase = (z > (z0 + float(delta_h))).float()
    v_lin = _gather_target_root_lin_vel_w(env)
    speed = torch.norm(v_lin, dim=-1)
    s = torch.as_tensor(std, device=speed.device, dtype=speed.dtype).clamp_min(1e-6)
    stab = torch.exp(-torch.square(speed / s))
    return hold_phase * stab


def object_vz_stability_after_height_delta_multi_hy(
    env: ManagerBasedRLEnv,
    delta_h: float,
    std: float,
) -> torch.Tensor:
    """Alias for :func:`object_vel_stability_after_height_delta_multi_hy` (uses full linear speed, not vz-only)."""
    return object_vel_stability_after_height_delta_multi_hy(env, delta_h=delta_h, std=std)


def finger_geometry_near_target_vector_multi_hy(
    env: ManagerBasedRLEnv,
    std: float = 0.08,
) -> torch.Tensor:
    """Per-finger proxy in ``[0, 1]`` from distance (finger link to target root); no contact forces. Shape ``(N, 5)``."""
    robot: Articulation = env.scene["robot"]
    target_w = _gather_target_root_pos_w(env)
    cols: list[torch.Tensor] = []
    for link in RIGHT_FINGER_LINK_NAMES:
        idx = robot.data.body_names.index(link)
        p = robot.data.body_pos_w[:, idx]
        d = torch.norm(p - target_w, dim=-1)
        cols.append(1.0 - torch.tanh(d / std))
    return torch.stack(cols, dim=-1)


def multi_finger_geometry_shaping_multi_hy(
    env: ManagerBasedRLEnv,
    std: float,
    tanh_scale: float = 2.0,
) -> torch.Tensor:
    """Encourage **all** fingertips near target (no forces). ``tanh(sum(proxies) / tanh_scale)``."""
    v = finger_geometry_near_target_vector_multi_hy(env, std=std)
    count = v.sum(dim=-1)
    return torch.tanh(count / tanh_scale)


def multi_finger_geometry_shaping_after_height_delta_multi_hy(
    env: ManagerBasedRLEnv,
    delta_h: float,
    std: float,
    tanh_scale: float = 2.0,
) -> torch.Tensor:
    """Same shaping as :func:`multi_finger_geometry_shaping_multi_hy`, active only when target ``z > z0 + delta_h``.

    Proximity is finger link positions vs **target root** (object center proxy in world frame).
    """
    z = _gather_target_root_pos_w(env)[:, 2]
    z0 = _ensure_target_z0_cache(env)
    gate = (z > (z0 + float(delta_h))).float()
    v = finger_geometry_near_target_vector_multi_hy(env, std=std)
    count = v.sum(dim=-1)
    shaping = torch.tanh(count / tanh_scale)
    return gate * shaping


def lift_height_times_wrist_proximity_multi_hy(
    env: ManagerBasedRLEnv,
    target_height: float,
    height_std: float,
    wrist_std: float,
    wrist_link_name: str,
    min_reward_height: float | None = None,
) -> torch.Tensor:
    """Product of height shaping and wrist–object proximity (no contact): rewards **lift while hand is close**."""
    h = object_height_tanh_multi_hy(env, target_height, height_std, min_reward_height=min_reward_height)
    w = wrist_object_distance_shaping_multi_hy(env, wrist_std, wrist_link_name)
    return h * w


def object_position_in_robot_root_frame_multi_hy(
    env: ManagerBasedRLEnv,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
) -> torch.Tensor:
    robot: Articulation = env.scene[robot_cfg.name]
    object_pos_w = _gather_target_root_pos_w(env)
    object_pos_b, _ = subtract_frame_transforms(
        robot.data.root_pos_w, robot.data.root_quat_w, object_pos_w
    )
    return object_pos_b


def wrist_to_object_offset_in_robot_root_frame_multi_hy(
    env: ManagerBasedRLEnv,
    wrist_link_name: str,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
) -> torch.Tensor:
    robot: Articulation = env.scene[robot_cfg.name]
    idx = robot.data.body_names.index(wrist_link_name)
    wrist_w = robot.data.body_pos_w[:, idx]
    obj_w = _gather_target_root_pos_w(env)
    wrist_b, _ = subtract_frame_transforms(
        robot.data.root_pos_w, robot.data.root_quat_w, wrist_w
    )
    obj_b, _ = subtract_frame_transforms(robot.data.root_pos_w, robot.data.root_quat_w, obj_w)
    return obj_b - wrist_b


def object_root_velocity_w_multi_hy(env: ManagerBasedRLEnv) -> torch.Tensor:
    lin = _gather_target_root_lin_vel_w(env)
    ang = _gather_target_root_ang_vel_w(env)
    return torch.cat([lin, ang], dim=-1)


def finger_object_contact_vector_multi_hy(
    env: ManagerBasedRLEnv,
    sensor_names_15: list[str],
    force_threshold: float,
) -> torch.Tensor:
    mags = _finger_mags_target(env, sensor_names_15)
    print("mags: ", mags)
    return (mags > force_threshold).float()


def object_root_height_reached_multi_hy(
    env: ManagerBasedRLEnv,
    target_height: float,
) -> torch.Tensor:
    z = _gather_target_root_pos_w(env)[:, 2]
    return z >= target_height


def root_height_below_minimum_multi_hy(
    env: ManagerBasedRLEnv,
    minimum_height: float,
) -> torch.Tensor:
    z = _gather_target_root_pos_w(env)[:, 2]
    return z < minimum_height


def target_object_tilt_exceeds_threshold_multi_hy(
    env: ManagerBasedRLEnv,
    max_tilt_deg: float,
    upright_axis_body: tuple[float, float, float] = (0.0, 0.0, 1.0),
) -> torch.Tensor:
    """``True`` when the **target** HY body's upright axis tilts more than ``max_tilt_deg`` from world +Z.

    Maps body-frame ``upright_axis_body`` (unit direction when upright in USD) into world and compares
    to ``(0,0,1)``. Default assumes local +Z is the bottle's vertical axis.
    """
    quat = _gather_target_root_quat_w(env)
    ax = torch.tensor(upright_axis_body, device=quat.device, dtype=quat.dtype).view(1, 3)
    ax = ax / torch.clamp(torch.norm(ax, dim=-1, keepdim=True), min=1e-6)
    ax = ax.expand(quat.shape[0], 3)
    axis_w = quat_apply(quat, ax)
    cos = axis_w[:, 2].clamp(-1.0, 1.0)
    tilt_rad = torch.acos(cos)
    max_rad = torch.as_tensor(np.deg2rad(max_tilt_deg), device=quat.device, dtype=quat.dtype)
    z = _gather_target_root_pos_w(env)[:, 2]
    low = z < 1.02
    return (tilt_rad > max_rad) & low


def target_object_tilt_penalty_mask_multi_hy(
    env: ManagerBasedRLEnv,
    max_tilt_deg: float,
    upright_axis_body: tuple[float, float, float] = (0.0, 0.0, 1.0),
) -> torch.Tensor:
    """``1.0`` when the **target** HY body is tilted past ``max_tilt_deg`` (multiply by negative :class:`~isaaclab.managers.RewardTermCfg` weight for a penalty)."""
    return target_object_tilt_exceeds_threshold_multi_hy(
        env, max_tilt_deg, upright_axis_body=upright_axis_body
    ).float()


def object_pointnet_hy_feature(
    env: ManagerBasedRLEnv,
    feature_npz_path: str,
) -> torch.Tensor:
    """256-D PointNet++ row for the **target** HY object (``extract_hy_usd_pointnet2_features.py`` output)."""
    global _pointnet_hy_cpu, _pointnet_hy_path

    if not os.path.isfile(feature_npz_path):
        raise FileNotFoundError(
            f"PointNet HY features missing: {feature_npz_path}\n"
            "Run: ./isaaclab.sh -p cxy_project/scripts/extract_hy_usd_pointnet2_features.py --checkpoint <best_model.pth>"
        )

    if _pointnet_hy_cpu is None or _pointnet_hy_path != feature_npz_path:
        data = np.load(feature_npz_path, allow_pickle=True)
        if "features" not in data or "names" not in data:
            raise KeyError(f"{feature_npz_path} must contain 'features' and 'names'")
        feats = np.asarray(data["features"], dtype=np.float32)
        names = data["names"]
        if feats.ndim != 2 or feats.shape[1] != 256:
            raise RuntimeError(f"Expected features (K, 256), got {feats.shape}")
        folder_to_row: dict[str, int] = {}
        for i, n in enumerate(names.tolist() if hasattr(names, "tolist") else list(names)):
            folder_to_row[str(n)] = i
        for folder in THREE_HY_FOLDER_NAMES:
            if folder not in folder_to_row:
                raise KeyError(f"NPZ missing folder name {folder!r}; have {list(folder_to_row.keys())}")
        rows = np.stack([feats[folder_to_row[f]] for f in THREE_HY_FOLDER_NAMES], axis=0)
        _pointnet_hy_cpu = torch.from_numpy(np.ascontiguousarray(rows))
        _pointnet_hy_path = feature_npz_path

    table = _pointnet_hy_cpu.to(device=env.device, dtype=torch.float32)
    idx = _target_idx(env)
    return table[idx]

