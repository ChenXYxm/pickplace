# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""PPO training variant for three HY objects (cleaner bottle / spray bottle / whiteboard cleaner)."""

from __future__ import annotations

import os

import isaaclab.envs.mdp as base_mdp
from isaaclab.devices.device_base import DevicesCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import RewardTermCfg as RewTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.utils import configclass

from isaaclab_tasks.manager_based.manipulation.lift import mdp as lift_mdp

from cxy_project.envs.g1_pick_place import mdp
from cxy_project.envs.g1_pick_place.g1_pick_ppo_three_hy_scene_cfg import G1PickPPOThreeHySceneCfg
from cxy_project.envs.g1_pick_place.multi_hy_constants import (
    RIGHT_FINGER_SENSOR_STEMS,
    three_hy_contact_sensor_names_ordered,
)
from cxy_project.envs.g1_pick_place.pickplace_unitree_g1_inspire_hand_env_cfg import PickPlaceG1InspireFTPEnvCfg
from cxy_project.objects.ycb_objects_cfg import CXY_OBJECTS_DIR
from cxy_project.robots.g1_inspire_ftp_urdf_cfg import (
    G1_INSPIRE_FTP_HAND_JOINT_NAMES,
    G1_INSPIRE_FTP_PINOCCHIO_PACKAGE_DIR,
    G1_INSPIRE_FTP_URDF_PATH,
)


G1_RIGHT_ARM_JOINT_NAMES: tuple[str, ...] = (
    "right_shoulder_pitch_joint",
    "right_shoulder_roll_joint",
    "right_shoulder_yaw_joint",
    "right_elbow_joint",
    "right_wrist_yaw_joint",
    "right_wrist_roll_joint",
    "right_wrist_pitch_joint",
)
G1_RIGHT_ARM_AND_HAND_JOINT_NAMES_OBS: list[str] = list(G1_RIGHT_ARM_JOINT_NAMES) + list(G1_INSPIRE_FTP_HAND_JOINT_NAMES)

RIGHT_HAND_THUMB_CONTACT_STEM: str = RIGHT_FINGER_SENSOR_STEMS[0]
RIGHT_HAND_NON_THUMB_CONTACT_STEMS: tuple[str, ...] = RIGHT_FINGER_SENSOR_STEMS[1:]

THREE_HY_CONTACT_SENSOR_NAMES_15: list[str] = three_hy_contact_sensor_names_ordered()

HY_POINTNET2_FEATURE_NPZ: str = os.path.join(
    CXY_OBJECTS_DIR, "hy_objects", "hy_object_pointnet2_msg_normals_256.npz"
)

LIFT_REWARD_MIN_Z: float = 0.99


@configclass
class G1PickPPOHyEventCfg:
    """Reset: default scene state, then target + distractor poses for the three HY bodies."""

    reset_all = EventTerm(func=base_mdp.reset_scene_to_default, mode="reset")

    randomize_multi_hy_layout = EventTerm(
        func=mdp.randomize_multi_hy_target_and_poses,
        mode="reset",
        params={
            "target_pose_local": (-0.14, 0.38, 0.9996),
            "target_x_range": (-0.28, -0.10),
            "target_y_range": (0.33, 0.45),
            "distractor_x_range": (0.32, 0.75),
            "distractor_y_range": (0.51, 0.59),
            "distractor_z": 0.9996,
        },
    )


@configclass
class G1PickPPOHyObservationsCfg:
    """Vector policy observations; PointNet tail (256) is **last** (per-episode target object feature)."""

    @configclass
    class PolicyCfg(ObsGroup):
        joint_pos = ObsTerm(
            func=base_mdp.joint_pos_rel,
            params={
                "asset_cfg": SceneEntityCfg(
                    "robot",
                    joint_names=G1_RIGHT_ARM_AND_HAND_JOINT_NAMES_OBS,
                    preserve_order=True,
                )
            },
        )
        joint_vel = ObsTerm(
            func=base_mdp.joint_vel_rel,
            params={
                "asset_cfg": SceneEntityCfg(
                    "robot",
                    joint_names=G1_RIGHT_ARM_AND_HAND_JOINT_NAMES_OBS,
                    preserve_order=True,
                )
            },
        )
        object_position = ObsTerm(
            func=mdp.object_position_in_robot_root_frame_multi_hy,
            params={"robot_cfg": SceneEntityCfg("robot")},
        )
        right_wrist_object_offset = ObsTerm(
            func=mdp.wrist_to_object_offset_in_robot_root_frame_multi_hy,
            params={
                "wrist_link_name": "right_wrist_yaw_link",
                "robot_cfg": SceneEntityCfg("robot"),
            },
        )
        finger_contact_vector = ObsTerm(
            func=mdp.finger_object_contact_vector_multi_hy,
            params={
                "sensor_names_15": THREE_HY_CONTACT_SENSOR_NAMES_15,
                "force_threshold": 0.5,
            },
        )
        object_velocity_w = ObsTerm(func=mdp.object_root_velocity_w_multi_hy, params={})
        actions = ObsTerm(func=mdp.last_action)
        object_pointnet256 = ObsTerm(
            func=mdp.object_pointnet_hy_feature,
            params={"feature_npz_path": HY_POINTNET2_FEATURE_NPZ},
        )

        def __post_init__(self):
            self.enable_corruption = False
            self.concatenate_terms = True

    policy: PolicyCfg = PolicyCfg()


@configclass
class G1PickPPOHyRewardsCfg:
    """Lift target HY object only."""

    wrist_object_distance = RewTerm(
        func=mdp.wrist_object_distance_shaping_multi_hy,
        weight=0.02,
        params={
            "std": 0.18,
            "wrist_link_name": "right_wrist_yaw_link",
        },
    )
    multi_finger_contact = RewTerm(
        func=mdp.multi_finger_contact_shaping_multi_hy,
        weight=0.02,
        params={
            "sensor_names_15": THREE_HY_CONTACT_SENSOR_NAMES_15,
            "force_threshold": 0.5,
            "tanh_scale": 2.0,
        },
    )
    thumb_opposition_contact = RewTerm(
        func=mdp.thumb_opposition_contact_bonus_multi_hy,
        weight=0.35,
        params={
            "thumb_sensor_name": RIGHT_HAND_THUMB_CONTACT_STEM,
            "other_digit_sensor_names": list(RIGHT_HAND_NON_THUMB_CONTACT_STEMS),
            "force_threshold": 0.5,
            "sensor_names_15": THREE_HY_CONTACT_SENSOR_NAMES_15,
        },
    )

    lift_height = RewTerm(
        func=mdp.object_height_tanh_multi_hy,
        weight=0.9,
        params={"target_height": 1.25, "std": 0.15, "min_reward_height": LIFT_REWARD_MIN_Z},
    )
    finger_contact = RewTerm(
        func=mdp.finger_object_contact_binary_multi_hy,
        weight=0.12,
        params={"sensor_names_15": THREE_HY_CONTACT_SENSOR_NAMES_15, "force_threshold": 0.5},
    )
    lift_while_touching = RewTerm(
        func=mdp.lift_height_with_finger_contact_multi_hy,
        weight=6.0,
        params={
            "target_height": 1.25,
            "height_std": 0.15,
            "sensor_names_15": THREE_HY_CONTACT_SENSOR_NAMES_15,
            "force_threshold": 0.5,
            "min_reward_height": LIFT_REWARD_MIN_Z,
        },
    )
    object_upward_vel_contact = RewTerm(
        func=mdp.object_upward_velocity_when_finger_contact_multi_hy,
        weight=1.15,
        params={
            "sensor_names_15": THREE_HY_CONTACT_SENSOR_NAMES_15,
            "force_threshold": 0.5,
            "std": 0.085,
        },
    )
    # Half the magnitude of ``object_upward_vel_contact`` weight (1.15 / 2); same tilt criterion as ``object_tipped_over``.
    # object_tilt_fallen_penalty = RewTerm(
    #     func=mdp.target_object_tilt_penalty_mask_multi_hy,
    #     weight=-0.575,
    #     params={"max_tilt_deg": 65.0},
    # )
    wrist_target_height_diff_penalty = RewTerm(
        func=mdp.wrist_target_height_diff_excess_multi_hy,
        weight=-1.0,
        params={
            "wrist_link_name": "right_wrist_yaw_link",
            "max_abs_diff_m": 0.06,
        },
    )
    grasp_lift_object_velocity = RewTerm(
        func=mdp.grasp_lift_object_velocity_penalty_multi_hy,
        weight=-0.02,
        params={
            "sensor_names_15": THREE_HY_CONTACT_SENSOR_NAMES_15,
            "force_threshold": 0.5,
            "min_height": LIFT_REWARD_MIN_Z,
            "lin_vel_coeff": 1.0,
            "ang_vel_coeff": 0.05,
        },
    )
    action_rate = RewTerm(func=base_mdp.action_rate_l2, weight=-5e-3)


@configclass
class G1PickPPOTerminationsHyCfg:
    time_out = DoneTerm(func=mdp.time_out, time_out=True)

    object_dropping = DoneTerm(
        func=mdp.root_height_below_minimum_multi_hy,
        params={"minimum_height": 0.35},
    )

    # object_tipped_over = DoneTerm(
    #     func=mdp.target_object_tilt_exceeds_threshold_multi_hy,
    #     params={"max_tilt_deg": 80.0},
    #     time_out=False,
    # )

    object_reached_lift_height = DoneTerm(
        func=mdp.object_root_height_reached_multi_hy,
        params={"target_height": 1.25},
        time_out=False,
    )


@configclass
class G1InspirePickPPOHyEnvCfg(PickPlaceG1InspireFTPEnvCfg):
    """G1 Inspire + three HY objects + Pink IK + PPO."""

    # When GPU PhysX cannot populate filtered ``force_matrix_w``, use net forces × proximity to target (see ``multi_hy_mdp``).
    cxy_contact_net_fallback: bool = True
    cxy_contact_spatial_gate_m: float = 0.22
    # Net fallback: use ||(Fx,Fy)|| to down-weight dominant **vertical** contact (e.g. hand on table). Set False for full ||F||.
    cxy_contact_net_use_horizontal: bool = True
    # If set (world m), net fallback only counts when each finger link z >= this (stricter anti-table; None = off).
    # Objects on table are ~1.0 m world z; try 1.008–1.02 after checking a few frames if enabling.
    cxy_contact_net_finger_z_min_w: float | None = None

    scene: G1PickPPOThreeHySceneCfg = G1PickPPOThreeHySceneCfg(num_envs=1, env_spacing=2.5, replicate_physics=False)
    observations: G1PickPPOHyObservationsCfg = G1PickPPOHyObservationsCfg()
    rewards: G1PickPPOHyRewardsCfg = G1PickPPOHyRewardsCfg()
    terminations: G1PickPPOTerminationsHyCfg = G1PickPPOTerminationsHyCfg()
    events: G1PickPPOHyEventCfg = G1PickPPOHyEventCfg()

    def __post_init__(self):
        # Keep timing consistent with PickPlaceG1InspireFTPEnvCfg timing.
        self.decimation = 6
        self.episode_length_s = 10.0
        self.sim.dt = 1 / 120
        self.sim.render_interval = 2

        # Pink / Pinocchio: fixed project URDF + mesh package dir.
        self.actions.pink_ik_cfg.controller.urdf_path = G1_INSPIRE_FTP_URDF_PATH
        self.actions.pink_ik_cfg.controller.mesh_path = G1_INSPIRE_FTP_PINOCCHIO_PACKAGE_DIR

        # Headless / training: disable XR teleop device graph.
        self.teleop_devices = DevicesCfg(devices={})


@configclass
class G1PickPPOHyNoContactObservationsCfg:
    """Same as :class:`G1PickPPOHyObservationsCfg` but ``finger_contact_vector`` uses geometry, not forces."""

    @configclass
    class PolicyCfg(ObsGroup):
        joint_pos = ObsTerm(
            func=base_mdp.joint_pos_rel,
            params={
                "asset_cfg": SceneEntityCfg(
                    "robot",
                    joint_names=G1_RIGHT_ARM_AND_HAND_JOINT_NAMES_OBS,
                    preserve_order=True,
                )
            },
        )
        joint_vel = ObsTerm(
            func=base_mdp.joint_vel_rel,
            params={
                "asset_cfg": SceneEntityCfg(
                    "robot",
                    joint_names=G1_RIGHT_ARM_AND_HAND_JOINT_NAMES_OBS,
                    preserve_order=True,
                )
            },
        )
        object_position = ObsTerm(
            func=mdp.object_position_in_robot_root_frame_multi_hy,
            params={"robot_cfg": SceneEntityCfg("robot")},
        )
        right_wrist_object_offset = ObsTerm(
            func=mdp.wrist_to_object_offset_in_robot_root_frame_multi_hy,
            params={
                "wrist_link_name": "right_wrist_yaw_link",
                "robot_cfg": SceneEntityCfg("robot"),
            },
        )
        finger_contact_vector = ObsTerm(
            func=mdp.finger_geometry_near_target_vector_multi_hy,
            params={"std": 0.08},
        )
        object_velocity_w = ObsTerm(func=mdp.object_root_velocity_w_multi_hy, params={})
        actions = ObsTerm(func=mdp.last_action)
        object_pointnet256 = ObsTerm(
            func=mdp.object_pointnet_hy_feature,
            params={"feature_npz_path": HY_POINTNET2_FEATURE_NPZ},
        )

        def __post_init__(self):
            self.enable_corruption = False
            self.concatenate_terms = True

    policy: PolicyCfg = PolicyCfg()


@configclass
class G1PickPPOHyNoContactRewardsCfg:
    """Target HY object: wrist proximity + height + upward velocity; no :class:`~isaaclab.sensors.ContactSensor` forces."""

    # wrist_object_distance = RewTerm(
    #     func=mdp.wrist_object_distance_shaping_multi_hy,
    #     weight=0.35,
    #     params={
    #         "std": 0.18,
    #         "wrist_link_name": "right_wrist_yaw_link",
    #     },
    # )
    multi_finger_geometry = RewTerm(
        func=mdp.multi_finger_geometry_shaping_multi_hy,
        weight=0.15,
        params={"std": 0.08, "tanh_scale": 2.0},
    )
    lift_height = RewTerm(
        func=mdp.object_height_tanh_multi_hy,
        weight=1.6,
        params={"target_height": 1.25, "std": 0.15, "min_reward_height": LIFT_REWARD_MIN_Z},
    )
    lift_height_wrist_near = RewTerm(
        func=mdp.lift_height_times_wrist_proximity_multi_hy,
        weight=1.2,
        params={
            "target_height": 1.25,
            "height_std": 0.15,
            "wrist_std": 0.18,
            "wrist_link_name": "right_wrist_yaw_link",
            "min_reward_height": LIFT_REWARD_MIN_Z,
        },
    )
    object_upward_vel_lift_phase = RewTerm(
        func=mdp.object_upward_velocity_until_height_delta_multi_hy,
        weight=1.15,
        params={"delta_h": 0.2, "std": 0.085},
    )
    object_vel_stability_hold_phase = RewTerm(
        func=mdp.object_vel_stability_after_height_delta_multi_hy,
        weight=0.9,
        params={
            "delta_h": 0.2,
            # Gaussian on ||v_lin|| (world); slightly larger than old vz-only std
            "std": 0.08,
        },
    )
    multi_finger_geometry_lift_gate = RewTerm(
        func=mdp.multi_finger_geometry_shaping_after_height_delta_multi_hy,
        weight=0.35,
        params={
            "delta_h": 0.08,
            "std": 0.08,
            "tanh_scale": 2.0,
        },
    )
    # object_tilt_fallen_penalty = RewTerm(
    #     func=mdp.target_object_tilt_penalty_mask_multi_hy,
    #     weight=-0.575,
    #     params={"max_tilt_deg": 65.0},
    # )
    # wrist_target_height_diff_penalty = RewTerm(
    #     func=mdp.wrist_target_height_diff_excess_multi_hy,
    #     weight=-1.0,
    #     params={
    #         "wrist_link_name": "right_wrist_yaw_link",
    #         "max_abs_diff_m": 0.06,
    #     },
    # )
    action_rate = RewTerm(func=base_mdp.action_rate_l2, weight=-5e-5)


@configclass
class G1InspirePickPPOHyNoContactEnvCfg(PickPlaceG1InspireFTPEnvCfg):
    """HY multi-object task with geometry/kinematic rewards only (GPU-friendly; no contact-force terms)."""

    cxy_contact_net_fallback: bool = False
    cxy_contact_spatial_gate_m: float = 0.22
    cxy_contact_net_use_horizontal: bool = True
    cxy_contact_net_finger_z_min_w: float | None = None

    scene: G1PickPPOThreeHySceneCfg = G1PickPPOThreeHySceneCfg(num_envs=1, env_spacing=2.5, replicate_physics=False)
    observations: G1PickPPOHyNoContactObservationsCfg = G1PickPPOHyNoContactObservationsCfg()
    rewards: G1PickPPOHyNoContactRewardsCfg = G1PickPPOHyNoContactRewardsCfg()
    terminations: G1PickPPOTerminationsHyCfg = G1PickPPOTerminationsHyCfg()
    events: G1PickPPOHyEventCfg = G1PickPPOHyEventCfg()

    def __post_init__(self):
        self.decimation = 6
        self.episode_length_s = 4.0
        self.sim.dt = 1 / 120
        self.sim.render_interval = self.decimation

        self.actions.pink_ik_cfg.controller.urdf_path = G1_INSPIRE_FTP_URDF_PATH
        self.actions.pink_ik_cfg.controller.mesh_path = G1_INSPIRE_FTP_PINOCCHIO_PACKAGE_DIR

        self.teleop_devices = DevicesCfg(devices={})

