# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""PPO scene: three HY bodies + 15 contact sensors (5 fingers × 3 objects)."""

from __future__ import annotations

from isaaclab.sensors import ContactSensorCfg
from isaaclab.utils import configclass

from cxy_project.envs.g1_pick_place.multi_hy_constants import THREE_HY_FILTER_PRIM_REL_PATHS
from cxy_project.envs.g1_pick_place.three_hy_scene_cfg import ThreeHyObjectTableSceneCfg

_STEMS_LINKS: tuple[tuple[str, str], ...] = (
    ("contact_r_thumb4", "right_thumb_4"),
    ("contact_r_index2", "right_index_2"),
    ("contact_r_middle2", "right_middle_2"),
    ("contact_r_ring2", "right_ring_2"),
    ("contact_r_little2", "right_little_2"),
)


def _make_g1_pick_ppo_three_hy_scene_cfg_cls():
    annotations: dict[str, type] = {}
    fields: dict = {}
    for oi in range(3):
        filter_rel = THREE_HY_FILTER_PRIM_REL_PATHS[oi]
        for stem, link in _STEMS_LINKS:
            fname = f"{stem}_o{oi}"
            annotations[fname] = ContactSensorCfg
            fields[fname] = ContactSensorCfg(
                prim_path=f"{{ENV_REGEX_NS}}/Robot/{link}",
                update_period=0.0,
                history_length=1,
                debug_vis=False,
                filter_prim_paths_expr=[f"{{ENV_REGEX_NS}}/{filter_rel}"],
            )
    cls_dict = {
        "__module__": __name__,
        "__annotations__": annotations,
        **fields,
    }
    raw = type("G1PickPPOThreeHySceneCfg", (ThreeHyObjectTableSceneCfg,), cls_dict)
    return configclass(raw)


G1PickPPOThreeHySceneCfg = _make_g1_pick_ppo_three_hy_scene_cfg_cls()

