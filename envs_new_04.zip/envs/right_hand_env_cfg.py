import isaaclab.envs.mdp as mdp
import isaaclab.sim as sim_utils
from isaaclab.assets import ArticulationCfg,RigidObjectCfg,AssetBaseCfg
from isaaclab.envs import ManagerBasedRLEnvCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import RewardTermCfg as RewTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.sim import PhysxCfg, SimulationCfg
from isaaclab.sim.spawners.from_files.from_files_cfg import GroundPlaneCfg, UsdFileCfg
from isaaclab.sim.spawners.materials.physics_materials_cfg import RigidBodyMaterialCfg
from isaaclab.utils import configclass
from isaaclab.utils.assets import ISAAC_NUCLEUS_DIR
from isaaclab.sensors import ContactSensorCfg
from cxy_project.robots.g1_right_hand import RIGHT_HAND_CFG
from cxy_project.mdp.actions import FloatingRootPoseActionCfg

TABLE_BASE_Z = -0.3
TABLE_SURFACE_Z = 0.70
OBJECT_Z = 0.73
HAND_INIT_Z = 0.9
TARGET_LIFT_Z = 0.9

FINGER_JOINT_NAMES = [
    "R_index_proximal_joint",
    "R_index_intermediate_joint",
    "R_middle_proximal_joint",
    "R_middle_intermediate_joint",
    "R_ring_proximal_joint",
    "R_ring_intermediate_joint",
    "R_pinky_proximal_joint",
    "R_pinky_intermediate_joint",
    "R_thumb_proximal_yaw_joint",
    "R_thumb_proximal_pitch_joint",
    "R_thumb_intermediate_joint",
    "R_thumb_distal_joint"
]

FINGER_LINKS = [
    "R_thumb_.*",
    "R_pinky_.*",
    "R_middle_.*",
    "R_ring_.*",
    "R_index_.*"
]

@configclass
class G1RightHandGraspSceneCfg(InteractiveSceneCfg):
    robot: ArticulationCfg = RIGHT_HAND_CFG.replace(
        prim_path = "{ENV_REGEX_NS}/Robot",
    )

    robot.init_state = ArticulationCfg.InitialStateCfg(
        pos = (0.0,0.0,HAND_INIT_Z),
        rot = (0.7071,0.0,0.0,-0.7071),
        joint_pos={".*": 0.0},
        joint_vel={".*": 0.0},
    )

    table = AssetBaseCfg(
        prim_path="/World/envs/env_.*/Table",
        init_state=AssetBaseCfg.InitialStateCfg(
            pos = (0.0,0.0,TABLE_BASE_Z),
            rot = (1.0,0.0,0.0,0.0)
        ),
        spawn=UsdFileCfg(
            usd_path = f"{ISAAC_NUCLEUS_DIR}/Props/PackingTable/packing_table.usd",
            rigid_props = sim_utils.RigidBodyPropertiesCfg(kinematic_enabled=True)
        ),
    )
    ground = AssetBaseCfg(
        prim_path="/World/GroundPlane",
        spawn=GroundPlaneCfg(),
    )
    light = AssetBaseCfg(
        prim_path="/World/light",
        spawn=sim_utils.DomeLightCfg(color=(0.75,0.75,0.75), intensity=3000.0),
    )

@configclass
class ActionsCfg:
    hand_control = FloatingRootPoseActionCfg(
        asset_name = "robot",
        finger_joint_names = FINGER_JOINT_NAMES,
        max_pos_step = 0.02,
        max_rot_step = 0.05,
    )

@configclass
class ObservationsCfg:

    @configclass
    class PolicyCfg(ObsGroup):
        robot_root_pos = ObsTerm(
            func=mdp.root_pos_w,
            params={"asset_cfg": SceneEntityCfg("robot")},
        )
    
        actions = ObsTerm(
            func=mdp.last_action
        )

        def __post_init__(self):
            self.enable_corruption = False
            self.concatenate_terms = True
    policy: PolicyCfg=PolicyCfg()

@configclass
class TerminationsCfg:
    time_out = DoneTerm(func=mdp.time_out, time_out=True)



@configclass
class RightHandGraspEnvCfg(ManagerBasedRLEnvCfg):
    scene: G1RightHandGraspSceneCfg = G1RightHandGraspSceneCfg(
        num_envs = 1024,
        env_spacing= 2.5,
        replicate_physics=True
    )

    observations: ObservationsCfg = ObservationsCfg()
    actions: ActionsCfg = ActionsCfg()
    rewards=None
    terminations: TerminationsCfg = TerminationsCfg()
    events = None
    commands = None
    curriculum = None

    def __post_init__(self):
        self.decimation = 2
        self.episode_length_s = 10.0
        self.sim.dt = 1.0/120.0
        self.sim.render_interval = self.decimation
        self.sim.physx = PhysxCfg(bounce_threshold_velocity=0.2)
        self.sim.physics_material = RigidBodyMaterialCfg(
            static_friction=1.0,
            dynamic_friction=1.0
        )
