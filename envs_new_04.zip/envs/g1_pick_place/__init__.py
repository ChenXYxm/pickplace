"""Unitree G1 + Inspire hands pick-place environment (project copy).

Configs:

- ``pickplace_unitree_g1_inspire_hand_env_cfg.PickPlaceG1InspireFTPEnvCfg`` — teleop / debugging.
- ``pickplace_g1_inspire_ppo_env_cfg.G1InspirePickPPOEnvCfg`` — RSL-RL PPO (lift + finger-contact rewards).

Training script: ``cxy_project/scripts/train_g1_pick_place_ppo.py`` (gym id ``CXY-G1-Inspire-Pick-Lift-PPO-v0``).
"""
