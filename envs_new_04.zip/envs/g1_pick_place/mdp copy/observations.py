# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

from __future__ import annotations

import os
import warnings
from typing import TYPE_CHECKING

import numpy as np
import torch

from isaaclab.assets import Articulation, RigidObject
from isaaclab.managers import SceneEntityCfg
from isaaclab.utils.math import subtract_frame_transforms

from cxy_project.envs.g1_pick_place.mdp.rewards import _finger_sensor_force_max_mag_per_link

if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedRLEnv

# Module cache: (path, device_str) -> tensor (K, 256) on CPU for reload when path changes.
_pointnet_scale_features_cpu: torch.Tensor | None = None
_pointnet_scale_features_path: str | None = None


def object_obs(
    env: ManagerBasedRLEnv,
    left_eef_link_name: str,
    right_eef_link_name: str,
) -> torch.Tensor:
    """
    Object observations (in world frame):
        object pos,
        object quat,
        left_eef to object,
        right_eef_to object,
    """

    body_pos_w = env.scene["robot"].data.body_pos_w
    left_eef_idx = env.scene["robot"].data.body_names.index(left_eef_link_name)
    right_eef_idx = env.scene["robot"].data.body_names.index(right_eef_link_name)
    left_eef_pos = body_pos_w[:, left_eef_idx] - env.scene.env_origins
    right_eef_pos = body_pos_w[:, right_eef_idx] - env.scene.env_origins

    object_pos = env.scene["object"].data.root_pos_w - env.scene.env_origins
    object_quat = env.scene["object"].data.root_quat_w

    left_eef_to_object = object_pos - left_eef_pos
    right_eef_to_object = object_pos - right_eef_pos

    return torch.cat(
        (
            object_pos,
            object_quat,
            left_eef_to_object,
            right_eef_to_object,
        ),
        dim=1,
    )


def get_eef_pos(env: ManagerBasedRLEnv, link_name: str) -> torch.Tensor:
    body_pos_w = env.scene["robot"].data.body_pos_w
    left_eef_idx = env.scene["robot"].data.body_names.index(link_name)
    left_eef_pos = body_pos_w[:, left_eef_idx] - env.scene.env_origins

    return left_eef_pos


def get_eef_quat(env: ManagerBasedRLEnv, link_name: str) -> torch.Tensor:
    body_quat_w = env.scene["robot"].data.body_quat_w
    left_eef_idx = env.scene["robot"].data.body_names.index(link_name)
    left_eef_quat = body_quat_w[:, left_eef_idx]

    return left_eef_quat


def get_robot_joint_state(
    env: ManagerBasedRLEnv,
    joint_names: list[str],
) -> torch.Tensor:
    # hand_joint_names is a list of regex, use find_joints
    indexes, _ = env.scene["robot"].find_joints(joint_names)
    indexes = torch.tensor(indexes, dtype=torch.long)
    robot_joint_states = env.scene["robot"].data.joint_pos[:, indexes]

    return robot_joint_states


def get_all_robot_link_state(
    env: ManagerBasedRLEnv,
) -> torch.Tensor:
    body_pos_w = env.scene["robot"].data.body_link_state_w[:, :, :]
    all_robot_link_pos = body_pos_w

    return all_robot_link_pos


def finger_object_contact_vector(
    env: ManagerBasedRLEnv,
    sensor_names: list[str],
    force_threshold: float,
) -> torch.Tensor:
    """Per-finger binary contact vs ``force_threshold``, shape ``(num_envs, len(sensor_names))``."""
    mags = _finger_sensor_force_max_mag_per_link(env, sensor_names)
    return (mags > force_threshold).float()


def object_root_velocity_w(
    env: ManagerBasedRLEnv,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("object"),
) -> torch.Tensor:
    """Manipuland linear and angular velocity in world frame (6-D)."""
    obj: RigidObject = env.scene[asset_cfg.name]
    return torch.cat([obj.data.root_lin_vel_w, obj.data.root_ang_vel_w], dim=-1)


def wrist_to_object_offset_in_robot_root_frame(
    env: ManagerBasedRLEnv,
    wrist_link_name: str,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    object_cfg: SceneEntityCfg = SceneEntityCfg("object"),
) -> torch.Tensor:
    """Vector from wrist link to object COM, expressed in the robot root frame (3-D)."""
    robot: Articulation = env.scene[robot_cfg.name]
    obj: RigidObject = env.scene[object_cfg.name]
    idx = robot.data.body_names.index(wrist_link_name)
    wrist_w = robot.data.body_pos_w[:, idx]
    obj_w = obj.data.root_pos_w[:, :3]
    wrist_b, _ = subtract_frame_transforms(
        robot.data.root_pos_w, robot.data.root_quat_w, wrist_w
    )
    obj_b, _ = subtract_frame_transforms(robot.data.root_pos_w, robot.data.root_quat_w, obj_w)
    return obj_b - wrist_b


def object_scale_pointnet_feature(
    env: ManagerBasedRLEnv,
    feature_npz_path: str,
    expected_num_scales: int | None = None,
) -> torch.Tensor:
    """256-D PointNet++ row for the discrete scale chosen on last reset (see ``_cxy_object_scale_idx``).

    ``feature_npz_path`` should be the ``.npz`` from
    ``cxy_project/scripts/extract_rubiks_scaled_pointnet2_features.py``; row ``i`` matches
    ``YCB_RUBIKS_NONUNIFORM_SCALE_CHOICES[i]`` order.
    """
    global _pointnet_scale_features_cpu, _pointnet_scale_features_path

    if not os.path.isfile(feature_npz_path):
        raise FileNotFoundError(
            f"PointNet scale features missing: {feature_npz_path}\n"
            "Run: python cxy_project/scripts/extract_rubiks_scaled_pointnet2_features.py --checkpoint <best_model.pth>"
        )

    if _pointnet_scale_features_cpu is None or _pointnet_scale_features_path != feature_npz_path:
        data = np.load(feature_npz_path, allow_pickle=True)
        if "features" not in data:
            raise KeyError(f"{feature_npz_path} must contain array 'features'")
        feats = np.asarray(data["features"], dtype=np.float32)
        if feats.ndim != 2 or feats.shape[1] != 256:
            raise RuntimeError(
                f"Expected features with shape (K, 256), got {feats.shape} in {feature_npz_path}"
            )
        if expected_num_scales is not None and feats.shape[0] != expected_num_scales:
            raise RuntimeError(
                f"Expected features.shape[0]=={expected_num_scales}, got {feats.shape[0]} in {feature_npz_path}"
            )
        _pointnet_scale_features_cpu = torch.from_numpy(np.ascontiguousarray(feats))
        _pointnet_scale_features_path = feature_npz_path

    table = _pointnet_scale_features_cpu.to(device=env.device, dtype=torch.float32)

    if not hasattr(env, "_cxy_object_scale_idx"):
        warnings.warn(
            "env._cxy_object_scale_idx missing; using scale index 0 for PointNet obs until reset runs.",
            stacklevel=2,
        )
        idx = torch.zeros(env.num_envs, dtype=torch.long, device=env.device)
    else:
        idx = env._cxy_object_scale_idx
        if idx.device != env.device:
            idx = idx.to(env.device)
        if idx.shape[0] != env.num_envs:
            warnings.warn(
                "_cxy_object_scale_idx length mismatch; reusing clamped indices for PointNet obs.",
                stacklevel=2,
            )
    idx = idx.clamp(0, table.shape[0] - 1)
    return table[idx]
