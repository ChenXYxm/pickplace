# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""USD scale events for rigid objects (discrete choices, usable on ``mode=\"reset\"``)."""

from __future__ import annotations

from typing import TYPE_CHECKING, Sequence

import torch

import isaaclab.sim as sim_utils
from isaaclab.assets import Articulation, RigidObject
from isaaclab.managers import SceneEntityCfg
from isaaclab.sim.utils.stage import get_current_stage

if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedEnv


def randomize_rigid_object_scale_discrete(
    env: ManagerBasedEnv,
    env_ids: torch.Tensor | None,
    asset_cfg: SceneEntityCfg,
    scale_choices: Sequence[tuple[float, float, float]],
    relative_child_path: str | None = None,
):
    """Set uniform ``xformOp:scale`` (via :func:`~isaaclab.sim.utils.transforms.standardize_xform_ops`) from a **discrete** list.

    By default the target prim is the **rigid-body root** from :attr:`~isaaclab.assets.rigid_object.RigidObject.root_physx_view`
    (e.g. ``.../Object/<mesh_name>`` for mesh-converted YCB assets), not only ``.../Object``, so viewport and PhysX stay aligned.

    Mirrors :func:`isaaclab.envs.mdp.events.randomize_rigid_body_scale` USD writes, but:

    * picks one of ``scale_choices`` per environment index instead of uniform ranges, and
    * **does not** require the simulator to be stopped (intended for ``EventTermCfg(mode=\"reset\")``).
    * writes the sampled index per env to ``env._cxy_object_scale_idx`` (``long``, shape ``(num_envs,)``,
      on ``env.device``) for observation terms such as ``object_scale_pointnet_feature`` in ``observations.py``.

    .. caution::
        Isaac Lab documents that changing USD scale while sim is active can be fragile. If you see
        unstable contacts or parsing glitches, try ``replicate_physics=False`` on the scene or
        restrict this to pre-startup modes.

    Args:
        env: Environment instance.
        env_ids: Indices to update; ``None`` means all envs.
        asset_cfg: Rigid object (not articulation) to scale.
        scale_choices: Non-empty sequence of ``(sx, sy, sz)`` triples in **simulation units** (absolute scale).
        relative_child_path: If set, scale ``{asset_cfg.prim_path}`` + this path (regex order); otherwise use PhysX rigid-body paths.
    """
    if not scale_choices:
        raise ValueError("scale_choices must be non-empty.")

    asset: RigidObject = env.scene[asset_cfg.name]
    if isinstance(asset, Articulation):
        raise ValueError("randomize_rigid_object_scale_discrete supports RigidObject only.")

    if env_ids is None:
        env_ids = torch.arange(env.scene.num_envs, device="cpu")
    else:
        env_ids = env_ids.cpu()

    if env_ids.numel() == 0:
        return

    # Regex discovery order is not guaranteed to match env indices (e.g. env_10 before env_2). For the default
    # scale target we use the rigid-body prim paths from PhysX — same order as env indices.
    prim_paths = sim_utils.find_matching_prim_paths(asset.cfg.prim_path)
    physx_prim_paths: list[str] | None = None
    pp = asset.root_physx_view.prim_paths
    if pp is not None and len(pp) >= int(env_ids.max().item()) + 1:
        physx_prim_paths = [str(p) for p in pp]

    choices_t = torch.tensor(list(scale_choices), dtype=torch.float32, device="cpu")
    k = choices_t.shape[0]
    pick = torch.randint(0, k, (env_ids.shape[0],), device="cpu")
    scales = choices_t[pick]

    dev = env.device
    n_env = env.scene.num_envs
    if not hasattr(env, "_cxy_object_scale_idx") or env._cxy_object_scale_idx.shape[0] != n_env:
        env._cxy_object_scale_idx = torch.zeros(n_env, dtype=torch.long, device=dev)
    eids = env_ids.to(dev, dtype=torch.long)
    env._cxy_object_scale_idx[eids] = pick.to(dev)

    if relative_child_path is None:
        relative_child_path = ""
    elif not relative_child_path.startswith("/"):
        relative_child_path = "/" + relative_child_path

    scales_list = scales.tolist()

    # Author scale on the **composed stage** with the same xform stack as :func:`isaaclab.sim.utils.prims.create_prim`
    # (translate / orient / scale). Scaling the scene ``Object`` Xform alone can fail to match the rigid-body
    # instance used by PhysX when the body lives on a child prim (e.g. mesh converter layout); use PhysX prim
    # paths when no explicit relative_child_path is given.
    stage = get_current_stage()
    for i, eid in enumerate(env_ids.tolist()):
        if relative_child_path:
            prim_path_str = prim_paths[eid] + relative_child_path
        elif physx_prim_paths is not None:
            prim_path_str = physx_prim_paths[eid]
        else:
            prim_path_str = prim_paths[eid]
        prim = stage.GetPrimAtPath(prim_path_str)
        if not prim.IsValid():
            continue
        sx, sy, sz = scales_list[i]
        sim_utils.standardize_xform_ops(prim, scale=(float(sx), float(sy), float(sz)))

    # Propagate stage edits to rendering / physics subscribers (Kit update cycle).
    sim_utils.update_stage()
