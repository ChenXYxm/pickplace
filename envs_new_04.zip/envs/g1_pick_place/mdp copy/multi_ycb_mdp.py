# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""MDP terms for three-YCB scenes: all quantities use the per-env target object index."""

from __future__ import annotations

import os
import warnings
from typing import TYPE_CHECKING

import numpy as np
import torch

from isaaclab.assets import Articulation, RigidObject
from isaaclab.managers import SceneEntityCfg
from isaaclab.sensors import ContactSensor
from isaaclab.utils.math import subtract_frame_transforms

from cxy_project.envs.g1_pick_place.multi_ycb_constants import THREE_YCB_ASSET_NAMES, THREE_YCB_FOLDER_NAMES

if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedRLEnv

_pointnet_ycb_cpu: torch.Tensor | None = None
_pointnet_ycb_path: str | None = None


def _target_idx(env: ManagerBasedRLEnv) -> torch.Tensor:
    if not hasattr(env, "_cxy_target_object_idx"):
        warnings.warn(
            "_cxy_target_object_idx missing; using 0 (rubiks) until multi-ycb reset runs.",
            stacklevel=2,
        )
        return torch.zeros(env.num_envs, dtype=torch.long, device=env.device)
    idx = env._cxy_target_object_idx
    if idx.device != env.device:
        idx = idx.to(env.device)
    return idx.clamp(0, 2)


def _gather_target_root_pos_w(env: ManagerBasedRLEnv) -> torch.Tensor:
    stacked = torch.stack(
        [env.scene[n].data.root_pos_w[:, :3] for n in THREE_YCB_ASSET_NAMES],
        dim=1,
    )
    t = _target_idx(env)
    ar = torch.arange(env.num_envs, device=t.device)
    return stacked[ar, t, :]


def _gather_target_root_lin_vel_w(env: ManagerBasedRLEnv) -> torch.Tensor:
    stacked = torch.stack([env.scene[n].data.root_lin_vel_w for n in THREE_YCB_ASSET_NAMES], dim=1)
    t = _target_idx(env)
    ar = torch.arange(env.num_envs, device=t.device)
    return stacked[ar, t, :]


def _gather_target_root_ang_vel_w(env: ManagerBasedRLEnv) -> torch.Tensor:
    stacked = torch.stack([env.scene[n].data.root_ang_vel_w for n in THREE_YCB_ASSET_NAMES], dim=1)
    t = _target_idx(env)
    ar = torch.arange(env.num_envs, device=t.device)
    return stacked[ar, t, :]


def _finger_mags_target(
    env: ManagerBasedRLEnv,
    sensor_names_15: list[str],
) -> torch.Tensor:
    """Per-env, per-finger max force magnitudes for the **target** object only. Shape ``(N, 5)``."""
    assert len(sensor_names_15) == 15
    mags: list[torch.Tensor] = []
    for name in sensor_names_15:
        sensor: ContactSensor = env.scene.sensors[name]
        fm = sensor.data.force_matrix_w
        n = fm.shape[0]
        f_flat = fm.reshape(n, -1, 3)
        mag = torch.norm(f_flat, dim=-1).max(dim=-1).values
        mags.append(mag)
    full = torch.stack(mags, dim=-1)
    full = full.view(env.num_envs, 3, 5)
    t = _target_idx(env)
    ar = torch.arange(env.num_envs, device=t.device)
    return full[ar, t, :]


def finger_object_contact_binary_multi_ycb(
    env: ManagerBasedRLEnv,
    sensor_names_15: list[str],
    force_threshold: float,
) -> torch.Tensor:
    mags = _finger_mags_target(env, sensor_names_15)
    return (mags.max(dim=-1).values > force_threshold).float()


def object_height_tanh_multi_ycb(
    env: ManagerBasedRLEnv,
    target_height: float,
    std: float,
    min_reward_height: float | None = None,
) -> torch.Tensor:
    z = _gather_target_root_pos_w(env)[:, 2]
    err = torch.abs(z - target_height)
    out = 1.0 - torch.tanh(err / std)
    if min_reward_height is not None:
        out = out * (z >= min_reward_height).float()
    return out


def wrist_object_distance_shaping_multi_ycb(
    env: ManagerBasedRLEnv,
    std: float,
    wrist_link_name: str,
) -> torch.Tensor:
    robot: Articulation = env.scene["robot"]
    idx = robot.data.body_names.index(wrist_link_name)
    wrist_w = robot.data.body_pos_w[:, idx]
    obj_w = _gather_target_root_pos_w(env)
    dist = torch.norm(obj_w - wrist_w, dim=-1)
    print("dist: ", dist)
    return 1.0 - torch.tanh(dist / std)


def multi_finger_contact_shaping_multi_ycb(
    env: ManagerBasedRLEnv,
    sensor_names_15: list[str],
    force_threshold: float,
    tanh_scale: float = 2.0,
) -> torch.Tensor:
    mags = _finger_mags_target(env, sensor_names_15)
    count = (mags > force_threshold).float().sum(dim=-1)
    return torch.tanh(count / tanh_scale)


def thumb_opposition_contact_bonus_multi_ycb(
    env: ManagerBasedRLEnv,
    thumb_sensor_name: str,
    other_digit_sensor_names: list[str],
    force_threshold: float,
    sensor_names_15: list[str],
) -> torch.Tensor:
    """Uses stem names to pick rows from the target-object 5-finger slice (thumb + 4 others)."""
    mags = _finger_mags_target(env, sensor_names_15)
    stems_order = ("contact_r_thumb4", "contact_r_index2", "contact_r_middle2", "contact_r_ring2", "contact_r_little2")
    thumb_i = stems_order.index(thumb_sensor_name) if thumb_sensor_name in stems_order else 0
    other_is = [stems_order.index(s) for s in other_digit_sensor_names if s in stems_order]
    thumb_ok = mags[:, thumb_i] > force_threshold
    others_ok = torch.stack([mags[:, i] > force_threshold for i in other_is], dim=-1).any(dim=-1)
    return (thumb_ok & others_ok).float()


def grasp_lift_object_velocity_penalty_multi_ycb(
    env: ManagerBasedRLEnv,
    sensor_names_15: list[str],
    force_threshold: float,
    min_height: float,
    lin_vel_coeff: float = 1.0,
    ang_vel_coeff: float = 0.05,
) -> torch.Tensor:
    contact = finger_object_contact_binary_multi_ycb(env, sensor_names_15, force_threshold)
    lifted = (_gather_target_root_pos_w(env)[:, 2] >= min_height).float()
    mask = contact * lifted
    lv = torch.sum(torch.square(_gather_target_root_lin_vel_w(env)), dim=-1)
    av = torch.sum(torch.square(_gather_target_root_ang_vel_w(env)), dim=-1)
    return mask * (lin_vel_coeff * lv + ang_vel_coeff * av)


def lift_height_with_finger_contact_multi_ycb(
    env: ManagerBasedRLEnv,
    target_height: float,
    height_std: float,
    sensor_names_15: list[str],
    force_threshold: float,
    min_reward_height: float | None = None,
) -> torch.Tensor:
    h = object_height_tanh_multi_ycb(env, target_height, height_std, min_reward_height=min_reward_height)
    c = finger_object_contact_binary_multi_ycb(env, sensor_names_15, force_threshold)
    return h * c


def object_upward_velocity_when_finger_contact_multi_ycb(
    env: ManagerBasedRLEnv,
    sensor_names_15: list[str],
    force_threshold: float,
    std: float,
) -> torch.Tensor:
    vz = _gather_target_root_lin_vel_w(env)[:, 2]
    c = finger_object_contact_binary_multi_ycb(env, sensor_names_15, force_threshold)
    up = torch.clamp(vz, min=0.0)
    return c * torch.tanh(up / std)


def object_position_in_robot_root_frame_multi_ycb(
    env: ManagerBasedRLEnv,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
) -> torch.Tensor:
    robot: Articulation = env.scene[robot_cfg.name]
    object_pos_w = _gather_target_root_pos_w(env)
    object_pos_b, _ = subtract_frame_transforms(robot.data.root_pos_w, robot.data.root_quat_w, object_pos_w)
    return object_pos_b


def wrist_to_object_offset_in_robot_root_frame_multi_ycb(
    env: ManagerBasedRLEnv,
    wrist_link_name: str,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
) -> torch.Tensor:
    robot: Articulation = env.scene[robot_cfg.name]
    idx = robot.data.body_names.index(wrist_link_name)
    wrist_w = robot.data.body_pos_w[:, idx]
    obj_w = _gather_target_root_pos_w(env)
    wrist_b, _ = subtract_frame_transforms(
        robot.data.root_pos_w, robot.data.root_quat_w, wrist_w
    )
    obj_b, _ = subtract_frame_transforms(robot.data.root_pos_w, robot.data.root_quat_w, obj_w)
    return obj_b - wrist_b


def object_root_velocity_w_multi_ycb(env: ManagerBasedRLEnv) -> torch.Tensor:
    lin = _gather_target_root_lin_vel_w(env)
    ang = _gather_target_root_ang_vel_w(env)
    return torch.cat([lin, ang], dim=-1)


def finger_object_contact_vector_multi_ycb(
    env: ManagerBasedRLEnv,
    sensor_names_15: list[str],
    force_threshold: float,
) -> torch.Tensor:
    mags = _finger_mags_target(env, sensor_names_15)
    return (mags > force_threshold).float()


def object_root_height_reached_multi_ycb(
    env: ManagerBasedRLEnv,
    target_height: float,
) -> torch.Tensor:
    z = _gather_target_root_pos_w(env)[:, 2]
    return z >= target_height


def root_height_below_minimum_multi_ycb(
    env: ManagerBasedRLEnv,
    minimum_height: float,
) -> torch.Tensor:
    z = _gather_target_root_pos_w(env)[:, 2]
    return z < minimum_height


def object_pointnet_ycb_feature(
    env: ManagerBasedRLEnv,
    feature_npz_path: str,
) -> torch.Tensor:
    """256-D PointNet++ row for the **target** YCB object (``extract_ycb_pointnet2_features.py`` output)."""
    global _pointnet_ycb_cpu, _pointnet_ycb_path

    if not os.path.isfile(feature_npz_path):
        raise FileNotFoundError(
            f"PointNet YCB features missing: {feature_npz_path}\n"
            "Run: ./isaaclab.sh -p cxy_project/scripts/extract_ycb_pointnet2_features.py --checkpoint <best_model.pth>"
        )

    if _pointnet_ycb_cpu is None or _pointnet_ycb_path != feature_npz_path:
        data = np.load(feature_npz_path, allow_pickle=True)
        if "features" not in data or "names" not in data:
            raise KeyError(f"{feature_npz_path} must contain 'features' and 'names'")
        feats = np.asarray(data["features"], dtype=np.float32)
        names = data["names"]
        if feats.ndim != 2 or feats.shape[1] != 256:
            raise RuntimeError(f"Expected features (K, 256), got {feats.shape}")
        folder_to_row: dict[str, int] = {}
        for i, n in enumerate(names.tolist() if hasattr(names, "tolist") else list(names)):
            folder_to_row[str(n)] = i
        for folder in THREE_YCB_FOLDER_NAMES:
            if folder not in folder_to_row:
                raise KeyError(f"NPZ missing folder name {folder!r}; have {list(folder_to_row.keys())}")
        rows = np.stack([feats[folder_to_row[f]] for f in THREE_YCB_FOLDER_NAMES], axis=0)
        _pointnet_ycb_cpu = torch.from_numpy(np.ascontiguousarray(rows))
        _pointnet_ycb_path = feature_npz_path

    table = _pointnet_ycb_cpu.to(device=env.device, dtype=torch.float32)
    idx = _target_idx(env)
    return table[idx]
