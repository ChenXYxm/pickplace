# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Rewards for G1 Inspire pick / lift RL."""

from __future__ import annotations

from typing import TYPE_CHECKING

import torch

from isaaclab.assets import Articulation, RigidObject
from isaaclab.managers import SceneEntityCfg
from isaaclab.sensors import ContactSensor

if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedRLEnv


def _finger_sensor_force_max_mag_per_link(
    env: ManagerBasedRLEnv, sensor_names: list[str]
) -> torch.Tensor:
    """Per-sensor max contact force norm on that link, shape ``(num_envs, len(sensor_names))``."""
    mags: list[torch.Tensor] = []
    for name in sensor_names:
        sensor: ContactSensor = env.scene.sensors[name]
        fm = sensor.data.force_matrix_w
        n = fm.shape[0]
        f_flat = fm.reshape(n, -1, 3)
        mag = torch.norm(f_flat, dim=-1).max(dim=-1).values
        mags.append(mag)
    return torch.stack(mags, dim=-1)


def object_height_tanh(
    env: ManagerBasedRLEnv,
    target_height: float,
    std: float,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("object"),
    min_reward_height: float | None = None,
) -> torch.Tensor:
    """Shaped reward approaching ``target_height`` (world-frame *z* of object root).

    If ``min_reward_height`` is set, the reward is **zero** wherever object root *z* is strictly below that
    threshold (no partial credit on the ground / table).
    """
    obj: RigidObject = env.scene[asset_cfg.name]
    z = obj.data.root_pos_w[:, 2]
    err = torch.abs(z - target_height)
    out = 1.0 - torch.tanh(err / std)
    if min_reward_height is not None:
        out = out * (z >= min_reward_height).float()
    return out


def finger_object_contact_binary(
    env: ManagerBasedRLEnv,
    sensor_names: list[str],
    force_threshold: float,
) -> torch.Tensor:
    """1.0 if any listed contact sensor reports filtered contact force magnitude above threshold."""
    mags = _finger_sensor_force_max_mag_per_link(env, sensor_names)
    return (mags.max(dim=-1).values > force_threshold).float()


def wrist_object_distance_shaping(
    env: ManagerBasedRLEnv,
    std: float,
    wrist_link_name: str,
    object_cfg: SceneEntityCfg = SceneEntityCfg("object"),
) -> torch.Tensor:
    """Encourage the wrist link to approach the object (``1 - tanh(dist / std)`` in world frame)."""
    robot: Articulation = env.scene["robot"]
    obj: RigidObject = env.scene[object_cfg.name]
    idx = robot.data.body_names.index(wrist_link_name)
    wrist_w = robot.data.body_pos_w[:, idx]
    dist = torch.norm(obj.data.root_pos_w - wrist_w, dim=-1)
    return 1.0 - torch.tanh(dist / std)


def multi_finger_contact_shaping(
    env: ManagerBasedRLEnv,
    sensor_names: list[str],
    force_threshold: float,
    tanh_scale: float = 2.0,
) -> torch.Tensor:
    """Reward more fingers in contact: ``tanh(contact_count / tanh_scale)`` with count in ``[0, n]``."""
    mags = _finger_sensor_force_max_mag_per_link(env, sensor_names)
    count = (mags > force_threshold).float().sum(dim=-1)
    return torch.tanh(count / tanh_scale)


def thumb_opposition_contact_bonus(
    env: ManagerBasedRLEnv,
    thumb_sensor_name: str,
    other_digit_sensor_names: list[str],
    force_threshold: float,
) -> torch.Tensor:
    """1.0 when thumb and at least one non-thumb digit both exceed the contact force threshold."""
    names = [thumb_sensor_name] + list(other_digit_sensor_names)
    mags = _finger_sensor_force_max_mag_per_link(env, names)
    thumb_ok = mags[:, 0] > force_threshold
    others_ok = (mags[:, 1:] > force_threshold).any(dim=-1)
    return (thumb_ok & others_ok).float()


def grasp_lift_object_velocity_penalty(
    env: ManagerBasedRLEnv,
    sensor_names: list[str],
    force_threshold: float,
    min_height: float,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("object"),
    lin_vel_coeff: float = 1.0,
    ang_vel_coeff: float = 0.05,
) -> torch.Tensor:
    """Squared linear + angular object velocity, active only when object is high enough and fingers touch.

    Use a **negative** :attr:`RewardTermCfg.weight` so this reduces the score.
    """
    obj: RigidObject = env.scene[asset_cfg.name]
    contact = finger_object_contact_binary(env, sensor_names, force_threshold)
    lifted = (obj.data.root_pos_w[:, 2] >= min_height).float()
    mask = contact * lifted
    lv = torch.sum(torch.square(obj.data.root_lin_vel_w), dim=-1)
    av = torch.sum(torch.square(obj.data.root_ang_vel_w), dim=-1)
    return mask * (lin_vel_coeff * lv + ang_vel_coeff * av)


def lift_height_with_finger_contact(
    env: ManagerBasedRLEnv,
    target_height: float,
    height_std: float,
    sensor_names: list[str],
    force_threshold: float,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("object"),
    min_reward_height: float | None = None,
) -> torch.Tensor:
    """Height-shaping reward gated by finger–object contact (encourages grasped lift)."""
    h = object_height_tanh(env, target_height, height_std, asset_cfg, min_reward_height=min_reward_height)
    c = finger_object_contact_binary(env, sensor_names, force_threshold)
    return h * c


def object_upward_velocity_when_finger_contact(
    env: ManagerBasedRLEnv,
    sensor_names: list[str],
    force_threshold: float,
    std: float,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("object"),
) -> torch.Tensor:
    """Reward positive world-*z* linear velocity of the object when fingers touch (encourages actually lifting)."""
    obj: RigidObject = env.scene[asset_cfg.name]
    vz = obj.data.root_lin_vel_w[:, 2]
    c = finger_object_contact_binary(env, sensor_names, force_threshold)
    up = torch.clamp(vz, min=0.0)
    return c * torch.tanh(up / std)
