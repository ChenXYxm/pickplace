# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

import os

import torch
from pink.tasks import FrameTask

import carb

import isaaclab.envs.mdp as base_mdp
import isaaclab.sim as sim_utils
from isaaclab.assets import ArticulationCfg, AssetBaseCfg, RigidObjectCfg
from isaaclab.controllers.pink_ik import NullSpacePostureTask, PinkIKControllerCfg
from isaaclab.devices.device_base import DevicesCfg
from isaaclab.devices.openxr import ManusViveCfg, OpenXRDeviceCfg, XrCfg
from isaaclab.devices.openxr.retargeters.humanoid.unitree.inspire.g1_upper_body_retargeter import UnitreeG1RetargeterCfg
from isaaclab.envs import ManagerBasedRLEnvCfg
from isaaclab.envs.mdp.actions.pink_actions_cfg import PinkInverseKinematicsActionCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.sim.spawners.from_files.from_files_cfg import GroundPlaneCfg, UsdFileCfg
from isaaclab.utils import configclass
from isaaclab.utils.assets import ISAAC_NUCLEUS_DIR

from cxy_project.envs.g1_pick_place import mdp
from cxy_project.objects.ycb_objects_cfg import (
    CXY_OBJECTS_USD_CACHE_DIR,
    DEFAULT_YCB_OBJECT_ROOT,
    ycb_pick_cached_usd_path,
    ycb_pick_usd_file_name,
    ycb_poisson_textured_obj_path,
)
from cxy_project.robots.g1_inspire_ftp_urdf_cfg import (
    G1_INSPIRE_FTP_HAND_JOINT_NAMES,
    G1_INSPIRE_FTP_PINOCCHIO_PACKAGE_DIR,
    G1_INSPIRE_FTP_URDF_CFG,
    G1_INSPIRE_FTP_URDF_PATH,
)


##
# Scene definition
##
@configclass
class ObjectTableSceneCfg(InteractiveSceneCfg):
    """Configuration for the Unitree G1 Inspire Hand Pick Place Base Scene."""

    # Table
    packing_table = AssetBaseCfg(
        prim_path="/World/envs/env_.*/PackingTable",
        init_state=AssetBaseCfg.InitialStateCfg(pos=[0.0, 0.55, 0.0], rot=[1.0, 0.0, 0.0, 0.0]),
        spawn=UsdFileCfg(
            usd_path=f"{ISAAC_NUCLEUS_DIR}/Props/PackingTable/packing_table.usd",
            rigid_props=sim_utils.RigidBodyPropertiesCfg(kinematic_enabled=True),
        ),
    )

    # Manipuland: Berkeley YCB mesh under ``cxy_project/objects/<name>/poisson/textured.obj``.
    # USD path points at mesh→USD cache; :meth:`PickPlaceG1InspireFTPEnvCfg.__post_init__` runs
    # :class:`~isaaclab.sim.converters.MeshConverter` so the file exists before the scene spawns.
    object = RigidObjectCfg(
        prim_path="{ENV_REGEX_NS}/Object",
        init_state=RigidObjectCfg.InitialStateCfg(pos=[-0.2, 0.38, 0.9996], rot=[1, 0, 0, 0]),
        spawn=UsdFileCfg(
            usd_path=os.path.abspath(ycb_pick_cached_usd_path(DEFAULT_YCB_OBJECT_ROOT)),
            scale=(1.0, 1.0, 1.0),
        ),
    )

    # Humanoid robot: same actuators / defaults as Nucleus G1_INSPIRE_FTP_CFG, spawned from project URDF.
    robot: ArticulationCfg = G1_INSPIRE_FTP_URDF_CFG.replace(
        prim_path="/World/envs/env_.*/Robot",
        init_state=ArticulationCfg.InitialStateCfg(
            pos=(-0.2, 0, 1.0),
            rot=(0.7071, 0, 0, 0.7071),
            joint_pos={
                # right-arm
                "right_shoulder_pitch_joint": 0.0,
                "right_shoulder_roll_joint": -0.4,
                "right_shoulder_yaw_joint": 0.0,
                "right_elbow_joint": 0.0,
                "right_wrist_yaw_joint": 0.0,
                "right_wrist_roll_joint": 0.0,
                "right_wrist_pitch_joint": 0.0,
                # left-arm
                "left_shoulder_pitch_joint": 0.5,
                "left_shoulder_roll_joint": 0.15,
                "left_shoulder_yaw_joint": 0.0,
                "left_elbow_joint": 0.6,
                "left_wrist_yaw_joint": 0.0,
                "left_wrist_roll_joint": 0.0,
                "left_wrist_pitch_joint": 0.0,
                # --
                "waist_.*": 0.0,
                ".*_hip_.*": 0.0,
                ".*_knee_.*": 0.0,
                ".*_ankle_.*": 0.0,
                # Finger groups (fifth finger: `little` in this URDF).
                ".*_thumb_.*": 0.0,
                ".*_index_.*": 0.0,
                ".*_middle_.*": 0.0,
                ".*_ring_.*": 0.0,
                ".*_little_.*": 0.0,
            },
            joint_vel={".*": 0.0},
        ),
    )

    # Ground plane
    ground = AssetBaseCfg(
        prim_path="/World/GroundPlane",
        spawn=GroundPlaneCfg(),
    )

    # Lights
    light = AssetBaseCfg(
        prim_path="/World/light",
        spawn=sim_utils.DomeLightCfg(color=(0.75, 0.75, 0.75), intensity=3000.0),
    )


##
# MDP settings
##
@configclass
class ActionsCfg:
    """Action specifications for the MDP."""

    pink_ik_cfg = PinkInverseKinematicsActionCfg(
        pink_controlled_joint_names=[
            ".*_shoulder_pitch_joint",
            ".*_shoulder_roll_joint",
            ".*_shoulder_yaw_joint",
            ".*_elbow_joint",
            ".*_wrist_yaw_joint",
            ".*_wrist_roll_joint",
            ".*_wrist_pitch_joint",
        ],
        # 24 drive joints in Pinocchio / sim order for g1_29dof_rev_1_0_with_inspire_hand_FTP.urdf
        hand_joint_names=list(G1_INSPIRE_FTP_HAND_JOINT_NAMES),
        target_eef_link_names={
            # "left_wrist": "left_wrist_yaw_link",
            "right_wrist": "right_wrist_yaw_link",
        },
        # the robot in the sim scene we are controlling
        asset_name="robot",
        controller=PinkIKControllerCfg(
            articulation_name="robot",
            base_link_name="pelvis",
            num_hand_joints=12,
            show_ik_warnings=False,
            fail_on_joint_limit_violation=False,
            variable_input_tasks=[
                # FrameTask(
                #     "left_wrist_yaw_link",
                #     position_cost=8.0,  # [cost] / [m]
                #     orientation_cost=2.0,  # [cost] / [rad]
                #     lm_damping=10,  # dampening for solver for step jumps
                #     gain=0.5,
                # ),
                FrameTask(
                    "right_wrist_yaw_link",
                    position_cost=8.0,  # [cost] / [m]
                    orientation_cost=2.0,  # [cost] / [rad]
                    lm_damping=10,  # dampening for solver for step jumps
                    gain=0.5,
                ),
                NullSpacePostureTask(
                    cost=0.5,
                    lm_damping=1,
                    controlled_frames=[
                        # "left_wrist_yaw_link",
                        "right_wrist_yaw_link",
                    ],
                    controlled_joints=[
                        # "left_shoulder_pitch_joint",
                        # "left_shoulder_roll_joint",
                        # "left_shoulder_yaw_joint",
                        "right_shoulder_pitch_joint",
                        "right_shoulder_roll_joint",
                        "right_shoulder_yaw_joint",
                        "right_waist_yaw_joint",
                        "right_waist_pitch_joint",
                        "right_waist_roll_joint",
                        "waist_yaw_joint",
                        "waist_pitch_joint",
                        "waist_roll_joint",
                    ],
                    gain=0.3,
                ),
            ],
            fixed_input_tasks=[],
            xr_enabled=bool(carb.settings.get_settings().get("/app/xr/enabled")),
        ),
        enable_gravity_compensation=False,
    )


@configclass
class ObservationsCfg:
    """Observation specifications for the MDP."""

    @configclass
    class PolicyCfg(ObsGroup):
        """Observations for policy group with state values."""

        actions = ObsTerm(func=mdp.last_action)
        robot_joint_pos = ObsTerm(
            func=base_mdp.joint_pos,
            params={"asset_cfg": SceneEntityCfg("robot")},
        )
        robot_root_pos = ObsTerm(func=base_mdp.root_pos_w, params={"asset_cfg": SceneEntityCfg("robot")})
        robot_root_rot = ObsTerm(func=base_mdp.root_quat_w, params={"asset_cfg": SceneEntityCfg("robot")})
        object_pos = ObsTerm(func=base_mdp.root_pos_w, params={"asset_cfg": SceneEntityCfg("object")})
        object_rot = ObsTerm(func=base_mdp.root_quat_w, params={"asset_cfg": SceneEntityCfg("object")})
        robot_links_state = ObsTerm(func=mdp.get_all_robot_link_state)

        left_eef_pos = ObsTerm(func=mdp.get_eef_pos, params={"link_name": "left_wrist_yaw_link"})
        left_eef_quat = ObsTerm(func=mdp.get_eef_quat, params={"link_name": "left_wrist_yaw_link"})
        right_eef_pos = ObsTerm(func=mdp.get_eef_pos, params={"link_name": "right_wrist_yaw_link"})
        right_eef_quat = ObsTerm(func=mdp.get_eef_quat, params={"link_name": "right_wrist_yaw_link"})

        # Hand drive joints by finger (FTP URDF: fifth finger is `little`).
        hand_joint_state = ObsTerm(
            func=mdp.get_robot_joint_state,
            params={
                "joint_names": [
                    ".*_thumb_[0-9]_joint",
                    ".*_index_[0-9]_joint",
                    ".*_middle_[0-9]_joint",
                    ".*_ring_[0-9]_joint",
                    ".*_little_[0-9]_joint",
                ],
            },
        )

        object = ObsTerm(
            func=mdp.object_obs,
            params={"left_eef_link_name": "left_wrist_yaw_link", "right_eef_link_name": "right_wrist_yaw_link"},
        )

        def __post_init__(self):
            self.enable_corruption = False
            self.concatenate_terms = False

    # observation groups
    policy: PolicyCfg = PolicyCfg()


@configclass
class TerminationsCfg:
    """Termination terms for the MDP."""

    time_out = DoneTerm(func=mdp.time_out, time_out=True)

    object_dropping = DoneTerm(
        func=mdp.root_height_below_minimum, params={"minimum_height": 0.5, "asset_cfg": SceneEntityCfg("object")}
    )

    success = DoneTerm(func=mdp.task_done_pick_place, params={"task_link_name": "right_wrist_yaw_link"})


@configclass
class EventCfg:
    """Configuration for events."""

    reset_all = EventTerm(func=mdp.reset_scene_to_default, mode="reset")

    reset_object = EventTerm(
        func=mdp.reset_root_state_uniform,
        mode="reset",
        params={
            "pose_range": {
                "x": [-0.01, 0.01],
                "y": [-0.01, 0.01],
            },
            "velocity_range": {},
            "asset_cfg": SceneEntityCfg("object"),
        },
    )


@configclass
class PickPlaceG1InspireFTPEnvCfg(ManagerBasedRLEnvCfg):
    """Configuration for the GR1T2 environment."""

    # Berkeley YCB folder under ``cxy_project/objects`` (must contain ``poisson/textured.obj``).
    ycb_object_root: str = DEFAULT_YCB_OBJECT_ROOT
    ycb_object_scale: tuple[float, float, float] = (1.0, 1.0, 1.0)

    # Scene settings
    scene: ObjectTableSceneCfg = ObjectTableSceneCfg(num_envs=1, env_spacing=2.5, replicate_physics=True)
    # Basic settings
    observations: ObservationsCfg = ObservationsCfg()
    actions: ActionsCfg = ActionsCfg()
    # MDP settings
    terminations: TerminationsCfg = TerminationsCfg()
    events = EventCfg()

    # Unused managers
    commands = None
    rewards = None
    curriculum = None

    # Position of the XR anchor in the world frame
    xr: XrCfg = XrCfg(
        anchor_pos=(0.0, 0.0, 0.0),
        anchor_rot=(1.0, 0.0, 0.0, 0.0),
    )

    # Idle action to hold robot in default pose
    # Action format: [left arm pos (3), left arm quat (4), right arm pos (3), right arm quat (4),
    #                 left hand joint pos (12), right hand joint pos (12)]
    idle_action = torch.tensor(
        [
            # 14 = left/right wrist (pos3+quat4); below 24 = hand joints (must match num_hand_joints)
            # -0.1487,
            # 0.2038,
            # 1.0952,
            # 0.707,
            # 0.0,
            # 0.0,
            # 0.707,
            -0.0513,
            0.2038,
            1.0952,
            0.707,
            0.0,
            0.0,
            0.707,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
        ]
    )

    def __post_init__(self):
        """Post initialization."""
        # general settings
        self.decimation = 6
        self.episode_length_s = 20.0
        # simulation settings
        self.sim.dt = 1 / 120  # 120Hz
        self.sim.render_interval = 2

        # YCB manipuland: OBJ → USD cache (mass / collision baked into USD).
        from isaaclab.sim.converters import MeshConverter, MeshConverterCfg
        from isaaclab.sim.schemas.schemas_cfg import (
            CollisionPropertiesCfg,
            ConvexHullPropertiesCfg,
            MassPropertiesCfg,
            RigidBodyPropertiesCfg,
        )

        mesh_path = ycb_poisson_textured_obj_path(self.ycb_object_root)
        mesh_converter = MeshConverter(
            MeshConverterCfg(
                asset_path=mesh_path,
                usd_dir=CXY_OBJECTS_USD_CACHE_DIR,
                usd_file_name=ycb_pick_usd_file_name(self.ycb_object_root),
                mass_props=MassPropertiesCfg(mass=0.05),
                rigid_props=RigidBodyPropertiesCfg(),
                collision_props=CollisionPropertiesCfg(collision_enabled=True),
                mesh_collision_props=ConvexHullPropertiesCfg(),
                make_instanceable=False,
            )
        )
        self.scene.object.spawn = UsdFileCfg(
            usd_path=os.path.abspath(mesh_converter.usd_path),
            scale=self.ycb_object_scale,
        )

        # Pink / Pinocchio: fixed project URDF + mesh package dir (not USD→URDF export).
        self.actions.pink_ik_cfg.controller.urdf_path = G1_INSPIRE_FTP_URDF_PATH
        self.actions.pink_ik_cfg.controller.mesh_path = G1_INSPIRE_FTP_PINOCCHIO_PACKAGE_DIR

        self.teleop_devices = DevicesCfg(
            devices={
                "handtracking": OpenXRDeviceCfg(
                    retargeters=[
                        UnitreeG1RetargeterCfg(
                            enable_visualization=True,
                            # number of joints in both hands
                            num_open_xr_hand_joints=2 * 26,
                            sim_device=self.sim.device,
                            # Please confirm that self.actions.pink_ik_cfg.hand_joint_names is
                            # consistent with robot.joint_names[-24:]
                            # The order of the joints does matter as it will be used for
                            # converting pink_ik actions to final control actions in IsaacLab.
                            hand_joint_names=self.actions.pink_ik_cfg.hand_joint_names,
                        ),
                    ],
                    sim_device=self.sim.device,
                    xr_cfg=self.xr,
                ),
                "manusvive": ManusViveCfg(
                    retargeters=[
                        UnitreeG1RetargeterCfg(
                            enable_visualization=True,
                            num_open_xr_hand_joints=2 * 26,
                            sim_device=self.sim.device,
                            hand_joint_names=self.actions.pink_ik_cfg.hand_joint_names,
                        ),
                    ],
                    sim_device=self.sim.device,
                    xr_cfg=self.xr,
                ),
            },
        )


# Pinocchio 3.x: keep fix inside cxy_project only (do not patch source/isaaclab).
from cxy_project.patches.pink_pinocchio3_joint_names import apply_pink_pinocchio3_joint_names_fix

apply_pink_pinocchio3_joint_names_fix()
