# G1 Inspire Pick / Lift — PPO 奖励设计说明

本文档记录 **`G1PickPPORewardsCfg`**（定义于 `pickplace_g1_inspire_ppo_env_cfg.py`）在两次迭代中的奖励配置：  
**上一版**（强化接触/接近、高度门槛 `1.0 m`）与 **当前版**（解决「手包住物体但不抬起」、调整权重与门槛）.

实现函数见：`cxy_project/envs/g1_pick_place/mdp/rewards.py`。

---

## 共用设定（两版一致，除非另行说明）

| 项目 | 值 |
|------|-----|
| 目标高度 `target_height` | 1.25 m（世界系物体 root 的 *z*） |
| 高度 shaping 的 `std` / `height_std` | 0.15 |
| 腕–物距离 shaping 的 `std` | 0.18 |
| 接触力阈值 `force_threshold` | 0.5（与 `ContactSensor` 力矩阵一致，单位随仿真） |
| 多指 shaping 的 `tanh_scale` | 2.0 |
| 右手五指 contact 传感器名 | `contact_r_thumb4`, `contact_r_index2`, `contact_r_middle2`, `contact_r_ring2`, `contact_r_little2` |
| 腕部 link（距离奖励） | `right_wrist_yaw_link` |

**说明：** 物体初始高度约在 **1.0 m** 附近（场景里 spawn ~0.9996 m）。若 `min_reward_height` 取 **1.0**，则静止在桌面上时常有 **z &lt; 1.0**，高度相关项会为 **0**，策略容易只靠接触/接近拿分而不学习抬升。

---

## 上一版奖励（修改前）

该版本在接触与接近项上权重较高，且 **`lift_height` / `lift_while_touching` 使用 `min_reward_height: 1.0`**。在典型静止高度略低于 1.0 m 时，**高度 shaping 长期为 0**，易出现「手指包裹、不抬物体」的策略。

| 配置项 | 权重 | 主要参数 |
|--------|------|----------|
| `wrist_object_distance` | **0.35** | `std=0.18`, `wrist_link_name=right_wrist_yaw_link` |
| `multi_finger_contact` | **0.28** | `tanh_scale=2.0` |
| `thumb_opposition_contact` | **0.8** | 拇指 + 至少一指同时过阈值 |
| `lift_height` | **0.5** | `target_height=1.25`, `std=0.15`, **`min_reward_height=1.0`** |
| `finger_contact` | **0.5** | 任一指过阈值即 1 |
| `lift_while_touching` | **4.0** | `lift_height × contact`，**`min_reward_height=1.0`** |
| `grasp_lift_object_velocity` | **−0.02** | 举高且接触时惩罚线/角速度平方；**`min_height=1.0`** |
| `action_rate` | **−5e−5** | `base_mdp.action_rate_l2` |

**上一版没有：** `object_upward_vel_contact`（接触时向上速度奖励）。

---

## 当前版奖励（修改后）

### 核心常量

- **`LIFT_REWARD_MIN_Z = 0.99`**  
  用于 `lift_height`、`lift_while_touching` 的 `min_reward_height`，以及 `grasp_lift_object_velocity` 的 `min_height`。  
  略低于静止台面高度，使 **台面附近即有非零高度梯度**，并对「刚开始离地」毫米级抬升有信号。

### 奖励表

| 配置项 | 权重 | 主要参数 |
|--------|------|----------|
| `wrist_object_distance` | **0.12** | 同上，降低「只靠近、不抬」的局部最优 |
| `multi_finger_contact` | **0.12** | 同上 |
| `thumb_opposition_contact` | **0.35** | 同上 |
| `lift_height` | **0.9** | `min_reward_height`**= `LIFT_REWARD_MIN_Z` (0.99)** |
| `finger_contact` | **0.12** | 降低与多指/拇指的重复激励 |
| `lift_while_touching` | **6.0** | **`min_reward_height=0.99`**，强化「接触 + 高度」联合目标 |
| **`object_upward_vel_contact`** | **0.55** | **新增**：`mdp.object_upward_velocity_when_finger_contact`，`std=0.12`；有接触时对物体世界系 **+z 线速度** 做 `tanh`，鼓励「边抓边上提」 |
| `grasp_lift_object_velocity` | **−0.02** | **`min_height=0.99`**，与抬升阶段一致 |
| `action_rate` | **−5e−5** | 不变 |

### 当前版相对上一版的设计意图（摘要）

1. **高度门槛**：由 **1.0 → 0.99**，避免静止略低于 1.0 m 时整段高度奖励为 0。  
2. **权重再平衡**：减弱纯接近/纯接触，加强 `lift_height` 与 `lift_while_touching`，并新增 **向上速度** 项，直接对「抬升动作」给梯度。  
3. **稳定性惩罚**：`min_height` 与 `LIFT_REWARD_MIN_Z` 对齐，避免与抬升阶段脱节。

---

## 与代码的对应关系

- 奖励类：`pickplace_g1_inspire_ppo_env_cfg.py` → `G1PickPPORewardsCfg`  
- 标量函数：`mdp/rewards.py` 中同名函数（如 `object_height_tanh`、`lift_height_with_finger_contact`、`object_upward_velocity_when_finger_contact` 等）

若你修改本 README 中的「当前版」表格，请同步更新 `G1PickPPORewardsCfg`，避免文档与训练配置不一致。

---

## 版本记录

| 日期（约） | 说明 |
|------------|------|
| 2026-03 | 上一版：高接触权重 + `min_reward_height=1.0` |
| 2026-03 | 当前版：`LIFT_REWARD_MIN_Z`、权重调整、新增 `object_upward_vel_contact` |

（具体提交日期以 Git 历史为准。）
