# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""PPO training variant of :class:`PickPlaceG1InspireFTPEnvCfg`.

Three YCB objects per scene; each episode one **target** at the grasp pose and two **distractors** on the side.
Rewards, terminations, observations, and contact sensors only use the target object (see ``multi_ycb_mdp``).
"""

from __future__ import annotations

import os

import isaaclab.envs.mdp as base_mdp
from isaaclab.devices.device_base import DevicesCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import RewardTermCfg as RewTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.utils import configclass

from cxy_project.envs.g1_pick_place import mdp
from cxy_project.envs.g1_pick_place.g1_pick_ppo_three_ycb_scene_cfg import G1PickPPOThreeYcbSceneCfg
from cxy_project.envs.g1_pick_place.multi_ycb_constants import (
    three_ycb_contact_sensor_names_ordered,
)
from cxy_project.envs.g1_pick_place.pickplace_unitree_g1_inspire_hand_env_cfg import PickPlaceG1InspireFTPEnvCfg
from cxy_project.objects.ycb_objects_cfg import CXY_OBJECTS_DIR, CXY_OBJECTS_USD_CACHE_DIR, ycb_pick_usd_file_name, ycb_poisson_textured_obj_path
from cxy_project.robots.g1_inspire_ftp_urdf_cfg import G1_INSPIRE_FTP_HAND_JOINT_NAMES, G1_INSPIRE_FTP_PINOCCHIO_PACKAGE_DIR, G1_INSPIRE_FTP_URDF_PATH

# Right arm (Pink IK chain) + right Inspire hand only — matches manipulation DoF, drops legs / torso / left arm.
G1_RIGHT_ARM_JOINT_NAMES: tuple[str, ...] = (
    "right_shoulder_pitch_joint",
    "right_shoulder_roll_joint",
    "right_shoulder_yaw_joint",
    "right_elbow_joint",
    "right_wrist_yaw_joint",
    "right_wrist_roll_joint",
    "right_wrist_pitch_joint",
)
G1_RIGHT_ARM_AND_HAND_JOINT_NAMES_OBS: list[str] = list(G1_RIGHT_ARM_JOINT_NAMES) + list(G1_INSPIRE_FTP_HAND_JOINT_NAMES)

# Stems for thumb / non-thumb (used by thumb–opposition multi-ycb reward).
RIGHT_HAND_FINGER_SENSOR_STEMS: tuple[str, ...] = (
    "contact_r_thumb4",
    "contact_r_index2",
    "contact_r_middle2",
    "contact_r_ring2",
    "contact_r_little2",
)
RIGHT_HAND_THUMB_CONTACT_STEM: str = RIGHT_HAND_FINGER_SENSOR_STEMS[0]
RIGHT_HAND_NON_THUMB_CONTACT_STEMS: tuple[str, ...] = RIGHT_HAND_FINGER_SENSOR_STEMS[1:]

# 15 sensors: for each of 3 objects, 5 finger channels (order must match ``multi_ycb_mdp._finger_mags_target``).
THREE_YCB_CONTACT_SENSOR_NAMES_15: list[str] = three_ycb_contact_sensor_names_ordered()

# Default ``.npz`` from ``extract_ycb_pointnet2_features.py`` (must contain ``names`` + ``features`` for the three YCB folders).
YCB_POINTNET2_FEATURE_NPZ: str = os.path.join(CXY_OBJECTS_DIR, "object_pointnet2_msg_normals_256.npz")

# Object spawn ~1.0 m *z*; ``min_reward_height`` must stay **below** that so height shaping is non-zero on the table.
LIFT_REWARD_MIN_Z: float = 1.001


@configclass
class G1PickPPOEventCfg:
    """Reset: default scene state, then target + distractor poses for the three YCB bodies."""

    reset_all = EventTerm(func=base_mdp.reset_scene_to_default, mode="reset")

    randomize_multi_ycb_layout = EventTerm(
        func=mdp.randomize_multi_ycb_target_and_poses,
        mode="reset",
        params={
            "target_pose_local": (-0.2, 0.38, 0.9996),
            "distractor_x_range": (0.32, 0.75),
            "distractor_y_range": (0.51, 0.59),
            "distractor_z": 0.9996,
        },
    )


@configclass
class G1PickPPOObservationsCfg:
    """Policy observations; PointNet tail (256) is **last** (per-episode target object feature)."""

    @configclass
    class PolicyCfg(ObsGroup):
        joint_pos = ObsTerm(
            func=base_mdp.joint_pos_rel,
            params={
                "asset_cfg": SceneEntityCfg(
                    "robot",
                    joint_names=G1_RIGHT_ARM_AND_HAND_JOINT_NAMES_OBS,
                    preserve_order=True,
                )
            },
        )
        joint_vel = ObsTerm(
            func=base_mdp.joint_vel_rel,
            params={
                "asset_cfg": SceneEntityCfg(
                    "robot",
                    joint_names=G1_RIGHT_ARM_AND_HAND_JOINT_NAMES_OBS,
                    preserve_order=True,
                )
            },
        )
        object_position = ObsTerm(
            func=mdp.object_position_in_robot_root_frame_multi_ycb,
            params={"robot_cfg": SceneEntityCfg("robot")},
        )
        right_wrist_object_offset = ObsTerm(
            func=mdp.wrist_to_object_offset_in_robot_root_frame_multi_ycb,
            params={
                "wrist_link_name": "right_wrist_yaw_link",
                "robot_cfg": SceneEntityCfg("robot"),
            },
        )
        finger_contact_vector = ObsTerm(
            func=mdp.finger_object_contact_vector_multi_ycb,
            params={
                "sensor_names_15": THREE_YCB_CONTACT_SENSOR_NAMES_15,
                "force_threshold": 0.5,
            },
        )
        object_velocity_w = ObsTerm(func=mdp.object_root_velocity_w_multi_ycb, params={})
        actions = ObsTerm(func=mdp.last_action)
        object_pointnet256 = ObsTerm(
            func=mdp.object_pointnet_ycb_feature,
            params={"feature_npz_path": YCB_POINTNET2_FEATURE_NPZ},
        )

        def __post_init__(self):
            self.enable_corruption = False
            self.concatenate_terms = True

    policy: PolicyCfg = PolicyCfg()


@configclass
class G1PickPPORewardsCfg:
    """Lift target object only (see multi-ycb contact + state)."""

    wrist_object_distance = RewTerm(
        func=mdp.wrist_object_distance_shaping_multi_ycb,
        weight=0.12,
        params={
            "std": 0.18,
            "wrist_link_name": "right_wrist_yaw_link",
        },
    )
    multi_finger_contact = RewTerm(
        func=mdp.multi_finger_contact_shaping_multi_ycb,
        weight=0.12,
        params={
            "sensor_names_15": THREE_YCB_CONTACT_SENSOR_NAMES_15,
            "force_threshold": 0.5,
            "tanh_scale": 2.0,
        },
    )
    thumb_opposition_contact = RewTerm(
        func=mdp.thumb_opposition_contact_bonus_multi_ycb,
        weight=0.35,
        params={
            "thumb_sensor_name": RIGHT_HAND_THUMB_CONTACT_STEM,
            "other_digit_sensor_names": list(RIGHT_HAND_NON_THUMB_CONTACT_STEMS),
            "force_threshold": 0.5,
            "sensor_names_15": THREE_YCB_CONTACT_SENSOR_NAMES_15,
        },
    )

    lift_height = RewTerm(
        func=mdp.object_height_tanh_multi_ycb,
        weight=0.9,
        params={"target_height": 1.25, "std": 0.15, "min_reward_height": LIFT_REWARD_MIN_Z},
    )
    finger_contact = RewTerm(
        func=mdp.finger_object_contact_binary_multi_ycb,
        weight=0.12,
        params={"sensor_names_15": THREE_YCB_CONTACT_SENSOR_NAMES_15, "force_threshold": 0.5},
    )
    lift_while_touching = RewTerm(
        func=mdp.lift_height_with_finger_contact_multi_ycb,
        weight=6.0,
        params={
            "target_height": 1.25,
            "height_std": 0.15,
            "sensor_names_15": THREE_YCB_CONTACT_SENSOR_NAMES_15,
            "force_threshold": 0.5,
            "min_reward_height": LIFT_REWARD_MIN_Z,
        },
    )
    object_upward_vel_contact = RewTerm(
        func=mdp.object_upward_velocity_when_finger_contact_multi_ycb,
        weight=0.55,
        params={
            "sensor_names_15": THREE_YCB_CONTACT_SENSOR_NAMES_15,
            "force_threshold": 0.5,
            "std": 0.12,
        },
    )
    grasp_lift_object_velocity = RewTerm(
        func=mdp.grasp_lift_object_velocity_penalty_multi_ycb,
        weight=-0.02,
        params={
            "sensor_names_15": THREE_YCB_CONTACT_SENSOR_NAMES_15,
            "force_threshold": 0.5,
            "min_height": LIFT_REWARD_MIN_Z,
            "lin_vel_coeff": 1.0,
            "ang_vel_coeff": 0.05,
        },
    )
    action_rate = RewTerm(func=base_mdp.action_rate_l2, weight=-5e-5)


@configclass
class G1PickPPOTerminationsCfg:
    time_out = DoneTerm(func=mdp.time_out, time_out=True)

    object_dropping = DoneTerm(
        func=mdp.root_height_below_minimum_multi_ycb,
        params={"minimum_height": 0.35},
    )

    object_reached_lift_height = DoneTerm(
        func=mdp.object_root_height_reached_multi_ycb,
        params={"target_height": 1.25},
        time_out=False,
    )


@configclass
class G1InspirePickPPOEnvCfg(PickPlaceG1InspireFTPEnvCfg):
    """G1 Inspire + three YCB objects + Pink IK + PPO."""

    scene: G1PickPPOThreeYcbSceneCfg = G1PickPPOThreeYcbSceneCfg(num_envs=1, env_spacing=2.5, replicate_physics=False)
    observations: G1PickPPOObservationsCfg = G1PickPPOObservationsCfg()
    rewards: G1PickPPORewardsCfg = G1PickPPORewardsCfg()
    terminations: G1PickPPOTerminationsCfg = G1PickPPOTerminationsCfg()
    events: G1PickPPOEventCfg = G1PickPPOEventCfg()

    def __post_init__(self):
        """Match :class:`PickPlaceG1InspireFTPEnvCfg` timing/Pink URDF, but build **three** YCB USD caches."""
        self.decimation = 6
        self.episode_length_s = 20.0
        self.sim.dt = 1 / 120
        self.sim.render_interval = 2

        from isaaclab.sim.converters import MeshConverter, MeshConverterCfg
        from isaaclab.sim.schemas.schemas_cfg import (
            CollisionPropertiesCfg,
            ConvexHullPropertiesCfg,
            MassPropertiesCfg,
            RigidBodyPropertiesCfg,
        )
        from isaaclab.sim.spawners.from_files.from_files_cfg import UsdFileCfg

        from cxy_project.envs.g1_pick_place.multi_ycb_constants import THREE_YCB_ASSET_NAMES, THREE_YCB_FOLDER_NAMES

        for folder, attr in zip(THREE_YCB_FOLDER_NAMES, THREE_YCB_ASSET_NAMES):
            mesh_path = ycb_poisson_textured_obj_path(folder)
            mesh_converter = MeshConverter(
                MeshConverterCfg(
                    asset_path=mesh_path,
                    usd_dir=CXY_OBJECTS_USD_CACHE_DIR,
                    usd_file_name=ycb_pick_usd_file_name(folder),
                    mass_props=MassPropertiesCfg(mass=0.05),
                    rigid_props=RigidBodyPropertiesCfg(),
                    collision_props=CollisionPropertiesCfg(collision_enabled=True),
                    mesh_collision_props=ConvexHullPropertiesCfg(),
                    make_instanceable=False,
                )
            )
            getattr(self.scene, attr).spawn = UsdFileCfg(
                usd_path=os.path.abspath(mesh_converter.usd_path),
                scale=(1.0, 1.0, 1.0),
            )

        self.actions.pink_ik_cfg.controller.urdf_path = G1_INSPIRE_FTP_URDF_PATH
        self.actions.pink_ik_cfg.controller.mesh_path = G1_INSPIRE_FTP_PINOCCHIO_PACKAGE_DIR

        self.teleop_devices = DevicesCfg(devices={})
