# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Scene with multiple HY rigid bodies for PPO multi-target task."""

from __future__ import annotations

import os

import isaaclab.sim as sim_utils
from isaaclab.assets import ArticulationCfg, AssetBaseCfg, RigidObjectCfg
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.sim.schemas.schemas_cfg import (
    CollisionPropertiesCfg,
    MassPropertiesCfg,
    RigidBodyPropertiesCfg,
)
from isaaclab.sim.spawners.from_files.from_files_cfg import GroundPlaneCfg, UsdFileCfg
from isaaclab.utils import configclass
from isaaclab.utils.assets import ISAAC_NUCLEUS_DIR

from cxy_project.envs.g1_pick_place.multi_hy_constants import THREE_HY_PRIM_BASENAMES
from cxy_project.robots.g1_inspire_ftp_urdf_cfg import G1_INSPIRE_FTP_URDF_CFG

HY_OBJECTS_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "objects", "hy_objects")
HY_SPAWN_SCALE: tuple[float, float, float] = (0.125, 0.125, 0.125)
# Slightly larger than ``HY_SPAWN_SCALE`` for lotion assets (sim spawn scale only).
HY_SPAWN_SCALE_LOTION: tuple[float, float, float] = (0.14, 0.14, 0.14)


@configclass
class ThreeHyObjectTableSceneCfg(InteractiveSceneCfg):
    """Table + HY manipulands + G1 Inspire robot.

    Note: no legacy single ``object`` asset is defined. This scene cfg is intended for HY-only PPO.
    """

    packing_table = AssetBaseCfg(
        prim_path="/World/envs/env_.*/PackingTable",
        init_state=AssetBaseCfg.InitialStateCfg(pos=[0.0, 0.55, 0.0], rot=[1.0, 0.0, 0.0, 0.0]),
        spawn=UsdFileCfg(
            usd_path=f"{ISAAC_NUCLEUS_DIR}/Props/PackingTable/packing_table.usd",
            rigid_props=sim_utils.RigidBodyPropertiesCfg(kinematic_enabled=True),
        ),
    )

    hy_cleaner_bottle = RigidObjectCfg(
        prim_path=f"{{ENV_REGEX_NS}}/{THREE_HY_PRIM_BASENAMES[0]}",
        init_state=RigidObjectCfg.InitialStateCfg(pos=[-0.2, 0.38, 0.9996], rot=[1, 0, 0, 0]),
        spawn=UsdFileCfg(
            usd_path=os.path.abspath(os.path.join(HY_OBJECTS_DIR, "hy_cleaner_bottle", "qsim_hy_cleaner_bottle.usd")),
            scale=HY_SPAWN_SCALE,
            mass_props=MassPropertiesCfg(mass=0.05),
            rigid_props=RigidBodyPropertiesCfg(),
            collision_props=CollisionPropertiesCfg(collision_enabled=True),
            activate_contact_sensors=True,
        ),
    )
    hy_spray_bottle = RigidObjectCfg(
        prim_path=f"{{ENV_REGEX_NS}}/{THREE_HY_PRIM_BASENAMES[1]}",
        init_state=RigidObjectCfg.InitialStateCfg(pos=[0.5, 0.55, 0.9996], rot=[1, 0, 0, 0]),
        spawn=UsdFileCfg(
            usd_path=os.path.abspath(os.path.join(HY_OBJECTS_DIR, "hy_spray_bottle", "qsim_hy_spray_bottle.usd")),
            scale=HY_SPAWN_SCALE,
            mass_props=MassPropertiesCfg(mass=0.05),
            rigid_props=RigidBodyPropertiesCfg(),
            collision_props=CollisionPropertiesCfg(collision_enabled=True),
            activate_contact_sensors=True,
        ),
    )
    hy_whiteboard_cleaner = RigidObjectCfg(
        prim_path=f"{{ENV_REGEX_NS}}/{THREE_HY_PRIM_BASENAMES[2]}",
        init_state=RigidObjectCfg.InitialStateCfg(pos=[0.55, 0.52, 0.9996], rot=[1, 0, 0, 0]),
        spawn=UsdFileCfg(
            usd_path=os.path.abspath(
                os.path.join(HY_OBJECTS_DIR, "hy_whiteboard_cleaner", "qsim_hy_whiteboard_cleaner.usd")
            ),
            scale=HY_SPAWN_SCALE,
            mass_props=MassPropertiesCfg(mass=0.05),
            rigid_props=RigidBodyPropertiesCfg(),
            collision_props=CollisionPropertiesCfg(collision_enabled=True),
            activate_contact_sensors=True,
        ),
    )
    # hy_lotion_bottle = RigidObjectCfg(
    #     prim_path=f"{{ENV_REGEX_NS}}/{THREE_HY_PRIM_BASENAMES[3]}",
    #     init_state=RigidObjectCfg.InitialStateCfg(pos=[0.62, 0.45, 0.9996], rot=[1, 0, 0, 0]),
    #     spawn=UsdFileCfg(
    #         usd_path=os.path.abspath(os.path.join(HY_OBJECTS_DIR, "hy_lotion_bottle", "qsim_hy_lotion_bottle.usd")),
    #         scale=HY_SPAWN_SCALE_LOTION,
    #         mass_props=MassPropertiesCfg(mass=0.05),
    #         rigid_props=RigidBodyPropertiesCfg(),
    #         collision_props=CollisionPropertiesCfg(collision_enabled=True),
    #         activate_contact_sensors=True,
    #     ),
    # )
    # hy_lotion = RigidObjectCfg(
    #     prim_path=f"{{ENV_REGEX_NS}}/{THREE_HY_PRIM_BASENAMES[4]}",
    #     init_state=RigidObjectCfg.InitialStateCfg(pos=[0.68, 0.42, 0.9996], rot=[1, 0, 0, 0]),
    #     spawn=UsdFileCfg(
    #         usd_path=os.path.abspath(os.path.join(HY_OBJECTS_DIR, "hy_lotion", "qsim_hy_lotion_1.usd")),
    #         scale=HY_SPAWN_SCALE_LOTION,
    #         mass_props=MassPropertiesCfg(mass=0.05),
    #         rigid_props=RigidBodyPropertiesCfg(),
    #         collision_props=CollisionPropertiesCfg(collision_enabled=True),
    #         activate_contact_sensors=True,
    #     ),
    # )

    robot: ArticulationCfg = G1_INSPIRE_FTP_URDF_CFG.replace(
        prim_path="/World/envs/env_.*/Robot",
        init_state=ArticulationCfg.InitialStateCfg(
            pos=(-0.2, 0, 1.0),
            rot=(0.7071, 0, 0, 0.7071),
            joint_pos={
                # right-arm
                "right_shoulder_pitch_joint": 0.0,
                "right_shoulder_roll_joint": -0.4,
                "right_shoulder_yaw_joint": 0.0,
                "right_elbow_joint": 0.0,
                "right_wrist_yaw_joint": 0.0,
                "right_wrist_roll_joint": 0.0,
                "right_wrist_pitch_joint": 0.0,
                # left-arm
                "left_shoulder_pitch_joint": 0.5,
                "left_shoulder_roll_joint": 0.15,
                "left_shoulder_yaw_joint": 0.0,
                "left_elbow_joint": 0.6,
                "left_wrist_yaw_joint": 0.0,
                "left_wrist_roll_joint": 0.0,
                "left_wrist_pitch_joint": 0.0,
                # --
                "waist_.*": 0.0,
                ".*_hip_.*": 0.0,
                ".*_knee_.*": 0.0,
                ".*_ankle_.*": 0.0,
                # Finger groups
                ".*_thumb_.*": 0.0,
                ".*_index_.*": 0.0,
                ".*_middle_.*": 0.0,
                ".*_ring_.*": 0.0,
                ".*_little_.*": 0.0,
            },
            joint_vel={".*": 0.0},
        ),
    )

    ground = AssetBaseCfg(
        prim_path="/World/GroundPlane",
        spawn=GroundPlaneCfg(),
    )

    light = AssetBaseCfg(
        prim_path="/World/light",
        spawn=sim_utils.DomeLightCfg(color=(0.75, 0.75, 0.75), intensity=3000.0),
    )

