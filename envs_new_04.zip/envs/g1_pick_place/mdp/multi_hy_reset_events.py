# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Reset: random target HY object + fixed grasp pose + random distractor poses."""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

import torch

from isaaclab.assets import RigidObject
from isaaclab.utils.math import quat_from_euler_xyz

from cxy_project.envs.g1_pick_place.multi_hy_constants import THREE_HY_ASSET_NAMES

if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedEnv


def randomize_multi_hy_target_and_poses(
    env: ManagerBasedEnv,
    env_ids: torch.Tensor | None,
    target_pose_local: tuple[float, float, float] = (-0.2, 0.38, 0.9996),
    target_x_range: tuple[float, float] | None = None,
    target_y_range: tuple[float, float] | None = None,
    target_z_range: tuple[float, float] | None = None,
    distractor_x_range: tuple[float, float] = (0.32, 0.75),
    distractor_y_range: tuple[float, float] = (0.51, 0.59),
    distractor_z: float = 0.9996,
    asset_names: tuple[str, ...] = THREE_HY_ASSET_NAMES,
    target_object_weights: dict[str, float] | None = None,
    target_yaw_range: tuple[float, float] | None = None,
):
    """Sample a target index in ``0 .. len(asset_names)-1``, place that asset at fixed or randomized target local pose.

    Target pose uses ``target_pose_local`` by default. If ``target_x/y/z_range`` is provided, that axis is sampled
    uniformly per-environment. The **target** object's yaw (rotation about world +Z) is sampled uniformly in radians
    from ``target_yaw_range``; if ``None``, defaults to ``(-π, π)``. Distractors keep identity orientation.

    The remaining assets get independent uniform XY in the distractor ranges (same *z*).
    Writes ``env._cxy_target_object_idx`` and root pose / zero velocity into sim.

    If ``target_object_weights`` is set, keys are names in ``asset_names`` and values are **relative** sampling weights
    (unnormalized); missing names default to ``1.0``. If ``None``, each object is chosen uniformly.
    """
    if env_ids is None:
        env_ids = torch.arange(env.scene.num_envs, device="cpu")
    else:
        env_ids = env_ids.cpu()

    if env_ids.numel() == 0:
        return

    dev = env.device
    n_env = env.scene.num_envs
    eids = env_ids.to(dev, dtype=torch.long)
    n = eids.shape[0]

    if not hasattr(env, "_cxy_target_object_idx") or env._cxy_target_object_idx.shape[0] != n_env:
        env._cxy_target_object_idx = torch.zeros(n_env, dtype=torch.long, device=dev)
    if not hasattr(env, "_cxy_target_z0") or env._cxy_target_z0.shape[0] != n_env:
        env._cxy_target_z0 = torch.zeros(n_env, dtype=torch.float32, device=dev)

    n_assets = len(asset_names)
    if target_object_weights is None:
        pick = torch.randint(0, n_assets, (n,), device=dev, dtype=torch.long)
    else:
        w_list = [float(target_object_weights.get(name, 1.0)) for name in asset_names]
        w = torch.tensor(w_list, device=dev, dtype=torch.float32)
        if torch.any(w <= 0) or torch.any(torch.isnan(w)):
            raise ValueError(
                f"target_object_weights must be positive for every asset; got {dict(zip(asset_names, w_list))}"
            )
        w = w / w.sum()
        probs = w.expand(n, -1)
        pick = torch.multinomial(probs, num_samples=1).squeeze(-1).to(dtype=torch.long)
    env._cxy_target_object_idx[eids] = pick

    origins = env.scene.env_origins[eids]
    tx, ty, tz = target_pose_local
    txv = torch.full((n,), tx, device=dev, dtype=torch.float32)
    tyv = torch.full((n,), ty, device=dev, dtype=torch.float32)
    tzv = torch.full((n,), tz, device=dev, dtype=torch.float32)
    if target_x_range is not None:
        x_min, x_max = target_x_range
        txv = torch.rand(n, device=dev) * (x_max - x_min) + x_min
    if target_y_range is not None:
        y_min, y_max = target_y_range
        tyv = torch.rand(n, device=dev) * (y_max - y_min) + y_min
    if target_z_range is not None:
        z_min, z_max = target_z_range
        tzv = torch.rand(n, device=dev) * (z_max - z_min) + z_min
    target_w = origins + torch.stack([txv, tyv, tzv], dim=-1)
    # Cache per-episode initial target height (world z) for reward phase switching.
    env._cxy_target_z0[eids] = target_w[:, 2]

    x_min, x_max = distractor_x_range
    y_min, y_max = distractor_y_range
    n_distractors = n_assets - 1
    d_ws: list[torch.Tensor] = []
    for _ in range(n_distractors):
        dx = torch.rand(n, device=dev) * (x_max - x_min) + x_min
        dy = torch.rand(n, device=dev) * (y_max - y_min) + y_min
        d_ws.append(origins + torch.stack([dx, dy, torch.full((n,), distractor_z, device=dev)], dim=-1))

    yaw_min, yaw_max = (-math.pi, math.pi) if target_yaw_range is None else target_yaw_range
    yaw_t = torch.rand(n, device=dev, dtype=torch.float32) * (yaw_max - yaw_min) + yaw_min
    zero_rpy = torch.zeros(n, device=dev, dtype=torch.float32)
    quat_target = quat_from_euler_xyz(zero_rpy, zero_rpy, yaw_t)
    quat_distractor = torch.tensor([1.0, 0.0, 0.0, 0.0], device=dev, dtype=torch.float32).unsqueeze(0).expand(n, 4)
    zero_vel = torch.zeros(n, 6, device=dev, dtype=torch.float32)

    assets: list[RigidObject] = [env.scene[name] for name in asset_names]

    for t in range(n_assets):
        mask = pick == t
        if not mask.any():
            continue
        sub_eids = eids[mask]
        others = sorted(j for j in range(n_assets) if j != t)

        # Target object t
        pose_t = torch.cat([target_w[mask], quat_target[mask]], dim=-1)
        assets[t].write_root_pose_to_sim(pose_t, env_ids=sub_eids)
        assets[t].write_root_velocity_to_sim(zero_vel[mask], env_ids=sub_eids)

        for slot, oidx in enumerate(others):
            pose_d = torch.cat([d_ws[slot][mask], quat_distractor[mask]], dim=-1)
            assets[oidx].write_root_pose_to_sim(pose_d, env_ids=sub_eids)
            assets[oidx].write_root_velocity_to_sim(zero_vel[mask], env_ids=sub_eids)

