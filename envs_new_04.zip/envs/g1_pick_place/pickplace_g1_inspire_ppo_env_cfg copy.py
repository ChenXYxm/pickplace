# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""PPO training variant of :class:`PickPlaceG1InspireFTPEnvCfg`.

Rewards encourage reaching with the right wrist, multi-finger and thumb–opposition contact, lifting the object
to 1.25 m world *z*, penalizing object linear/angular velocity when lifted while touching, and smooth actions.
Contact is measured via filtered :class:`~isaaclab.sensors.ContactSensor` instances on distal finger links.

If contact sensors do not report forces, verify USD prim paths under ``{ENV_REGEX_NS}/Robot/...`` match your URDF import.
"""

from __future__ import annotations

import os

import isaaclab.envs.mdp as base_mdp
from isaaclab.devices.device_base import DevicesCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import RewardTermCfg as RewTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.sensors import ContactSensorCfg
from isaaclab.utils import configclass

from isaaclab_tasks.manager_based.manipulation.lift import mdp as lift_mdp

from cxy_project.envs.g1_pick_place import mdp
from cxy_project.envs.g1_pick_place.pickplace_unitree_g1_inspire_hand_env_cfg import (
    ObjectTableSceneCfg,
    PickPlaceG1InspireFTPEnvCfg,
)
from cxy_project.objects.ycb_objects_cfg import CXY_OBJECTS_DIR
from cxy_project.robots.g1_inspire_ftp_urdf_cfg import G1_INSPIRE_FTP_HAND_JOINT_NAMES

# Right arm (Pink IK chain) + right Inspire hand only — matches manipulation DoF, drops legs / torso / left arm.
G1_RIGHT_ARM_JOINT_NAMES: tuple[str, ...] = (
    "right_shoulder_pitch_joint",
    "right_shoulder_roll_joint",
    "right_shoulder_yaw_joint",
    "right_elbow_joint",
    "right_wrist_yaw_joint",
    "right_wrist_roll_joint",
    "right_wrist_pitch_joint",
)
G1_RIGHT_ARM_AND_HAND_JOINT_NAMES_OBS: list[str] = list(G1_RIGHT_ARM_JOINT_NAMES) + list(G1_INSPIRE_FTP_HAND_JOINT_NAMES)

# Distal / last driven segments on the right Inspire hand (URDF link names, no ``_link`` suffix).
RIGHT_HAND_FINGER_OBJECT_SENSOR_NAMES: tuple[str, ...] = (
    "contact_r_thumb4",
    "contact_r_index2",
    "contact_r_middle2",
    "contact_r_ring2",
    "contact_r_little2",
)
# First entry is thumb; remainder used for thumb–opposition bonus.
RIGHT_HAND_THUMB_CONTACT_SENSOR: str = RIGHT_HAND_FINGER_OBJECT_SENSOR_NAMES[0]
RIGHT_HAND_NON_THUMB_CONTACT_SENSORS: tuple[str, ...] = RIGHT_HAND_FINGER_OBJECT_SENSOR_NAMES[1:]

# Non-uniform scales for ``077_rubiks_cube``-style training (same 4 triples as PointNet feature extraction).
YCB_RUBIKS_NONUNIFORM_SCALE_CHOICES: tuple[tuple[float, float, float], ...] = (
    (0.9, 1.1, 1.0),
    (1.0, 1.0, 1.0),
    (1.2, 1.0, 1.2),
    (0.8, 1.3, 1.0),
)

# Default ``.npz`` from ``extract_rubiks_scaled_pointnet2_features.py`` (row *i* = scale choice *i*).
RUBIKS_POINTNET_SCALE_FEATURE_NPZ: str = os.path.join(
    CXY_OBJECTS_DIR, "077_rubiks_cube_scaled_pointnet2_256.npz"
)

# Object spawn ~1.0 m *z*; ``min_reward_height`` must stay **below** that so height shaping is non-zero on the table
# and gives a gradient for the first millimetres of lift (1.0 would zero out rewards at rest).
LIFT_REWARD_MIN_Z: float = 0.99


@configclass
class G1PickPPOEventCfg:
    """Reset pipeline: scene default → random object scale (discrete) → object pose jitter."""

    reset_all = EventTerm(func=base_mdp.reset_scene_to_default, mode="reset")

    randomize_object_scale_discrete = EventTerm(
        func=mdp.randomize_rigid_object_scale_discrete,
        mode="reset",
        params={
            "asset_cfg": SceneEntityCfg("object"),
            "scale_choices": list(YCB_RUBIKS_NONUNIFORM_SCALE_CHOICES),
        },
    )

    reset_object = EventTerm(
        func=base_mdp.reset_root_state_uniform,
        mode="reset",
        params={
            "pose_range": {
                "x": [-0.01, 0.01],
                "y": [-0.01, 0.01],
            },
            "velocity_range": {},
            "asset_cfg": SceneEntityCfg("object"),
        },
    )


@configclass
class G1PickPPOSceneCfg(ObjectTableSceneCfg):
    """Adds per-link contact sensors (filtered to the manipuland prim ``.../Object``)."""

    contact_r_thumb4 = ContactSensorCfg(
        prim_path="{ENV_REGEX_NS}/Robot/right_thumb_4",
        update_period=0.0,
        history_length=1,
        debug_vis=False,
        filter_prim_paths_expr=["{ENV_REGEX_NS}/Object"],
    )
    contact_r_index2 = ContactSensorCfg(
        prim_path="{ENV_REGEX_NS}/Robot/right_index_2",
        update_period=0.0,
        history_length=1,
        debug_vis=False,
        filter_prim_paths_expr=["{ENV_REGEX_NS}/Object"],
    )
    contact_r_middle2 = ContactSensorCfg(
        prim_path="{ENV_REGEX_NS}/Robot/right_middle_2",
        update_period=0.0,
        history_length=1,
        debug_vis=False,
        filter_prim_paths_expr=["{ENV_REGEX_NS}/Object"],
    )
    contact_r_ring2 = ContactSensorCfg(
        prim_path="{ENV_REGEX_NS}/Robot/right_ring_2",
        update_period=0.0,
        history_length=1,
        debug_vis=False,
        filter_prim_paths_expr=["{ENV_REGEX_NS}/Object"],
    )
    contact_r_little2 = ContactSensorCfg(
        prim_path="{ENV_REGEX_NS}/Robot/right_little_2",
        update_period=0.0,
        history_length=1,
        debug_vis=False,
        filter_prim_paths_expr=["{ENV_REGEX_NS}/Object"],
    )


@configclass
class G1PickPPOObservationsCfg:
    """Vector policy observations (flattened): right arm + right-hand joints only, object pose, wrist–object offset, contact flags, object velocity, actions, then PointNet tail (256)."""

    @configclass
    class PolicyCfg(ObsGroup):
        joint_pos = ObsTerm(
            func=base_mdp.joint_pos_rel,
            params={
                "asset_cfg": SceneEntityCfg(
                    "robot",
                    joint_names=G1_RIGHT_ARM_AND_HAND_JOINT_NAMES_OBS,
                    preserve_order=True,
                )
            },
        )
        joint_vel = ObsTerm(
            func=base_mdp.joint_vel_rel,
            params={
                "asset_cfg": SceneEntityCfg(
                    "robot",
                    joint_names=G1_RIGHT_ARM_AND_HAND_JOINT_NAMES_OBS,
                    preserve_order=True,
                )
            },
        )
        object_position = ObsTerm(
            func=lift_mdp.object_position_in_robot_root_frame,
            params={"robot_cfg": SceneEntityCfg("robot"), "object_cfg": SceneEntityCfg("object")},
        )
        # Grasp-centric geometry: object relative to wrist (robot root frame); complements `object_position`.
        right_wrist_object_offset = ObsTerm(
            func=mdp.wrist_to_object_offset_in_robot_root_frame,
            params={
                "wrist_link_name": "right_wrist_yaw_link",
                "robot_cfg": SceneEntityCfg("robot"),
                "object_cfg": SceneEntityCfg("object"),
            },
        )
        # Tactile proxy: one flag per distal link (same sensors / threshold as contact rewards).
        finger_contact_vector = ObsTerm(
            func=mdp.finger_object_contact_vector,
            params={
                "sensor_names": list(RIGHT_HAND_FINGER_OBJECT_SENSOR_NAMES),
                "force_threshold": 0.5,
            },
        )
        object_velocity_w = ObsTerm(
            func=mdp.object_root_velocity_w,
            params={"asset_cfg": SceneEntityCfg("object")},
        )
        actions = ObsTerm(func=mdp.last_action)
        # Must stay **last** in the policy group so PPO ``ActorCriticPointNetObsEncoder`` can take the tail 256-D.
        object_scale_pointnet256 = ObsTerm(
            func=mdp.object_scale_pointnet_feature,
            params={
                "feature_npz_path": RUBIKS_POINTNET_SCALE_FEATURE_NPZ,
                "expected_num_scales": len(YCB_RUBIKS_NONUNIFORM_SCALE_CHOICES),
            },
        )

        def __post_init__(self):
            self.enable_corruption = False
            self.concatenate_terms = True

    policy: PolicyCfg = PolicyCfg()


@configclass
class G1PickPPORewardsCfg:
    """Lift to 1.25 m + finger contact on the object."""

    # Reach (keep moderate — too high dominates "wrap without lift").
    wrist_object_distance = RewTerm(
        func=mdp.wrist_object_distance_shaping,
        weight=0.12,
        params={
            "std": 0.18,
            "wrist_link_name": "right_wrist_yaw_link",
            "object_cfg": SceneEntityCfg("object"),
        },
    )
    multi_finger_contact = RewTerm(
        func=mdp.multi_finger_contact_shaping,
        weight=0.12,
        params={
            "sensor_names": list(RIGHT_HAND_FINGER_OBJECT_SENSOR_NAMES),
            "force_threshold": 0.5,
            "tanh_scale": 2.0,
        },
    )
    thumb_opposition_contact = RewTerm(
        func=mdp.thumb_opposition_contact_bonus,
        weight=0.35,
        params={
            "thumb_sensor_name": RIGHT_HAND_THUMB_CONTACT_SENSOR,
            "other_digit_sensor_names": list(RIGHT_HAND_NON_THUMB_CONTACT_SENSORS),
            "force_threshold": 0.5,
        },
    )

    # Height shaping: ``min_reward_height`` must be < resting object *z* (~1.0) or terms stay 0 until a large jump.
    lift_height = RewTerm(
        func=mdp.object_height_tanh,
        weight=0.9,
        params={"target_height": 1.25, "std": 0.15, "min_reward_height": LIFT_REWARD_MIN_Z},
    )
    finger_contact = RewTerm(
        func=mdp.finger_object_contact_binary,
        weight=0.12,
        params={"sensor_names": list(RIGHT_HAND_FINGER_OBJECT_SENSOR_NAMES), "force_threshold": 0.5},
    )
    lift_while_touching = RewTerm(
        func=mdp.lift_height_with_finger_contact,
        weight=6.0,
        params={
            "target_height": 1.25,
            "height_std": 0.15,
            "sensor_names": list(RIGHT_HAND_FINGER_OBJECT_SENSOR_NAMES),
            "force_threshold": 0.5,
            "min_reward_height": LIFT_REWARD_MIN_Z,
        },
    )
    # Explicit signal to move the object upward while touching (addresses "cage but no lift").
    object_upward_vel_contact = RewTerm(
        func=mdp.object_upward_velocity_when_finger_contact,
        weight=0.55,
        params={
            "sensor_names": list(RIGHT_HAND_FINGER_OBJECT_SENSOR_NAMES),
            "force_threshold": 0.5,
            "std": 0.12,
            "asset_cfg": SceneEntityCfg("object"),
        },
    )
    # Penalize object slip / wobble when lifted and in contact (weight must be negative).
    grasp_lift_object_velocity = RewTerm(
        func=mdp.grasp_lift_object_velocity_penalty,
        weight=-0.02,
        params={
            "sensor_names": list(RIGHT_HAND_FINGER_OBJECT_SENSOR_NAMES),
            "force_threshold": 0.5,
            "min_height": LIFT_REWARD_MIN_Z,
            "asset_cfg": SceneEntityCfg("object"),
            "lin_vel_coeff": 1.0,
            "ang_vel_coeff": 0.05,
        },
    )
    action_rate = RewTerm(func=base_mdp.action_rate_l2, weight=-5e-5)


@configclass
class G1PickPPOTerminationsCfg:
    time_out = DoneTerm(func=mdp.time_out, time_out=True)

    object_dropping = DoneTerm(
        func=mdp.root_height_below_minimum,
        params={"minimum_height": 0.35, "asset_cfg": SceneEntityCfg("object")},
    )

    # Success: object lifted to goal height (world *z*, same frame as lift reward).
    object_reached_lift_height = DoneTerm(
        func=mdp.object_root_height_reached,
        params={"target_height": 1.25, "asset_cfg": SceneEntityCfg("object")},
        time_out=False,
    )


@configclass
class G1InspirePickPPOEnvCfg(PickPlaceG1InspireFTPEnvCfg):
    """G1 Inspire pick scene + Pink IK actions + PPO rewards/observations."""

    scene: G1PickPPOSceneCfg = G1PickPPOSceneCfg(num_envs=1, env_spacing=2.5, replicate_physics=True)
    observations: G1PickPPOObservationsCfg = G1PickPPOObservationsCfg()
    rewards: G1PickPPORewardsCfg = G1PickPPORewardsCfg()
    terminations: G1PickPPOTerminationsCfg = G1PickPPOTerminationsCfg()
    events: G1PickPPOEventCfg = G1PickPPOEventCfg()

    def __post_init__(self):
        super().__post_init__()
        # Headless / training: disable XR teleop device graph.
        self.teleop_devices = DevicesCfg(devices={})
