# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Register CXY G1 pick/lift tasks with ``gymnasium`` (import for side effects)."""

from __future__ import annotations

import gymnasium as gym

gym.register(
    id="CXY-G1-Inspire-Pick-Lift-PPO-v0",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    kwargs={
        "env_cfg_entry_point": "cxy_project.envs.g1_pick_place.pickplace_g1_inspire_ppo_env_cfg:G1InspirePickPPOEnvCfg",
        "rsl_rl_cfg_entry_point": "cxy_project.envs.g1_pick_place.agents.rsl_rl_ppo_cfg:G1PickPPORunnerCfg",
    },
    disable_env_checker=True,
)

gym.register(
    id="CXY-G1-Inspire-Pick-Lift-PPO-HY-v0",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    kwargs={
        "env_cfg_entry_point": "cxy_project.envs.g1_pick_place.pickplace_g1_inspire_ppo_hy_env_cfg:G1InspirePickPPOHyEnvCfg",
        "rsl_rl_cfg_entry_point": "cxy_project.envs.g1_pick_place.agents.rsl_rl_ppo_cfg:G1PickPPORunnerCfg",
    },
    disable_env_checker=True,
)

gym.register(
    id="CXY-G1-Inspire-Pick-Lift-PPO-HY-Nocontact-v0",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    kwargs={
        "env_cfg_entry_point": "cxy_project.envs.g1_pick_place.pickplace_g1_inspire_ppo_hy_env_cfg:G1InspirePickPPOHyNoContactEnvCfg",
        "rsl_rl_cfg_entry_point": "cxy_project.envs.g1_pick_place.agents.rsl_rl_ppo_cfg:G1PickPPORunnerCfg",
    },
    disable_env_checker=True,
)
