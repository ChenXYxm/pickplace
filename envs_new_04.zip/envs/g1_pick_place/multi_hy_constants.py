# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Shared constants for the multi-HY-object PPO task."""

from __future__ import annotations

# Asset keys (must match ``RigidObjectCfg`` attribute names in the HY scene cfg).
THREE_HY_ASSET_NAMES: tuple[str, ...] = (
    "hy_cleaner_bottle",
    "hy_spray_bottle",
    "hy_whiteboard_cleaner",
    # "hy_lotion_bottle",
    # "hy_lotion",
)

# Row names inside ``extract_hy_usd_pointnet2_features.py`` output NPZ.
THREE_HY_FOLDER_NAMES: tuple[str, ...] = (
    "hy_cleaner_bottle",
    "hy_spray_bottle",
    "hy_whiteboard_cleaner",
    # "hy_lotion_bottle",
    # "hy_lotion",
)

# USD prim basenames used by the contact sensor filter expressions.
THREE_HY_PRIM_BASENAMES: tuple[str, ...] = THREE_HY_FOLDER_NAMES

# Relative path under ``{ENV_REGEX_NS}/`` for **contact filter** (must match the rigid collider prim in USD).
# Example: ``/World/envs/env_0/hy_cleaner_bottle/hy_cleaner_bottle/mesh/mesh``
# If your spray/whiteboard USD differs, adjust the corresponding entry only.
THREE_HY_FILTER_PRIM_REL_PATHS: tuple[str, ...] = (
    "hy_cleaner_bottle/hy_cleaner_bottle/mesh/mesh",
    "hy_spray_bottle/hy_spray_bottle/mesh/mesh",
    "hy_whiteboard_cleaner/hy_whiteboard_cleaner/mesh/mesh",
    # # qsim USD uses nested xform + mesh like other HY crates
    # "hy_lotion_bottle/hy_lotion_bottle/mesh/mesh",
    # # defaultPrim in qsim is ``hy_lotion_1`` under root ``hy_lotion``
    # "hy_lotion/hy_lotion_1/mesh/mesh",
)

# Finger distal link sensor stems (same as the YCB env).
RIGHT_FINGER_SENSOR_STEMS: tuple[str, ...] = (
    "contact_r_thumb4",
    "contact_r_index2",
    "contact_r_middle2",
    "contact_r_ring2",
    "contact_r_little2",
)

# Robot link names (must match ``g1_pick_ppo_three_hy_scene_cfg._STEMS_LINKS``) for spatial gating.
RIGHT_FINGER_LINK_NAMES: tuple[str, ...] = (
    "right_thumb_4",
    "right_index_2",
    "right_middle_2",
    "right_ring_2",
    "right_little_2",
)


def three_hy_contact_sensor_names_ordered() -> list[str]:
    """Order: for each object index, append 5 stems in fixed order (5 × N sensors total)."""
    out: list[str] = []
    for oi in range(len(THREE_HY_ASSET_NAMES)):
        for stem in RIGHT_FINGER_SENSOR_STEMS:
            out.append(f"{stem}_o{oi}")
    return out

