# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Shared names for the three-YCB multi-object pick task."""

from __future__ import annotations

# Scene rigid-object asset keys (must match RigidObjectCfg attribute names on the scene cfg).
THREE_YCB_ASSET_NAMES: tuple[str, str, str] = ("ycb_rubiks", "ycb_meat_can", "ycb_sugar")

# YCB dataset folder names (mesh / extract_ycb_pointnet2_features.py ``names`` rows).
THREE_YCB_FOLDER_NAMES: tuple[str, str, str] = (
    "077_rubiks_cube",
    "010_potted_meat_can",
    "004_sugar_box",
)

# USD prim paths under each env (must match RigidObjectCfg.prim_path basename).
THREE_YCB_PRIM_BASENAMES: tuple[str, str, str] = ("YcbRubiks", "YcbMeatCan", "YcbSugarBox")

# Finger distal link sensor stem names (same as single-object task; paired with object suffix in cfg).
RIGHT_FINGER_SENSOR_STEMS: tuple[str, ...] = (
    "contact_r_thumb4",
    "contact_r_index2",
    "contact_r_middle2",
    "contact_r_ring2",
    "contact_r_little2",
)


def three_ycb_contact_sensor_names_ordered() -> list[str]:
    """Order matches :func:`cxy_project.envs.g1_pick_place.mdp.multi_ycb_mdp._finger_mags_target` (3 objects × 5 fingers)."""
    out: list[str] = []
    for oi in range(3):
        for stem in RIGHT_FINGER_SENSOR_STEMS:
            out.append(f"{stem}_o{oi}")
    return out
