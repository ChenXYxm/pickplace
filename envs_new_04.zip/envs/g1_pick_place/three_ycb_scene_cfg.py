# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Scene with three YCB rigid bodies (rubiks, meat can, sugar box) — PPO multi-target task."""

from __future__ import annotations

import os

import isaaclab.sim as sim_utils
from isaaclab.assets import ArticulationCfg, AssetBaseCfg, RigidObjectCfg
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.sim.spawners.from_files.from_files_cfg import GroundPlaneCfg, UsdFileCfg
from isaaclab.utils import configclass
from isaaclab.utils.assets import ISAAC_NUCLEUS_DIR

from cxy_project.envs.g1_pick_place.multi_ycb_constants import THREE_YCB_FOLDER_NAMES, THREE_YCB_PRIM_BASENAMES
from cxy_project.objects.ycb_objects_cfg import ycb_pick_cached_usd_path
from cxy_project.robots.g1_inspire_ftp_urdf_cfg import G1_INSPIRE_FTP_URDF_CFG

# Placeholder USD (overwritten in env ``__post_init__`` after MeshConverter); must be a valid path at import time.
_PLACEHOLDER_USD = os.path.abspath(ycb_pick_cached_usd_path(THREE_YCB_FOLDER_NAMES[0]))


@configclass
class ThreeYcbObjectTableSceneCfg(InteractiveSceneCfg):
    """Table + three YCB manipulands + G1 Inspire robot. No legacy ``object`` asset."""

    packing_table = AssetBaseCfg(
        prim_path="/World/envs/env_.*/PackingTable",
        init_state=AssetBaseCfg.InitialStateCfg(pos=[0.0, 0.55, 0.0], rot=[1.0, 0.0, 0.0, 0.0]),
        spawn=UsdFileCfg(
            usd_path=f"{ISAAC_NUCLEUS_DIR}/Props/PackingTable/packing_table.usd",
            rigid_props=sim_utils.RigidBodyPropertiesCfg(kinematic_enabled=True),
        ),
    )

    ycb_rubiks = RigidObjectCfg(
        prim_path=f"{{ENV_REGEX_NS}}/{THREE_YCB_PRIM_BASENAMES[0]}",
        init_state=RigidObjectCfg.InitialStateCfg(pos=[-0.2, 0.38, 0.9996], rot=[1, 0, 0, 0]),
        spawn=UsdFileCfg(usd_path=_PLACEHOLDER_USD, scale=(1.0, 1.0, 1.0)),
    )
    ycb_meat_can = RigidObjectCfg(
        prim_path=f"{{ENV_REGEX_NS}}/{THREE_YCB_PRIM_BASENAMES[1]}",
        init_state=RigidObjectCfg.InitialStateCfg(pos=[0.5, 0.55, 0.9996], rot=[1, 0, 0, 0]),
        spawn=UsdFileCfg(usd_path=_PLACEHOLDER_USD, scale=(1.0, 1.0, 1.0)),
    )
    ycb_sugar = RigidObjectCfg(
        prim_path=f"{{ENV_REGEX_NS}}/{THREE_YCB_PRIM_BASENAMES[2]}",
        init_state=RigidObjectCfg.InitialStateCfg(pos=[0.55, 0.52, 0.9996], rot=[1, 0, 0, 0]),
        spawn=UsdFileCfg(usd_path=_PLACEHOLDER_USD, scale=(1.0, 1.0, 1.0)),
    )

    robot: ArticulationCfg = G1_INSPIRE_FTP_URDF_CFG.replace(
        prim_path="/World/envs/env_.*/Robot",
        init_state=ArticulationCfg.InitialStateCfg(
            pos=(-0.2, 0, 1.0),
            rot=(0.7071, 0, 0, 0.7071),
            joint_pos={
                "right_shoulder_pitch_joint": 0.0,
                "right_shoulder_roll_joint": -0.4,
                "right_shoulder_yaw_joint": 0.0,
                "right_elbow_joint": 0.0,
                "right_wrist_yaw_joint": 0.0,
                "right_wrist_roll_joint": 0.0,
                "right_wrist_pitch_joint": 0.0,
                "left_shoulder_pitch_joint": 0.5,
                "left_shoulder_roll_joint": 0.15,
                "left_shoulder_yaw_joint": 0.0,
                "left_elbow_joint": 0.6,
                "left_wrist_yaw_joint": 0.0,
                "left_wrist_roll_joint": 0.0,
                "left_wrist_pitch_joint": 0.0,
                "waist_.*": 0.0,
                ".*_hip_.*": 0.0,
                ".*_knee_.*": 0.0,
                ".*_ankle_.*": 0.0,
                ".*_thumb_.*": 0.0,
                ".*_index_.*": 0.0,
                ".*_middle_.*": 0.0,
                ".*_ring_.*": 0.0,
                ".*_little_.*": 0.0,
            },
            joint_vel={".*": 0.0},
        ),
    )

    ground = AssetBaseCfg(
        prim_path="/World/GroundPlane",
        spawn=GroundPlaneCfg(),
    )

    light = AssetBaseCfg(
        prim_path="/World/light",
        spawn=sim_utils.DomeLightCfg(color=(0.75, 0.75, 0.75), intensity=3000.0),
    )
