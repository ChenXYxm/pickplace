# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

from isaaclab.utils import configclass

from isaaclab_rl.rsl_rl import RslRlOnPolicyRunnerCfg, RslRlPpoActorCriticCfg, RslRlPpoAlgorithmCfg


@configclass
class G1PickPpoActorCriticCfg(RslRlPpoActorCriticCfg):
    """Policy network with a trainable 2-hidden-layer encoder on trailing PointNet (256-D) features."""

    class_name: str = "ActorCriticPointNetObsEncoder"
    pointnet_raw_dim: int = 256
    pointnet_encoded_dim: int = 64
    pointnet_encoder_hidden_dims: list[int] = [256, 256]


@configclass
class G1PickPPORunnerCfg(RslRlOnPolicyRunnerCfg):
    """RSL-RL PPO defaults for CXY G1 Inspire pick/lift (Pink IK + hand joints)."""

    # Env exposes a single concatenated ``policy`` group; critic uses the same vector.
    obs_groups = {
        "policy": ["policy"],
        "critic": ["policy"],
    }

    num_steps_per_env = 24
    max_iterations = 2000
    save_interval = 100
    experiment_name = "g1_inspire_pick_lift_ppo"
    policy = G1PickPpoActorCriticCfg(
        init_noise_std=0.6,
        actor_obs_normalization=True,
        critic_obs_normalization=True,
        actor_hidden_dims=[512, 256, 128],
        critic_hidden_dims=[512, 256, 128],
        activation="elu",
    )
    algorithm = RslRlPpoAlgorithmCfg(
        value_loss_coef=1.0,
        use_clipped_value_loss=True,
        clip_param=0.2,
        entropy_coef=0.008,
        num_learning_epochs=5,
        num_mini_batches=4,
        learning_rate=3.0e-4,
        schedule="adaptive",
        gamma=0.99,
        lam=0.95,
        desired_kl=0.01,
        max_grad_norm=1.0,
    )
