# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""ActorCritic variant: last ``pointnet_raw_dim`` of policy/critic obs pass through a trainable MLP to ``pointnet_encoded_dim``."""

from __future__ import annotations

from typing import Any, NoReturn

import torch
import torch.nn as nn
from tensordict import TensorDict
from torch.distributions import Normal

from rsl_rl.networks import MLP, EmpiricalNormalization
from rsl_rl.modules import ActorCritic


class ActorCriticPointNetObsEncoder(ActorCritic):
    """Same as :class:`rsl_rl.modules.ActorCritic`, but splits trailing PointNet features, encodes, re-concatenates.

    Expects concatenated policy observation layout where the **last** ``pointnet_raw_dim`` components are
    the PointNet feature term (e.g. ``object_pointnet256``; keep it last in the policy group).
    """

    def __init__(
        self,
        obs: TensorDict,
        obs_groups: dict[str, list[str]],
        num_actions: int,
        pointnet_raw_dim: int = 256,
        pointnet_encoded_dim: int = 64,
        pointnet_encoder_hidden_dims: list[int] | tuple[int, ...] | None = None,
        actor_obs_normalization: bool = False,
        critic_obs_normalization: bool = False,
        actor_hidden_dims: tuple[int] | list[int] = (256, 256, 256),
        critic_hidden_dims: tuple[int] | list[int] = (256, 256, 256),
        activation: str = "elu",
        init_noise_std: float = 1.0,
        noise_std_type: str = "scalar",
        state_dependent_std: bool = False,
        **kwargs: dict[str, Any],
    ) -> None:
        if kwargs:
            print(
                "ActorCriticPointNetObsEncoder.__init__ got unexpected arguments, which will be ignored: "
                + str(list(kwargs.keys()))
            )
        nn.Module.__init__(self)

        self.obs_groups = obs_groups
        self.pointnet_raw_dim = int(pointnet_raw_dim)
        self.pointnet_encoded_dim = int(pointnet_encoded_dim)
        if pointnet_encoder_hidden_dims is None:
            pointnet_encoder_hidden_dims = (256, 256)
        self.pointnet_encoder_hidden_dims = tuple(pointnet_encoder_hidden_dims)

        num_actor_obs_full = 0
        for obs_group in obs_groups["policy"]:
            assert len(obs[obs_group].shape) == 2, "The ActorCritic module only supports 1D observations."
            num_actor_obs_full += obs[obs_group].shape[-1]
        num_critic_obs_full = 0
        for obs_group in obs_groups["critic"]:
            assert len(obs[obs_group].shape) == 2, "The ActorCritic module only supports 1D observations."
            num_critic_obs_full += obs[obs_group].shape[-1]

        if num_actor_obs_full < self.pointnet_raw_dim or num_critic_obs_full < self.pointnet_raw_dim:
            raise ValueError(
                f"Obs too small for pointnet tail: actor {num_actor_obs_full}, critic {num_critic_obs_full}, "
                f"need >= {self.pointnet_raw_dim}."
            )

        self._base_actor_dim = num_actor_obs_full - self.pointnet_raw_dim
        self._base_critic_dim = num_critic_obs_full - self.pointnet_raw_dim
        num_actor_in = self._base_actor_dim + self.pointnet_encoded_dim
        num_critic_in = self._base_critic_dim + self.pointnet_encoded_dim

        self.pointnet_encoder = MLP(
            self.pointnet_raw_dim,
            self.pointnet_encoded_dim,
            list(self.pointnet_encoder_hidden_dims),
            activation,
        )
        print(f"PointNet obs encoder MLP: {self.pointnet_encoder}")

        self.state_dependent_std = state_dependent_std

        if self.state_dependent_std:
            self.actor = MLP(num_actor_in, [2, num_actions], actor_hidden_dims, activation)
        else:
            self.actor = MLP(num_actor_in, num_actions, actor_hidden_dims, activation)
        print(f"Actor MLP: {self.actor}")

        self.actor_obs_normalization = actor_obs_normalization
        if actor_obs_normalization:
            # Normalize the vector *after* PointNet encoding (what the actor MLP sees).
            self.actor_obs_normalizer = EmpiricalNormalization(num_actor_in)
        else:
            self.actor_obs_normalizer = torch.nn.Identity()

        self.critic = MLP(num_critic_in, 1, critic_hidden_dims, activation)
        print(f"Critic MLP: {self.critic}")

        self.critic_obs_normalization = critic_obs_normalization
        if critic_obs_normalization:
            self.critic_obs_normalizer = EmpiricalNormalization(num_critic_in)
        else:
            self.critic_obs_normalizer = torch.nn.Identity()

        self.noise_std_type = noise_std_type
        if self.state_dependent_std:
            torch.nn.init.zeros_(self.actor[-2].weight[num_actions:])
            if self.noise_std_type == "scalar":
                torch.nn.init.constant_(self.actor[-2].bias[num_actions:], init_noise_std)
            elif self.noise_std_type == "log":
                torch.nn.init.constant_(
                    self.actor[-2].bias[num_actions:], torch.log(torch.tensor(init_noise_std + 1e-7))
                )
            else:
                raise ValueError(f"Unknown standard deviation type: {self.noise_std_type}. Should be 'scalar' or 'log'")
        else:
            if self.noise_std_type == "scalar":
                self.std = nn.Parameter(init_noise_std * torch.ones(num_actions))
            elif self.noise_std_type == "log":
                self.log_std = nn.Parameter(torch.log(init_noise_std * torch.ones(num_actions)))
            else:
                raise ValueError(f"Unknown standard deviation type: {self.noise_std_type}. Should be 'scalar' or 'log'")

        self.distribution = None
        Normal.set_default_validate_args(False)

    def forward(self) -> NoReturn:
        raise NotImplementedError

    def _encode_flat_obs(self, obs_flat: torch.Tensor, base_dim: int) -> torch.Tensor:
        base = obs_flat[..., :base_dim]
        pn = obs_flat[..., base_dim:]
        if pn.shape[-1] != self.pointnet_raw_dim:
            raise RuntimeError(
                f"Expected pointnet tail dim {self.pointnet_raw_dim}, got {pn.shape[-1]} (check obs ordering)."
            )
        enc = self.pointnet_encoder(pn)
        return torch.cat([base, enc], dim=-1)

    def get_actor_obs(self, obs: TensorDict) -> torch.Tensor:
        full = torch.cat([obs[obs_group] for obs_group in self.obs_groups["policy"]], dim=-1)
        return self._encode_flat_obs(full, self._base_actor_dim)

    def get_critic_obs(self, obs: TensorDict) -> torch.Tensor:
        full = torch.cat([obs[obs_group] for obs_group in self.obs_groups["critic"]], dim=-1)
        return self._encode_flat_obs(full, self._base_critic_dim)
