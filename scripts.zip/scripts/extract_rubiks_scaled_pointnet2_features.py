# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Extract 256-D PointNet2 MSG features for ``077_rubiks_cube`` at four non-uniform scales.

Uses the same pipeline as :mod:`extract_ycb_pointnet2_features` (mesh scale → sample → normals →
``pc_normalize`` on XYZ → network). Saves one ``.npz`` (names + features) and a matplotlib grid
of the **scaled** sampled point clouds (before ``pc_normalize``); subplot layout scales with the
number of scale triples (up to 4 columns).

Example::

    python cxy_project/scripts/extract_rubiks_scaled_pointnet2_features.py \\
        --checkpoint /path/to/best_model.pth --device cpu
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import warnings

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

_DEFAULT_OBJECT = "077_rubiks_cube"
# (sx, sy, sz) non-uniform scales applied to the mesh before sampling.
DEFAULT_SCALES: tuple[tuple[float, float, float], ...] = (
    # (0.9, 1.1, 1.0),
    # (1.0, 1.0, 1.0),
    # (1.2, 1.0, 1.2),
    # (0.8, 1.3, 1.0),
    (0.9, 2.0, 1.0),
    (1.0, 1.0, 1.0),
    (2.2, 1.0, 1.2),
    (0.8, 2.3, 1.0),
    (0.7, 2.4, 1.0),
    (0.6, 2.5, 1.0),
    (0.6, 2.7, 1.0),
    (2.5, 0.8, 1.0),
    (2.0, 0.6, 1.5),
    (2.2, 0.6, 1.8),
    (0.8, 2.8, 1.0),
    (1.0, 1.0, 2.3),
)


def _scale_tag(s: tuple[float, float, float]) -> str:
    """Stable string tag for scale triples (avoids ``:g`` turning 1.0 into ``1``)."""
    return f"{s[0]:.4f}_{s[1]:.4f}_{s[2]:.4f}"


def parse_args() -> argparse.Namespace:
    from cxy_project.scripts.extract_ycb_pointnet2_features import _DEFAULT_CHECKPOINT

    p = argparse.ArgumentParser(description="PointNet2 features for 077_rubiks_cube at 4 scales + viz.")
    p.add_argument("--checkpoint", type=str, default=_DEFAULT_CHECKPOINT)
    p.add_argument(
        "--objects-root",
        type=str,
        default=None,
        help="Root containing YCB dirs (default: cxy_project/objects).",
    )
    p.add_argument(
        "--output",
        type=str,
        default=None,
        help="Output .npz (default: cxy_project/objects/077_rubiks_cube_scaled_pointnet2_256.npz).",
    )
    p.add_argument(
        "--viz-output",
        type=str,
        default=None,
        help="Output PNG for point-cloud figure (default: next to --output).",
    )
    p.add_argument("--device", type=str, default="cuda")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--num-points", type=int, default=1024)
    p.add_argument("--mesh", type=str, choices=("poisson", "tsdf"), default="poisson")
    return p.parse_args()


def main() -> None:
    if _REPO_ROOT not in sys.path:
        sys.path.insert(0, _REPO_ROOT)

    args = parse_args()
    import importlib
    import numpy as np
    import torch

    from cxy_project.scripts import extract_ycb_pointnet2_features as ext

    default_out = os.path.join(_REPO_ROOT, "cxy_project", "objects", "077_rubiks_cube_scaled_pointnet2_256.npz")
    output = args.output or default_out
    viz_path = args.viz_output or (os.path.splitext(output)[0] + "_pointclouds.png")

    if not os.path.isfile(args.checkpoint):
        raise FileNotFoundError(
            f"Checkpoint not found: {args.checkpoint}\n"
            "Pass --checkpoint to your best_model.pth, or place it under the PointNet2 log path."
        )

    objects_root = args.objects_root or os.path.join(_REPO_ROOT, "cxy_project", "objects")
    sub = "poisson" if args.mesh == "poisson" else "tsdf"
    obj_path = os.path.join(objects_root, _DEFAULT_OBJECT, sub, "textured.obj")
    if not os.path.isfile(obj_path):
        raise FileNotFoundError(obj_path)

    if str(args.device).startswith("cuda") and not torch.cuda.is_available():
        warnings.warn("CUDA requested but not available; using CPU.", stacklevel=1)
        device = torch.device("cpu")
    else:
        device = torch.device(args.device)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=FutureWarning)
        ckpt = torch.load(args.checkpoint, map_location=device, weights_only=False)
    if "model_state_dict" not in ckpt:
        raise KeyError(f"Checkpoint missing 'model_state_dict': {list(ckpt.keys())}")

    pointnet2_cls_msg = importlib.import_module("pointnet2_cls_msg")
    model = pointnet2_cls_msg.get_model(40, normal_channel=True)
    model.load_state_dict(ckpt["model_state_dict"], strict=True)
    model = model.to(device)

    names_list: list[str] = []
    feats_list: list[np.ndarray] = []
    clouds_for_viz: list[tuple[str, np.ndarray]] = []

    for scale in DEFAULT_SCALES:
        tag = _scale_tag(scale)
        name = f"{_DEFAULT_OBJECT}_scale_{tag}"
        pc6, xyz_viz = ext.mesh_to_pointcloud_xyz_normals(
            obj_path, args.num_points, args.seed, scale_xyz=scale
        )
        pts = torch.from_numpy(pc6).float().to(device).transpose(1, 0).unsqueeze(0)
        feat = ext.extract_feature_256(model, pts).squeeze(0).detach().cpu().numpy().astype(np.float32)
        if feat.shape != (256,):
            raise RuntimeError(f"Bad feature shape {feat.shape} for scale {scale}")
        names_list.append(name)
        feats_list.append(feat)
        clouds_for_viz.append((name, xyz_viz))

    features = np.stack(feats_list, axis=0)
    names_arr = np.array(names_list, dtype=object)

    out_dir = os.path.dirname(os.path.abspath(output))
    if out_dir and not os.path.exists(out_dir):
        os.makedirs(out_dir, exist_ok=True)

    np.savez_compressed(output, names=names_arr, features=features)

    scales_serial = [[float(s[0]), float(s[1]), float(s[2])] for s in DEFAULT_SCALES]
    meta_path = os.path.splitext(output)[0] + "_meta.json"
    meta = {
        "object": _DEFAULT_OBJECT,
        "scales_xyz": scales_serial,
        "checkpoint_path": os.path.abspath(args.checkpoint),
        "mesh_variant": args.mesh,
        "num_points": args.num_points,
        "feature_dim": 256,
        "output_npz": os.path.abspath(output),
        "viz_png": os.path.abspath(viz_path),
    }
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)

    _save_pointcloud_figure(clouds_for_viz, viz_path)

    print(f"[INFO] Wrote {output}  features={features.shape}")
    print(f"[INFO] Meta {meta_path}")
    print(f"[INFO] Viz  {viz_path}")


def _save_pointcloud_figure(clouds: list[tuple[str, "np.ndarray"]], path: str) -> None:
    """Scatter subplots of scaled point clouds (XYZ before ``pc_normalize``); grid grows with ``len(clouds)``."""
    import math

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    from mpl_toolkits.mplot3d import Axes3D  # noqa: F401 — registers 3d projection

    n = len(clouds)
    if n == 0:
        return
    # Grid by count (avoids a single ultra-tall column of 3D axes).
    # e.g. n=11 → 5 cols × 3 rows; n=4 → 2×2; n=8 → 4×2.
    if n <= 4:
        ncols = n
    elif n <= 8:
        ncols = 4
    elif n <= 18:
        ncols = 5
    else:
        ncols = min(6, int(math.ceil(math.sqrt(n))))
    ncols = min(ncols, n)
    nrows = int(math.ceil(n / ncols))
    fig_w, fig_h = 2.5 * ncols, 2.5 * nrows
    fig = plt.figure(figsize=(fig_w, fig_h))
    for i, (title, xyz) in enumerate(clouds):
        ax = fig.add_subplot(nrows, ncols, i + 1, projection="3d")
        x, y, zc = xyz[:, 0], xyz[:, 1], xyz[:, 2]
        ax.scatter(x, y, zc, c=zc, cmap="viridis", s=2, alpha=0.85)
        ax.set_title(title, fontsize=9)
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        ax.set_zlabel("z")
        # Roughly equal aspect for shape comparison
        max_range = np.array(
            [x.max() - x.min(), y.max() - y.min(), zc.max() - zc.min()], dtype=np.float64
        ).max() / 2.0
        mid_x = (x.max() + x.min()) * 0.5
        mid_y = (y.max() + y.min()) * 0.5
        mid_z = (zc.max() + zc.min()) * 0.5
        ax.set_xlim(mid_x - max_range, mid_x + max_range)
        ax.set_ylim(mid_y - max_range, mid_y + max_range)
        ax.set_zlim(mid_z - max_range, mid_z + max_range)

    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    main()
