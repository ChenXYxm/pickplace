"""Run the Agibot place environments copied under cxy_project/place (random actions).

From the Isaac Lab repo root:

    ./isaaclab.sh -p cxy_project/scripts/run_place_env.py

    ./isaaclab.sh -p cxy_project/scripts/run_place_env.py --task Cxy-Place-Mug-Agibot-Left-Arm-RmpFlow-v0
"""

from __future__ import annotations

import argparse
import os
import sys

_WORKSPACE_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if _WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, _WORKSPACE_ROOT)

from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser(description="Random agent for cxy_project place environments.")
parser.add_argument(
    "--disable_fabric",
    action="store_true",
    default=False,
    help="Disable fabric and use USD I/O operations.",
)
parser.add_argument("--num_envs", type=int, default=1, help="Number of environments.")
parser.add_argument(
    "--task",
    type=str,
    default="Cxy-Place-Toy2Box-Agibot-Right-Arm-RmpFlow-v0",
    help="Gym task id (see cxy_project.place.config.agibot).",
)
AppLauncher.add_app_launcher_args(parser)
args_cli = parser.parse_args()

app_launcher = AppLauncher(args_cli)
simulation_app = app_launcher.app

import gymnasium as gym
import torch

import cxy_project.place.config.agibot  # noqa: F401 — register gym envs
from isaaclab_tasks.utils import parse_env_cfg


def main() -> None:
    env_cfg = parse_env_cfg(
        args_cli.task,
        device=args_cli.device,
        num_envs=args_cli.num_envs,
        use_fabric=not args_cli.disable_fabric,
    )
    env = gym.make(args_cli.task, cfg=env_cfg)

    print(f"[INFO]: Task: {args_cli.task}")
    print(f"[INFO]: Observation space: {env.observation_space}")
    print(f"[INFO]: Action space: {env.action_space}")

    env.reset()
    while simulation_app.is_running():
        with torch.inference_mode():
            actions = 2 * torch.rand(env.action_space.shape, device=env.unwrapped.device) - 1
            env.step(actions)

    env.close()


if __name__ == "__main__":
    main()
    simulation_app.close()
