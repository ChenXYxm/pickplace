# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Print physics-related prim paths for HY ``qsim_*.usd`` assets (requires ``pxr`` from Isaac Sim).

Contact sensors use ``filter_prim_paths_expr`` like ``{ENV_REGEX_NS}/hy_cleaner_bottle``. PhysX must
resolve that pattern to the same rigid bodies that collide. If the **only** RigidBody lives on a
child prim (e.g. ``.../hy_cleaner_bottle/mesh``), verify the filter glob still matches (Isaac Lab
converts ``.*`` to ``*`` for PhysX).

Run from repo root::

    ./isaaclab.sh -p cxy_project/scripts/inspect_hy_usd_prims.py

"""

from __future__ import annotations

import os

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
_HY = os.path.join(_REPO_ROOT, "cxy_project", "objects", "hy_objects")

_USD = (
    ("hy_cleaner_bottle", "qsim_hy_cleaner_bottle.usd"),
    ("hy_spray_bottle", "qsim_hy_spray_bottle.usd"),
    ("hy_whiteboard_cleaner", "qsim_hy_whiteboard_cleaner.usd"),
)


def main() -> None:
    from pxr import PhysxSchema, Usd, UsdPhysics

    for folder, fname in _USD:
        path = os.path.join(_HY, folder, fname)
        if not os.path.isfile(path):
            print(f"[skip] missing: {path}")
            continue
        stage = Usd.Stage.Open(path)
        if not stage:
            print(f"[skip] could not open: {path}")
            continue
        print(f"\n=== {folder} ({fname}) ===")
        print(f"defaultPrim: {stage.GetDefaultPrim().GetPath() if stage.GetDefaultPrim() else None}")
        for prim in stage.Traverse():
            p = prim.GetPath()
            has_rb = prim.HasAPI(UsdPhysics.RigidBodyAPI) or prim.HasAPI(PhysxSchema.PhysxRigidBodyAPI)
            has_collision = prim.HasAPI(UsdPhysics.CollisionAPI) or prim.HasAPI(PhysxSchema.PhysxCollisionAPI)
            if has_rb or has_collision:
                flags = []
                if has_rb:
                    flags.append("RigidBody")
                if has_collision:
                    flags.append("Collision")
                print(f"  {p}  [{'+'.join(flags)}]")


if __name__ == "__main__":
    main()
