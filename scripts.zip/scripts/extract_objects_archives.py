#!/usr/bin/env python3
"""Extract all ``*.tgz`` archives under ``cxy_project/objects``.

Berkeley-processed YCB-style meshes ship as tar.gz; each archive usually contains one top-level folder.

From the Isaac Lab repo root::

    python cxy_project/scripts/extract_objects_archives.py

Or::

    python cxy_project/scripts/extract_objects_archives.py --objects-dir /path/to/objects
"""

from __future__ import annotations

import argparse
import sys
import tarfile
from pathlib import Path


def _objects_dir_default() -> Path:
    return Path(__file__).resolve().parent.parent / "objects"


def extract_all(objects_dir: Path, *, dry_run: bool) -> int:
    objects_dir = objects_dir.resolve()
    if not objects_dir.is_dir():
        print(f"error: not a directory: {objects_dir}", file=sys.stderr)
        return 1

    archives = sorted(objects_dir.glob("*.tgz"))
    if not archives:
        print(f"no .tgz files in {objects_dir}")
        return 0

    extract_kw: dict = {}
    if sys.version_info >= (3, 12):
        extract_kw["filter"] = "data"

    for path in archives:
        if dry_run:
            print(f"would extract: {path.name}")
            continue
        print(f"extracting: {path.name}")
        with tarfile.open(path, "r:gz") as tar:
            tar.extractall(path=objects_dir, **extract_kw)

    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Extract all *.tgz in cxy_project/objects.")
    parser.add_argument(
        "--objects-dir",
        type=Path,
        default=_objects_dir_default(),
        help="Directory containing .tgz files (default: cxy_project/objects next to this script).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Only list archives, do not extract.",
    )
    args = parser.parse_args()
    return extract_all(args.objects_dir, dry_run=args.dry_run)


if __name__ == "__main__":
    raise SystemExit(main())
