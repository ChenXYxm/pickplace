import argparse
import os
import sys
import time
import pinocchio
_WORKSPACE_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__),"..",".."))
if _WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0,_WORKSPACE_ROOT)

from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser(description=" ")
parser.add_argument("--num_envs",type=int,default=1)
AppLauncher.add_app_launcher_args(parser)

args_cli = parser.parse_args()

app_launcher = AppLauncher(args_cli)

simulation_app = app_launcher.app

import torch
from isaaclab.envs import ManagerBasedRLEnv

from cxy_project.envs.right_hand_env_cfg import RightHandGraspEnvCfg

def main():
    env_cfg = RightHandGraspEnvCfg()
    env_cfg.scene_num_envs = args_cli.num_envs
    env = ManagerBasedRLEnv(env_cfg)
    act_dim = env.action_manager.total_action_dim

    assert act_dim == 19, f"Expected 19, got {act_dim}"

    wrist_quat = torch.tensor([0.7071,0,0,-0.7071],device=env.device)
    obs,_ = env.reset()

    count = 0
    low = torch.tensor([-0.1,-0.1,0.8],device = env.device)
    high = torch.tensor([0.1,0.1,1.0],device = env.device)

    while simulation_app.is_running():
        if count%300 == 0:
            obs, _ = env.reset()
        
        actions = torch.zeros(env.num_envs,act_dim,device=env.device)

        actions[:,0:3] = (high-low)*torch.rand(env.num_envs,3,device=env.device)
        actions[:,3:7] = wrist_quat.unsqueeze(0).expand(env.num_envs,-1)

        t = (count%300)/300.0
        actions[:,7:19] = t*1.2
        time.sleep(0.02)
        _,_,_,_,_ = env.step(actions)
        count += 1
    env.close()

if __name__ == "__main__":
    main()