# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Extract 256-D PointNet++ MSG features for YCB meshes under ``cxy_project/objects``.

Loads ``pointnet2_msg_normals`` classification weights (ModelNet40, 6-D inputs with normals),
samples 1024 points + face normals from ``poisson/textured.obj`` (or ``tsdf``), optionally applies
per-axis mesh scaling before sampling, applies the same ``pc_normalize`` on XYZ as
:class:`ModelNetDataLoader`, and saves the penultimate MLP embedding
(256-D, after fc2+bn2+relu, before the 40-D classifier) plus object folder names.

The default checkpoint path is under ``pointnet2/.../checkpoints/best_model.pth``; place the trained
file there or pass ``--checkpoint``.

Example (from Isaac Lab repo root)::

    ./isaaclab.sh -p cxy_project/scripts/extract_ycb_pointnet2_features.py \\
        --checkpoint pointnet2/Pointnet_Pointnet2_pytorch/log/classification/pointnet2_msg_normals/checkpoints/best_model.pth

Or any Python with torch + trimesh on ``PYTHONPATH``::

    python cxy_project/scripts/extract_ycb_pointnet2_features.py --device cpu
"""

from __future__ import annotations

import argparse
import importlib
import json
import os
import sys
import warnings

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
_POINTNET2_MODELS = os.path.join(
    _REPO_ROOT, "pointnet2", "Pointnet_Pointnet2_pytorch", "models"
)
_DEFAULT_CHECKPOINT = os.path.join(
    _REPO_ROOT,
    "pointnet2",
    "Pointnet_Pointnet2_pytorch",
    "log",
    "classification",
    "pointnet2_msg_normals",
    "checkpoints",
    "best_model.pth",
)
_DEFAULT_OUTPUT = os.path.join(
    _REPO_ROOT, "cxy_project", "objects", "object_pointnet2_msg_normals_256.npz"
)

if _POINTNET2_MODELS not in sys.path:
    sys.path.insert(0, _POINTNET2_MODELS)


def pc_normalize(pc: "np.ndarray") -> "np.ndarray":
    """Same as ModelNetDataLoader.pc_normalize: centroid + unit ball scale."""
    import numpy as np

    centroid = np.mean(pc, axis=0)
    pc = pc - centroid
    m = np.max(np.sqrt(np.sum(pc**2, axis=1)))
    if m < 1e-8:
        m = 1.0
    pc = pc / m
    return pc


def mesh_to_pointcloud_xyz_normals(
    obj_path: str,
    num_points: int,
    seed: int | None,
    scale_xyz: tuple[float, float, float] | None = None,
) -> tuple["np.ndarray", "np.ndarray"]:
    """Sample ``num_points`` surface points; normals from face normals.

    If ``scale_xyz`` is set, the mesh is scaled per-axis (sx, sy, sz) before sampling (non-uniform scale).

    Returns:
        pc6: float32 (N, 6) with ModelNet-style ``pc_normalize`` applied to XYZ only.
        xyz_before_normalize: float32 (N, 3) sampled positions after optional scaling, **before** ``pc_normalize``
            (useful for visualization of physical aspect ratios).
    """
    import numpy as np
    import trimesh

    if seed is not None:
        np.random.seed(seed)

    loaded = trimesh.load(obj_path, force="mesh", skip_materials=True)
    if isinstance(loaded, trimesh.Scene):
        if len(loaded.geometry) == 0:
            raise ValueError(f"Empty scene: {obj_path}")
        mesh = trimesh.util.concatenate(tuple(loaded.geometry.values()))
    else:
        mesh = loaded

    if not isinstance(mesh, trimesh.Trimesh) or mesh.faces.shape[0] == 0:
        raise ValueError(f"Not a triangle mesh: {obj_path}")

    if scale_xyz is not None:
        mesh = mesh.copy()
        mesh.apply_scale(np.asarray(scale_xyz, dtype=np.float64))

    points, face_idx = mesh.sample(num_points, return_index=True)
    xyz = np.asarray(points, dtype=np.float32)
    xyz_before_normalize = xyz.copy()
    normals = np.asarray(mesh.face_normals[face_idx], dtype=np.float32)
    nrm = np.linalg.norm(normals, axis=1, keepdims=True)
    nrm = np.where(nrm > 1e-8, nrm, 1.0)
    normals = normals / nrm

    pc6 = np.concatenate([xyz, normals], axis=1)
    pc6[:, 0:3] = pc_normalize(pc6[:, 0:3].astype(np.float64)).astype(np.float32)
    return pc6, xyz_before_normalize


def extract_feature_256(model: "torch.nn.Module", points_b6n: "torch.Tensor") -> "torch.Tensor":
    """Penultimate 256-D vector (post fc2, bn2, relu, dropout in eval). Input: [B, 6, N]."""
    import torch
    import torch.nn.functional as F

    model.eval()
    xyz = points_b6n
    B, _, _ = xyz.shape
    if model.normal_channel:
        norm = xyz[:, 3:, :]
        xyz_only = xyz[:, :3, :]
    else:
        norm = None
        xyz_only = xyz

    with torch.no_grad():
        l1_xyz, l1_points = model.sa1(xyz_only, norm)
        l2_xyz, l2_points = model.sa2(l1_xyz, l1_points)
        _l3_xyz, l3_points = model.sa3(l2_xyz, l2_points)
        x = l3_points.view(B, 1024)
        x = model.drop1(F.relu(model.bn1(model.fc1(x))))
        x = model.drop2(F.relu(model.bn2(model.fc2(x))))
    return x


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Extract 256-D PointNet2 MSG features for YCB objects.")
    p.add_argument(
        "--checkpoint",
        type=str,
        default=_DEFAULT_CHECKPOINT,
        help="Path to best_model.pth (expects key 'model_state_dict').",
    )
    p.add_argument(
        "--objects-root",
        type=str,
        default=None,
        help="Root folder containing YCB object dirs (default: cxy_project/objects).",
    )
    p.add_argument("--output", type=str, default=_DEFAULT_OUTPUT, help="Output .npz path.")
    p.add_argument("--device", type=str, default="cuda", help="cuda | cpu | cuda:0, ...")
    p.add_argument("--seed", type=int, default=0, help="NumPy seed for mesh sampling (per-run reproducibility).")
    p.add_argument("--num-points", type=int, default=1024, help="Must match training (1024).")
    p.add_argument(
        "--mesh",
        type=str,
        choices=("poisson", "tsdf"),
        default="poisson",
        help="Subfolder under each object (textured.obj).",
    )
    p.add_argument(
        "--allow-missing",
        action="store_true",
        help="Skip objects with missing mesh files instead of failing.",
    )
    return p.parse_args()


def main() -> None:
    args = parse_args()
    import numpy as np
    import torch

    if not os.path.isfile(args.checkpoint):
        raise FileNotFoundError(
            f"Checkpoint not found: {args.checkpoint}\n"
            "Copy best_model.pth from your PointNet2 training run into that path, or pass --checkpoint."
        )

    objects_root = args.objects_root or os.path.join(_REPO_ROOT, "cxy_project", "objects")
    if not os.path.isdir(objects_root):
        raise FileNotFoundError(f"Objects root not found: {objects_root}")

    from cxy_project.objects.ycb_objects_cfg import YCB_OBJECT_ROOTS

    if str(args.device).startswith("cuda") and not torch.cuda.is_available():
        warnings.warn("CUDA requested but not available; using CPU.", stacklevel=1)
        device = torch.device("cpu")
    else:
        device = torch.device(args.device)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=FutureWarning)
        ckpt = torch.load(args.checkpoint, map_location=device, weights_only=False)

    if "model_state_dict" not in ckpt:
        raise KeyError(f"Checkpoint missing 'model_state_dict' keys: {list(ckpt.keys())}")

    pointnet2_cls_msg = importlib.import_module("pointnet2_cls_msg")
    model = pointnet2_cls_msg.get_model(40, normal_channel=True)
    model.load_state_dict(ckpt["model_state_dict"], strict=True)
    model = model.to(device)

    names_list: list[str] = []
    feats_list: list[np.ndarray] = []

    sub = "poisson" if args.mesh == "poisson" else "tsdf"

    for name in YCB_OBJECT_ROOTS:
        obj_path = os.path.join(objects_root, name, sub, "textured.obj")
        if not os.path.isfile(obj_path):
            msg = f"Missing mesh: {obj_path}"
            if args.allow_missing:
                warnings.warn(msg, stacklevel=1)
                continue
            raise FileNotFoundError(msg)

        pc6, _ = mesh_to_pointcloud_xyz_normals(obj_path, args.num_points, args.seed)
        pts = torch.from_numpy(pc6).float().to(device).transpose(1, 0).unsqueeze(0)
        feat = extract_feature_256(model, pts).squeeze(0).detach().cpu().numpy().astype(np.float32)

        if feat.shape != (256,):
            raise RuntimeError(f"Expected feature shape (256,), got {feat.shape} for {name}")

        names_list.append(name)
        feats_list.append(feat)

    if not names_list:
        raise RuntimeError("No objects processed (empty list). Check YCB_OBJECT_ROOTS and mesh paths.")

    features = np.stack(feats_list, axis=0)
    names_arr = np.array(names_list, dtype=object)

    out_dir = os.path.dirname(os.path.abspath(args.output))
    if out_dir and not os.path.exists(out_dir):
        os.makedirs(out_dir, exist_ok=True)

    np.savez_compressed(args.output, names=names_arr, features=features)

    meta_path = os.path.splitext(args.output)[0] + "_meta.json"
    meta = {
        "checkpoint_path": os.path.abspath(args.checkpoint),
        "objects_root": os.path.abspath(objects_root),
        "output_npz": os.path.abspath(args.output),
        "num_points": args.num_points,
        "normal_channel": True,
        "mesh_variant": args.mesh,
        "model": "pointnet2_cls_msg",
        "num_class": 40,
        "feature_dim": 256,
        "object_count": int(features.shape[0]),
        "feature_dtype": "float32",
    }
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)

    print(f"[INFO] Wrote {args.output}  features={features.shape}  meta={meta_path}")


if __name__ == "__main__":
    # Ensure cxy_project is importable when run as ``python cxy_project/scripts/...``
    if _REPO_ROOT not in sys.path:
        sys.path.insert(0, _REPO_ROOT)
    main()
