# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Compare ``ContactSensor`` net vs filtered forces for the HY pick task (debug ``force_matrix_w``).

Run from Isaac Lab repo root::

    ./isaaclab.sh -p cxy_project/scripts/debug_contact_hy.py --headless
    ./isaaclab.sh -p cxy_project/scripts/debug_contact_hy.py --headless --physx-cpu

Interpretation (same physics step, same sensor):

- **Both ~0**: PhysX reports no contact on that finger link (or forces below noise).
- **net > 0, matrix ~0**: Unfiltered contact exists but **filtered** ``get_contact_force_matrix``
  is zero — typical on **GPU** PhysX for unsupported collider pairs, or **filter prim** mismatch.
  Re-run with ``--physx-cpu``; if matrix becomes non-zero, the issue is GPU filtered contact.
- **Both > 0**: Filtering works; rewards using ``force_matrix_w`` are valid.

Requires Pinocchio (same as training)."""

from __future__ import annotations

import pinocchio  # noqa: F401 — import order for Pink / Isaac Lab

import argparse
import os
import sys

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

import cxy_project.envs.g1_pick_place.task_registration  # noqa: F401

from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser(description="Debug HY contact: net_forces_w vs force_matrix_w.")
parser.add_argument(
    "--physx-cpu",
    action="store_true",
    dest="physx_cpu",
    help="Use CPU PhysX (ablation for GPU filtered-contact issues). "
    "Note: AppLauncher reserves --cpu for Kit; use this flag instead.",
)
parser.add_argument("--steps", type=int, default=120, help="Simulation steps after reset.")
parser.add_argument(
    "--print-every",
    type=int,
    default=30,
    help="Print net/matrix stats every N steps (0 = only last step).",
)
AppLauncher.add_app_launcher_args(parser)
args_cli = parser.parse_args()

app_launcher = AppLauncher(args_cli)
simulation_app = app_launcher.app

import numpy as np
import torch
import gymnasium as gym

from cxy_project.envs.g1_pick_place.multi_hy_constants import three_hy_contact_sensor_names_ordered
from cxy_project.envs.g1_pick_place.pickplace_g1_inspire_ppo_hy_env_cfg import G1InspirePickPPOHyEnvCfg


def _unwrap_mgr(env):
    """Return the underlying env that exposes ``scene.sensors`` (ManagerBasedRLEnv)."""
    e = env
    while hasattr(e, "unwrapped"):
        e = e.unwrapped
    if not hasattr(e, "scene") or not hasattr(e.scene, "sensors"):
        raise TypeError(f"Expected env with scene.sensors, got {type(e)}")
    return e


def _sensor_stats(sensor) -> tuple[float, float]:
    """Max norm of net forces vs max norm of filtered force matrix (per env)."""
    net = sensor.data.net_forces_w
    fm = sensor.data.force_matrix_w
    if net is None or fm is None:
        return float("nan"), float("nan")
    n = net.shape[0]
    net_flat = net.reshape(n, -1, 3)
    net_max = float(torch.norm(net_flat, dim=-1).max().item())
    fm_flat = fm.reshape(n, -1, 3)
    fm_max = float(torch.norm(fm_flat, dim=-1).max().item())
    return net_max, fm_max


def main() -> None:
    env_cfg = G1InspirePickPPOHyEnvCfg()
    env_cfg.scene.num_envs = 1
    if args_cli.physx_cpu:
        env_cfg.sim.device = "cpu"
    elif args_cli.device is not None:
        env_cfg.sim.device = args_cli.device

    task = "CXY-G1-Inspire-Pick-Lift-PPO-HY-v0"
    env = gym.make(task, cfg=env_cfg)
    mgr = _unwrap_mgr(env)

    names_15 = three_hy_contact_sensor_names_ordered()
    sensor_keys = set(mgr.scene.sensors.keys())
    missing = [n for n in names_15 if n not in sensor_keys]
    extra_note = ""
    if missing:
        print(f"[ERROR] Missing HY contact sensors in scene: {missing}")
        extra_note = " (sensor registration mismatch)"
    else:
        print("[OK] All 15 HY contact sensor names are registered.")

    _, _ = env.reset(seed=0)
    dev = env_cfg.sim.device
    if dev == "cpu":
        action = torch.zeros(env.action_space.shape, dtype=torch.float32)
    else:
        action = torch.zeros(env.action_space.shape, dtype=torch.float32, device=dev)

    def report(step_idx: int) -> None:
        t = int(mgr._cxy_target_object_idx[0].item()) if hasattr(mgr, "_cxy_target_object_idx") else -1
        print(f"\n--- step {step_idx} | target_idx={t} ---")
        for stem in ("contact_r_thumb4", "contact_r_index2"):
            for oi in range(3):
                name = f"{stem}_o{oi}"
                if name not in mgr.scene.sensors:
                    continue
                s = mgr.scene.sensors[name]
                net_m, fm_m = _sensor_stats(s)
                tag = "TARGET" if oi == t else "dist"
                print(f"  {name} ({tag}):  net_max={net_m:.6f}  matrix_max={fm_m:.6f}")

    for step in range(args_cli.steps):
        _, _, terminated, truncated, _ = env.step(action)
        pe = args_cli.print_every
        if pe > 0 and (step + 1) % pe == 0:
            report(step + 1)
        if np.asarray(terminated).any() or np.asarray(truncated).any():
            _, _ = env.reset()

    print("\n=== Final step report ===")
    report(args_cli.steps)
    print(
        "\nIf net_max >> 0 but matrix_max == 0 for the TARGET row, try re-running with --physx-cpu "
        "to test CPU PhysX filtered contact." + extra_note
    )

    env.close()


if __name__ == "__main__":
    try:
        main()
    finally:
        simulation_app.close()
