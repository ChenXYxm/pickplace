"""Run the Unitree G1 + Inspire Pink-IK pick-place environment (cxy_project copy).

Requires Isaac Sim, `pink`, and Isaac Lab assets (G1 Inspire FTP, Mimic steering wheel USD).

Robot is spawned from ``cxy_project/g1_description/g1_29dof_rev_1_0_with_inspire_hand_FTP.urdf`` (see
``cxy_project/robots/g1_inspire_ftp_urdf_cfg.py``). Pink IK uses the same URDF + package directory for meshes.

From the Isaac Lab repo root:

    ./isaaclab.sh -p cxy_project/scripts/run_g1_pick_place_inspire.py

Uses the config's ``idle_action`` by default (stable hold); pass ``--random`` for random wrist
targets (first 14 dims in [-1, 1]) and zero hand commands (last 24 dims).
"""

from __future__ import annotations

import argparse
import os
import sys
import pinocchio
_WORKSPACE_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if _WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, _WORKSPACE_ROOT)

from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser(description="Run G1 Inspire pick-place env (cxy_project).")
parser.add_argument("--num_envs", type=int, default=1, help="Number of parallel environments.")
parser.add_argument(
    "--random",
    action="store_true",
    help="Random first 14 dims (wrist IK targets) in [-1,1]; last 24 dims (hands) stay 0.",
)
AppLauncher.add_app_launcher_args(parser)
args_cli = parser.parse_args()

app_launcher = AppLauncher(args_cli)
simulation_app = app_launcher.app

import torch

from isaaclab.envs import ManagerBasedRLEnv

from cxy_project.envs.g1_pick_place.pickplace_unitree_g1_inspire_hand_env_cfg import PickPlaceG1InspireFTPEnvCfg

# Matches PinkInverseKinematicsAction: 2 FrameTasks × (3+4) + num_hand_joints.
_HEAD_ACTION_DIM = 7
_HAND_ACTION_DIM = 12


def main() -> None:
    env_cfg = PickPlaceG1InspireFTPEnvCfg()
    env_cfg.scene.num_envs = args_cli.num_envs
    env = ManagerBasedRLEnv(env_cfg)

    device = env.unwrapped.device
    act_dim = env.action_manager.total_action_dim
    idle_vec = env_cfg.idle_action.to(device=device, dtype=torch.float32)
    if idle_vec.shape[0] != act_dim:
        raise RuntimeError(
            f"env_cfg.idle_action length {idle_vec.shape[0]} != action_manager.total_action_dim {act_dim}"
        )
    if act_dim != _HEAD_ACTION_DIM + _HAND_ACTION_DIM:
        raise RuntimeError(
            f"expected action dim {_HEAD_ACTION_DIM + _HAND_ACTION_DIM} (14 wrist + 24 hand), got {act_dim}"
        )
    idle = idle_vec.unsqueeze(0).expand(env.num_envs, -1)

    print(f"[INFO]: total_action_dim={act_dim}")
    print(f"[INFO]: num_envs={env.num_envs}, random_actions={args_cli.random}")

    env.reset()
    while simulation_app.is_running():
        with torch.inference_mode():
            if args_cli.random:
                actions = torch.zeros(env.num_envs, act_dim, device=device)
                actions[:, :] = torch.empty(
                    env.num_envs, _HEAD_ACTION_DIM+_HAND_ACTION_DIM, device=device
                ).uniform_(-1.0, 1.0)
            else:
                actions = idle.clone()
            env.step(actions)

    env.close()


if __name__ == "__main__":
    main()
    simulation_app.close()
