#!/usr/bin/env python3
# Copyright (c) 2022-2026, The Isaac Lab Project Developers.
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Warm-start PPO (RSL-RL) when observation dimension increases.

This script targets the HY NoContact task and supports warm-starting from an older checkpoint after adding new
observation terms. It implements *scheme B*:

- new_obs = [old_obs, extra_k]
- expand actor/critic first Linear layer weight from (H, old_dim) -> (H, old_dim+k)
  (copy old weights, initialize new columns to 0)
- expand EmpiricalNormalization buffers for actor/critic obs normalization
  (mean=0, var=1, std=1 for new dims; keep count)

Important:
- Keep ``object_pointnet256`` as the last 256 dims of the concatenated policy obs (required by
  ``ActorCriticPointNetObsEncoder``).
"""

from __future__ import annotations

import pinocchio  # noqa: F401  (Pinocchio import order)

import argparse
import os
import sys
from datetime import datetime

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

# Register gym task id before ``gym.make``.
import cxy_project.envs.g1_pick_place.task_registration  # noqa: F401

_RSL_RL_DIR = os.path.join(_REPO_ROOT, "scripts", "reinforcement_learning", "rsl_rl")
if _RSL_RL_DIR not in sys.path:
    sys.path.insert(0, _RSL_RL_DIR)

from isaaclab.app import AppLauncher

import cli_args  # isort: skip


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Warm-start PPO after HY NoContact obs extension.")
    p.add_argument(
        "--task",
        type=str,
        default="CXY-G1-Inspire-Pick-Lift-PPO-HY-Nocontact-v0",
        help="Must be HY NoContact task id.",
    )
    p.add_argument("--num_envs", type=int, default=None, help="Number of environments to simulate.")
    p.add_argument("--seed", type=int, default=None, help="Seed used for the environment")
    p.add_argument("--max_iterations", type=int, default=200, help="Finetune iterations after warm-start.")
    p.add_argument(
        "--warmstart",
        type=str,
        required=True,
        help="Path to old checkpoint .pt (e.g., model_4500.pt) to warm-start from.",
    )
    p.add_argument("--video", action="store_true", default=False, help="Record videos during training.")
    p.add_argument("--video_length", type=int, default=200, help="Length of the recorded video (in steps).")
    p.add_argument("--video_interval", type=int, default=2000, help="Interval between video recordings (in steps).")
    p.add_argument("--export_io_descriptors", action="store_true", default=False, help="Export IO descriptors.")
    cli_args.add_rsl_rl_args(p)
    AppLauncher.add_app_launcher_args(p)
    return p.parse_args()


def _expand_linear_in(
    state: dict[str, "torch.Tensor"],
    weight_key: str,
    bias_key: str | None,
    new_in: int,
) -> None:
    import torch

    w = state[weight_key]
    if w.ndim != 2:
        raise ValueError(f"{weight_key} expected 2D weight, got {tuple(w.shape)}")
    old_in = int(w.shape[1])
    if new_in == old_in:
        return
    if new_in < old_in:
        raise ValueError(f"{weight_key} cannot shrink in-dim {old_in} -> {new_in}")
    new_w = torch.zeros((w.shape[0], new_in), device=w.device, dtype=w.dtype)
    new_w[:, :old_in] = w
    state[weight_key] = new_w
    # bias does not depend on input dim
    if bias_key is not None and bias_key not in state:
        raise KeyError(f"Expected bias key {bias_key} for {weight_key}")


def _expand_empirical_norm_buffers(state: dict[str, "torch.Tensor"], prefix: str, new_dim: int) -> None:
    import torch

    mean_k = f"{prefix}._mean"
    var_k = f"{prefix}._var"
    std_k = f"{prefix}._std"
    count_k = f"{prefix}.count"

    for k in (mean_k, var_k, std_k, count_k):
        if k not in state:
            raise KeyError(f"Missing {k} in checkpoint state_dict; cannot warm-start obs normalization.")

    mean = state[mean_k]
    var = state[var_k]
    std = state[std_k]
    if mean.ndim != 2 or var.ndim != 2 or std.ndim != 2:
        raise ValueError(f"{prefix} buffers expected shape (1, D); got mean={mean.shape} var={var.shape} std={std.shape}")
    old_dim = int(mean.shape[1])
    if new_dim == old_dim:
        return
    if new_dim < old_dim:
        raise ValueError(f"{prefix} cannot shrink dim {old_dim} -> {new_dim}")

    new_mean = torch.zeros((1, new_dim), device=mean.device, dtype=mean.dtype)
    new_var = torch.ones((1, new_dim), device=var.device, dtype=var.dtype)
    new_std = torch.ones((1, new_dim), device=std.device, dtype=std.dtype)
    new_mean[:, :old_dim] = mean
    new_var[:, :old_dim] = var
    new_std[:, :old_dim] = std
    state[mean_k] = new_mean
    state[var_k] = new_var
    state[std_k] = new_std
    # keep count as-is


def _warmstart_patch_state_dict(old_state: dict[str, "torch.Tensor"], new_state_template: dict[str, "torch.Tensor"]) -> dict:
    """Patch old_state in a copy so it matches new_state_template input dims."""
    import copy

    patched = copy.deepcopy(old_state)

    def _require(k: str) -> None:
        if k not in patched:
            raise KeyError(f"Checkpoint missing key: {k}")
        if k not in new_state_template:
            raise KeyError(f"New policy missing key: {k} (unexpected architecture change)")

    # Actor first linear
    _require("actor.0.weight")
    _require("actor.0.bias")
    new_actor_in = int(new_state_template["actor.0.weight"].shape[1])
    _expand_linear_in(patched, "actor.0.weight", "actor.0.bias", new_in=new_actor_in)

    # Critic first linear
    _require("critic.0.weight")
    _require("critic.0.bias")
    new_critic_in = int(new_state_template["critic.0.weight"].shape[1])
    _expand_linear_in(patched, "critic.0.weight", "critic.0.bias", new_in=new_critic_in)

    # EmpiricalNormalization buffers
    _expand_empirical_norm_buffers(patched, "actor_obs_normalizer", new_dim=new_state_template["actor_obs_normalizer._mean"].shape[1])
    _expand_empirical_norm_buffers(patched, "critic_obs_normalizer", new_dim=new_state_template["critic_obs_normalizer._mean"].shape[1])

    return patched


def main() -> None:
    args_cli = _parse_args()
    if "Nocontact" not in str(args_cli.task):
        raise ValueError("This warm-start script is intended for HY NoContact task only. Use --task ...HY-Nocontact-v0")

    if args_cli.video:
        args_cli.enable_cameras = True

    app_launcher = AppLauncher(args_cli)
    simulation_app = app_launcher.app

    import gymnasium as gym
    import time
    import torch
    import rsl_rl.runners.on_policy_runner as rsl_on_policy_runner
    from rsl_rl.runners import OnPolicyRunner

    from cxy_project.envs.g1_pick_place.agents.actor_critic_pointnet_obs import ActorCriticPointNetObsEncoder
    from cxy_project.envs.g1_pick_place.agents.rsl_rl_ppo_cfg import G1PickPPORunnerCfg
    from cxy_project.envs.g1_pick_place.pickplace_g1_inspire_ppo_hy_env_cfg import G1InspirePickPPOHyNoContactEnvCfg

    from isaaclab.envs import DirectMARLEnv, ManagerBasedRLEnvCfg, multi_agent_to_single_agent
    from isaaclab.utils.dict import print_dict
    from isaaclab.utils.io import dump_yaml
    from isaaclab_rl.rsl_rl import RslRlVecEnvWrapper

    # Inject our ActorCritic implementation into rsl_rl
    rsl_on_policy_runner.ActorCriticPointNetObsEncoder = ActorCriticPointNetObsEncoder

    # Build cfgs
    env_cfg = G1InspirePickPPOHyNoContactEnvCfg()
    agent_cfg = G1PickPPORunnerCfg()
    agent_cfg = cli_args.update_rsl_rl_cfg(agent_cfg, args_cli)
    # Rollout length and checkpoint cadence (warm-start finetune defaults).
    agent_cfg.num_steps_per_env = 64
    agent_cfg.save_interval = 60

    if args_cli.num_envs is not None:
        env_cfg.scene.num_envs = int(args_cli.num_envs)
    agent_cfg.max_iterations = int(args_cli.max_iterations)
    if args_cli.seed is not None:
        env_cfg.seed = int(args_cli.seed)
        agent_cfg.seed = int(args_cli.seed)
    env_cfg.seed = agent_cfg.seed
    env_cfg.sim.device = args_cli.device if args_cli.device is not None else env_cfg.sim.device

    # logging dir
    log_root_path = os.path.join("logs", "rsl_rl", agent_cfg.experiment_name)
    log_root_path = os.path.abspath(log_root_path)
    log_dir = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    if agent_cfg.run_name:
        log_dir += f"_{agent_cfg.run_name}"
    log_dir = os.path.join(log_root_path, log_dir)
    print(f"[INFO] Logging experiment in directory: {log_dir}")

    if isinstance(env_cfg, ManagerBasedRLEnvCfg):
        env_cfg.export_io_descriptors = args_cli.export_io_descriptors
    env_cfg.log_dir = log_dir

    env = gym.make(args_cli.task, cfg=env_cfg, render_mode="rgb_array" if args_cli.video else None)
    if isinstance(env.unwrapped, DirectMARLEnv):
        env = multi_agent_to_single_agent(env)

    if args_cli.video:
        video_kwargs = {
            "video_folder": os.path.join(log_dir, "videos", "train"),
            "step_trigger": lambda step: step % args_cli.video_interval == 0,
            "video_length": args_cli.video_length,
            "disable_logger": True,
        }
        print("[INFO] Recording videos during training.")
        print_dict(video_kwargs, nesting=4)
        env = gym.wrappers.RecordVideo(env, **video_kwargs)

    start_time = time.time()
    env = RslRlVecEnvWrapper(env, clip_actions=agent_cfg.clip_actions)

    runner = OnPolicyRunner(env, agent_cfg.to_dict(), log_dir=log_dir, device=agent_cfg.device)
    runner.add_git_repo_to_log(__file__)

    # Warm-start load (patch old state dict to new dims)
    ckpt_path = os.path.abspath(os.path.expanduser(args_cli.warmstart))
    if not os.path.isfile(ckpt_path):
        raise FileNotFoundError(ckpt_path)
    loaded = torch.load(ckpt_path, weights_only=False, map_location=agent_cfg.device)
    old_state = loaded["model_state_dict"]
    new_template = runner.alg.policy.state_dict()
    patched_state = _warmstart_patch_state_dict(old_state, new_template)
    # Note: rsl_rl ActorCritic overrides load_state_dict and returns a bool (resumed_training) in this version.
    resumed_training = runner.alg.policy.load_state_dict(patched_state, strict=False)
    print(f"[INFO] Warm-start loaded from: {ckpt_path}")
    print(f"[INFO] resumed_training={bool(resumed_training)} (ActorCritic.load_state_dict return value)")

    # Dump configs
    try:
        dump_yaml(os.path.join(log_dir, "params", "env.yaml"), env_cfg)
    except Exception as exc:
        print(f"[WARN] Skipping env.yaml dump: {exc}")
    dump_yaml(os.path.join(log_dir, "params", "agent.yaml"), agent_cfg)

    runner.learn(num_learning_iterations=agent_cfg.max_iterations, init_at_random_ep_len=True)

    print(f"Training time: {round(time.time() - start_time, 2)} seconds")
    env.close()
    simulation_app.close()


if __name__ == "__main__":
    main()

