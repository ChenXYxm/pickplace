#!/usr/bin/env python3
# Copyright (c) 2022-2026, The Isaac Lab Project Developers.
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Replay a saved play HDF5 (obs/actions) produced by ``play_g1_pick_place_ppo.py``.

This script replays the recorded **action sequence** in a fresh environment instance (num_envs=1).
If the episode group contains ``init_state/objects/<name>/`` (``root_pos_w``, ``root_quat_w``,
``root_lin_vel_w``, ``root_ang_vel_w``) as written by ``play_g1_pick_place_ppo.py``, those rigid-body
roots are applied after the first reset so object placement matches the recording.

Example (from Isaac Lab repo root)::

    # SSH / 无图形界面：必须加 ``--headless``，否则常卡在启动或异常退出（与是否 ``--video`` 无关）。
    ./isaaclab.sh -p cxy_project/scripts/replay_play_obs_hdf5.py \\
      --hdf5 logs/play_obs_env0.hdf5 \\
      --episode 0 \\
      --task CXY-G1-Inspire-Pick-Lift-PPO-HY-Nocontact-v0 \\
      --headless

    # 本机有显示器、需要录屏时再开 ``--video``（会自动打开 ``--enable_cameras``）
    ./isaaclab.sh -p cxy_project/scripts/replay_play_obs_hdf5.py \\
      --hdf5 logs/play_obs_env0.hdf5 \\
      --episode 0 \\
      --task CXY-G1-Inspire-Pick-Lift-PPO-HY-Nocontact-v0 \\
      --video --video_length 800
"""

from __future__ import annotations

import pinocchio  # noqa: F401  (Pinocchio import order)

import argparse
import os
import sys

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

import cxy_project.envs.g1_pick_place.task_registration  # noqa: F401

from isaaclab.app import AppLauncher


def _warn_headless_if_no_display(args: argparse.Namespace) -> None:
    """GUI mode without DISPLAY often blocks or crashes on Linux (e.g. SSH); unrelated to --video."""
    if getattr(args, "headless", False):
        return
    if not sys.platform.startswith("linux"):
        return
    display = os.environ.get("DISPLAY", "").strip()
    if display:
        return
    print(
        "[WARN] No DISPLAY on Linux: Isaac Sim is starting in GUI mode and may hang or exit on SSH / "
        "headless hosts. Re-run with --headless (or use X11 forwarding / a local desktop session).",
        file=sys.stderr,
    )


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Replay play_obs_env0.hdf5 actions in Isaac Lab.")
    p.add_argument("--hdf5", type=str, required=True, help="Path to HDF5 produced by play_g1_pick_place_ppo.py")
    p.add_argument("--episode", type=int, default=0, help="Episode index under /episodes (default: 0)")
    p.add_argument(
        "--task",
        type=str,
        default="CXY-G1-Inspire-Pick-Lift-PPO-HY-Nocontact-v0",
        help="Gym task id to instantiate for replay (must match action dims).",
    )
    p.add_argument("--num_envs", type=int, default=1, help="Must be 1 for replay.")
    p.add_argument("--max_steps", type=int, default=0, help="Optional cap; 0 = use full episode length.")
    p.add_argument("--video", action="store_true", default=False, help="Record a replay video.")
    p.add_argument("--video_length", type=int, default=600, help="Video length when --video is set.")
    p.add_argument("--video-closeup", action="store_true", default=False, help="Use the close-up viewer config.")
    AppLauncher.add_app_launcher_args(p)
    return p.parse_args()


def main() -> None:
    args = _parse_args()
    if args.num_envs != 1:
        raise ValueError("--num_envs must be 1 for replay.")

    _warn_headless_if_no_display(args)

    if args.video:
        args.enable_cameras = True
    app_launcher = AppLauncher(args)
    simulation_app = app_launcher.app

    import h5py
    import gymnasium as gym
    import numpy as np
    import torch

    from isaaclab.envs.common import ViewerCfg
    from isaaclab_rl.rsl_rl import RslRlVecEnvWrapper

    from cxy_project.envs.g1_pick_place.pickplace_g1_inspire_ppo_hy_env_cfg import (
        G1InspirePickPPOHyEnvCfg,
        G1InspirePickPPOHyNoContactEnvCfg,
    )
    from cxy_project.envs.g1_pick_place.multi_hy_constants import THREE_HY_ASSET_NAMES

    h5_path = os.path.abspath(os.path.expanduser(args.hdf5))
    if not os.path.isfile(h5_path):
        raise FileNotFoundError(h5_path)

    with h5py.File(h5_path, "r") as h5:
        if "episodes" not in h5:
            raise KeyError("HDF5 missing group 'episodes'. Re-run play with --hdf5-episodic.")
        eps_root = h5["episodes"]
        ep_name = f"ep_{int(args.episode):06d}"
        if ep_name not in eps_root:
            raise KeyError(f"Episode {args.episode} not found; available: {list(eps_root.keys())[:10]} ...")
        ep = eps_root[ep_name]
        actions_np = np.asarray(ep["actions"])
        # (T, action_dim)
        if actions_np.ndim != 2:
            raise RuntimeError(f"Expected actions (T, A), got {actions_np.shape}")
        target_name = ep.attrs.get("target_object_name", "unknown")
        print(f"[INFO] Loaded {ep_name}: actions={actions_np.shape} target_object={target_name!r}")

        init_objects: dict[str, dict[str, np.ndarray]] = {}
        if "init_state" in ep and "objects" in ep["init_state"]:
            obj_root = ep["init_state"]["objects"]
            required = ("root_pos_w", "root_quat_w", "root_lin_vel_w", "root_ang_vel_w")
            for oname in obj_root.keys():
                g = obj_root[oname]
                if not all(k in g for k in required):
                    print(f"[WARN] init_state/objects/{oname} missing one of {required}; skip")
                    continue
                init_objects[str(oname)] = {k: np.asarray(g[k]) for k in required}
        else:
            print(
                "[WARN] HDF5 has no init_state/objects; object poses will follow env reset only "
                "(replay may diverge from the original run)."
            )

    # Build env cfg (match play script pattern)
    if "Nocontact" in args.task or "Nocontact" in str(args.task):
        env_cfg = G1InspirePickPPOHyNoContactEnvCfg()
    else:
        env_cfg = G1InspirePickPPOHyEnvCfg()

    env_cfg.scene.num_envs = 1
    env_cfg.sim.device = args.device if args.device is not None else env_cfg.sim.device

    if args.video and args.video_closeup:
        env_cfg.viewer = ViewerCfg(
            origin_type="asset_body",
            asset_name="robot",
            body_name="right_wrist_yaw_link",
            env_index=0,
            eye=(0.52, -0.42, 1.32),
            lookat=(0.0, 0.18, -0.06),
            resolution=(1920, 1080),
        )
    elif args.video:
        env_cfg.viewer = ViewerCfg(
            eye=(-0.1, 1.5, 2.5),
            lookat=(-0.1, 0.36, 1.01),
            resolution=(1920, 1080),
        )

    env = gym.make(args.task, cfg=env_cfg, render_mode="rgb_array" if args.video else None)
    if args.video:
        video_kwargs = {
            "video_folder": os.path.join(os.getcwd(), "logs", "replay_videos"),
            "step_trigger": lambda step: step == 0,
            "video_length": int(min(args.video_length, actions_np.shape[0])),
            "disable_logger": True,
        }
        env = gym.wrappers.RecordVideo(env, **video_kwargs)

    env = RslRlVecEnvWrapper(env, clip_actions=None)
    obs = env.get_observations()

    # Restore recorded HY rigid roots (after reset / first obs) so objects match the HDF5 episode.
    if init_objects:
        scene = getattr(env.unwrapped, "scene", None)
        dev = env.unwrapped.device
        eid = torch.tensor([0], device=dev, dtype=torch.long)
        applied = 0
        for oname in THREE_HY_ASSET_NAMES:
            if oname not in init_objects:
                continue
            if scene is None or oname not in scene.rigid_objects:
                print(f"[WARN] Cannot apply init_state for {oname!r}: not in scene")
                continue
            d = init_objects[oname]
            obj = scene.rigid_objects[oname]
            pos = torch.as_tensor(d["root_pos_w"], device=dev, dtype=torch.float32).reshape(1, 3)
            quat = torch.as_tensor(d["root_quat_w"], device=dev, dtype=torch.float32).reshape(1, 4)
            pose = torch.cat([pos, quat], dim=-1)
            lin = torch.as_tensor(d["root_lin_vel_w"], device=dev, dtype=torch.float32).reshape(1, 3)
            ang = torch.as_tensor(d["root_ang_vel_w"], device=dev, dtype=torch.float32).reshape(1, 3)
            vel = torch.cat([lin, ang], dim=-1)
            obj.write_root_pose_to_sim(pose, env_ids=eid)
            obj.write_root_link_velocity_to_sim(vel, env_ids=eid)
            applied += 1
        print(f"[INFO] Applied init_state for {applied} rigid object(s).")

    # Replay actions
    T = actions_np.shape[0]
    max_steps = int(args.max_steps) if int(args.max_steps) > 0 else T
    max_steps = min(max_steps, T)
    for t in range(max_steps):
        if not simulation_app.is_running():
            break
        a = torch.from_numpy(actions_np[t]).to(device=env.unwrapped.device, dtype=torch.float32).unsqueeze(0)
        obs, _rew, dones, _extras = env.step(a)
        if int(dones[0].item()) == 1:
            break

    env.close()
    simulation_app.close()


if __name__ == "__main__":
    main()

