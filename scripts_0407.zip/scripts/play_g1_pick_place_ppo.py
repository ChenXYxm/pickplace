# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Load an RSL-RL checkpoint and run inference (play) on CXY G1 Inspire HY pick/lift tasks.

Aligned with ``train_g1_pick_place_ppo.py`` (no Hydra; same env cfg construction + Pinocchio import order).

Use conda env ``env_isaaclab`` so ``./isaaclab.sh -p`` resolves Isaac Sim / Pinocchio (recommended)::

    ./cxy_project/scripts/run_play_g1_pick_place_ppo_env_isaaclab.sh \\
      --task CXY-G1-Inspire-Pick-Lift-PPO-HY-v0 \\
      --checkpoint /path/to/model.pt --num_envs 1

Or after ``conda activate env_isaaclab``, from the Isaac Lab repo root::

    ./isaaclab.sh -p cxy_project/scripts/play_g1_pick_place_ppo.py \\
      --task CXY-G1-Inspire-Pick-Lift-PPO-HY-v0 \\
      --load_run 2026-03-31_12-00-00 \\
      --checkpoint model_120.pt \\
      --num_envs 1

Record one video clip (under ``<run>/videos/play/``)::

    ./isaaclab.sh -p cxy_project/scripts/play_g1_pick_place_ppo.py \\
      --task CXY-G1-Inspire-Pick-Lift-PPO-HY-Nocontact-v0 \\
      --load_run <run_dir_name> \\
      --checkpoint model_120.pt \\
      --num_envs 1 --video --video_length 800 --video-closeup

Absolute path to a ``.pt`` file::

    ./isaaclab.sh -p cxy_project/scripts/play_g1_pick_place_ppo.py \\
      --task CXY-G1-Inspire-Pick-Lift-PPO-HY-v0 \\
      --checkpoint /abs/path/to/model_120.pt \\
      --num_envs 1
"""

from __future__ import annotations

import pinocchio  # load before Isaac Lab / Pink (Pinocchio 3 import order); keep first after __future__

import argparse
import os
import sys

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

import cxy_project.envs.g1_pick_place.task_registration  # noqa: F401

_RSL_RL_DIR = os.path.join(_REPO_ROOT, "scripts", "reinforcement_learning", "rsl_rl")
if _RSL_RL_DIR not in sys.path:
    sys.path.insert(0, _RSL_RL_DIR)

from isaaclab.app import AppLauncher

import cli_args  # isort: skip

parser = argparse.ArgumentParser(description="Play (inference) CXY G1 Inspire pick/lift PPO checkpoint.")
parser.add_argument("--video", action="store_true", default=False, help="Record a video clip under the checkpoint run.")
parser.add_argument(
    "--video_length",
    type=int,
    default=600,
    help="Env steps to record / play when --video is set (default: 600, longer clip).",
)
parser.add_argument(
    "--video-closeup",
    action="store_true",
    default=False,
    help="Use a close-up viewport: camera tracks right wrist (asset_body) with short eye/lookat offsets.",
)
parser.add_argument("--num_envs", type=int, default=1, help="Number of parallel environments.")
parser.add_argument(
    "--task",
    type=str,
    default="CXY-G1-Inspire-Pick-Lift-PPO-HY-v0",
    help="Gym task id (must match training).",
)
parser.add_argument("--seed", type=int, default=None, help="Seed for the environment.")
parser.add_argument(
    "--real-time",
    action="store_true",
    default=False,
    help="Sleep between steps to approximate real-time playback (single-env friendly).",
)
parser.add_argument(
    "--max-steps",
    type=int,
    default=0,
    help="Stop after this many env steps when not using --video (0 = run until the app closes).",
)
parser.add_argument(
    "--no-export",
    action="store_true",
    default=False,
    help="Skip exporting policy JIT/ONNX next to the checkpoint.",
)
parser.add_argument(
    "--hdf5",
    type=str,
    default="",
    help="If set, append observations/actions to this HDF5 file during play (path to .hdf5).",
)
parser.add_argument(
    "--hdf5-env-index",
    type=int,
    default=0,
    help="Which environment index to record into HDF5 (default: 0).",
)
parser.add_argument(
    "--hdf5-episodic",
    action="store_true",
    default=False,
    help="If set, store HDF5 under episodes/ep_XXXXXX/* and split when dones[env_index] == 1.",
)
parser.add_argument(
    "--hdf5-include-extras",
    action="store_true",
    default=False,
    help="Include extras dict entries in the HDF5 (when they are tensors/arrays).",
)
parser.add_argument(
    "--cxy-net-use-full-force",
    action="store_true",
    default=False,
    help="HY task only: net contact fallback uses full ||F|| instead of horizontal ||(Fx,Fy)||.",
)
cli_args.add_rsl_rl_args(parser)
AppLauncher.add_app_launcher_args(parser)
args_cli = parser.parse_args()

if args_cli.video:
    args_cli.enable_cameras = True

app_launcher = AppLauncher(args_cli)
simulation_app = app_launcher.app

import importlib.metadata as metadata
import platform
import time

from packaging import version

RSL_RL_VERSION = "3.0.1"
installed_version = metadata.version("rsl-rl-lib")
if version.parse(installed_version) < version.parse(RSL_RL_VERSION):
    if platform.system() == "Windows":
        cmd = [r".\isaaclab.bat", "-p", "-m", "pip", "install", f"rsl-rl-lib=={RSL_RL_VERSION}"]
    else:
        cmd = ["./isaaclab.sh", "-p", "-m", "pip", "install", f"rsl-rl-lib=={RSL_RL_VERSION}"]
    print(
        f"Please install the correct version of RSL-RL.\nExisting version is: '{installed_version}'"
        f" and required version is: '{RSL_RL_VERSION}'.\nTo install the correct version, run:"
        f"\n\n\t{' '.join(cmd)}\n"
    )
    raise SystemExit(1)

import logging

import gymnasium as gym
import torch
import rsl_rl.runners.on_policy_runner as rsl_on_policy_runner
from rsl_rl.runners import DistillationRunner, OnPolicyRunner

from cxy_project.envs.g1_pick_place.agents.actor_critic_pointnet_obs import ActorCriticPointNetObsEncoder

rsl_on_policy_runner.ActorCriticPointNetObsEncoder = ActorCriticPointNetObsEncoder

from isaaclab.envs import DirectMARLEnv, multi_agent_to_single_agent
from isaaclab.envs.common import ViewerCfg
from isaaclab.utils.assets import retrieve_file_path
from isaaclab.utils.dict import print_dict

from isaaclab_rl.rsl_rl import RslRlVecEnvWrapper, export_policy_as_jit, export_policy_as_onnx

from isaaclab_tasks.utils import get_checkpoint_path

from cxy_project.envs.g1_pick_place.agents.rsl_rl_ppo_cfg import G1PickPPORunnerCfg
from cxy_project.envs.g1_pick_place.pickplace_g1_inspire_ppo_hy_env_cfg import (
    G1InspirePickPPOHyEnvCfg,
    G1InspirePickPPOHyNoContactEnvCfg,
)
from cxy_project.envs.g1_pick_place.multi_hy_constants import THREE_HY_ASSET_NAMES

HY_PPO_TASK_NOCONTACT = "CXY-G1-Inspire-Pick-Lift-PPO-HY-Nocontact-v0"

logger = logging.getLogger(__name__)

def _h5_ensure_dataset(h5, name: str, sample: "torch.Tensor", *, chunks: bool = True):
    """Create or fetch a resizable dataset of shape (T, ...) matching ``sample.shape`` (without T)."""
    import numpy as np

    arr = sample.detach().to("cpu")
    if arr.dtype == torch.bfloat16:
        arr = arr.to(torch.float32)
    np_arr = arr.numpy()
    if name in h5:
        return h5[name]
    maxshape = (None,) + np_arr.shape
    dset = h5.create_dataset(
        name,
        shape=(0,) + np_arr.shape,
        maxshape=maxshape,
        dtype=np_arr.dtype,
        chunks=((1,) + np_arr.shape) if chunks else None,
        compression="gzip",
        compression_opts=4,
    )
    return dset


def _h5_append(dset, value: "torch.Tensor"):
    v = value.detach().to("cpu")
    if v.dtype == torch.bfloat16:
        v = v.to(torch.float32)
    np_v = v.numpy()
    t = dset.shape[0]
    dset.resize((t + 1,) + dset.shape[1:])
    dset[t] = np_v


def _selected_target_object_name(env_unwrapped, env_i: int) -> tuple[int | None, str]:
    """Best-effort: return (target_index, target_name) for a given env index."""
    try:
        idx = getattr(env_unwrapped, "_cxy_target_object_idx", None)
        if idx is None:
            return None, "unknown"
        if hasattr(idx, "detach"):
            idx_i = int(idx[env_i].detach().to("cpu").item())
        else:
            idx_i = int(idx[env_i])
        idx_i = max(0, min(idx_i, len(THREE_HY_ASSET_NAMES) - 1))
        return idx_i, str(THREE_HY_ASSET_NAMES[idx_i])
    except Exception:
        return None, "unknown"


def _h5_record_hy_objects_initial_state(h5_group, env_unwrapped, env_i: int) -> None:
    """Record HY rigid-body root states for a single env index under init_state/objects/*."""
    import numpy as np

    obj_root = h5_group.require_group("init_state").require_group("objects")
    scene = getattr(env_unwrapped, "scene", None)
    if scene is None:
        return
    for name in THREE_HY_ASSET_NAMES:
        if name not in scene.rigid_objects:
            continue
        obj = scene.rigid_objects[name]
        g = obj_root.require_group(str(name))
        # root pose
        pos = obj.data.root_pos_w[env_i, :3].detach().to("cpu").numpy()
        quat = obj.data.root_quat_w[env_i, :4].detach().to("cpu").numpy()
        lin = obj.data.root_lin_vel_w[env_i, :3].detach().to("cpu").numpy()
        ang = obj.data.root_ang_vel_w[env_i, :3].detach().to("cpu").numpy()
        # overwrite if rerun in same file/group
        for k, v in {
            "root_pos_w": pos.astype(np.float32, copy=False),
            "root_quat_w": quat.astype(np.float32, copy=False),
            "root_lin_vel_w": lin.astype(np.float32, copy=False),
            "root_ang_vel_w": ang.astype(np.float32, copy=False),
        }.items():
            if k in g:
                del g[k]
            g.create_dataset(k, data=v, compression="gzip", compression_opts=4)


def _resolve_checkpoint_path(log_root_path: str, agent_cfg) -> str:
    """Resolve checkpoint: absolute file path, or ``get_checkpoint_path`` with load_run / regex."""
    ckpt = agent_cfg.load_checkpoint
    load_run = agent_cfg.load_run
    if ckpt:
        expanded = os.path.abspath(os.path.expanduser(ckpt))
        if os.path.isfile(expanded):
            return expanded
        try:
            return retrieve_file_path(ckpt)
        except (FileNotFoundError, OSError, RuntimeError):
            pass
    pattern = ckpt if ckpt else ".*"
    return get_checkpoint_path(log_root_path, load_run if load_run else ".*", pattern)


def main() -> None:
    if args_cli.task == HY_PPO_TASK_NOCONTACT:
        env_cfg = G1InspirePickPPOHyNoContactEnvCfg()
        logger.info("HY env: %s (no contact-force reward terms).", HY_PPO_TASK_NOCONTACT)
    else:
        env_cfg = G1InspirePickPPOHyEnvCfg()
        if args_cli.cxy_net_use_full_force:
            env_cfg.cxy_contact_net_use_horizontal = False

    agent_cfg = G1PickPPORunnerCfg()
    agent_cfg = cli_args.update_rsl_rl_cfg(agent_cfg, args_cli)
    agent_cfg.num_steps_per_env = 128

    env_cfg.scene.num_envs = args_cli.num_envs if args_cli.num_envs is not None else env_cfg.scene.num_envs
    env_cfg.seed = agent_cfg.seed
    env_cfg.sim.device = args_cli.device if args_cli.device is not None else env_cfg.sim.device

    log_root_path = os.path.abspath(os.path.join("logs", "rsl_rl", agent_cfg.experiment_name))
    print(f"[INFO] Experiment log root: {log_root_path}")

    resume_path = _resolve_checkpoint_path(log_root_path, agent_cfg)
    print(f"[INFO] Loading checkpoint: {resume_path}")

    log_dir = os.path.dirname(resume_path)
    env_cfg.log_dir = log_dir

    if args_cli.video and args_cli.video_closeup:
        # Camera eye/target are **offsets** added to the wrist body world position each render (see ViewportCameraController).
        env_cfg.viewer = ViewerCfg(
            origin_type="asset_body",
            asset_name="robot",
            body_name="right_wrist_yaw_link",
            env_index=0,
            eye=(0.52, -0.42, 1.32),
            lookat=(0.0, 0.18, -0.06),
            resolution=(1920, 1080),
        )
        logger.info("Viewer: close-up tracking right_wrist_yaw_link (1920x1080).")
    elif args_cli.video:
        # World-frame shot: x=-0.1 and pull back further along +y for a wider view of the workspace.
        env_cfg.viewer = ViewerCfg(
            eye=(-0.1, 1.5, 2.5),
            lookat=(-0.1, 0.36, 1.01),
            resolution=(1920, 1080),
        )
        logger.info("Viewer: world-frame wider shot at x=-0.1 with +y pullback (1920x1080).")

    env = gym.make(args_cli.task, cfg=env_cfg, render_mode="rgb_array" if args_cli.video else None)

    if isinstance(env.unwrapped, DirectMARLEnv):
        env = multi_agent_to_single_agent(env)

    if args_cli.video:
        video_kwargs = {
            "video_folder": os.path.join(log_dir, "videos", "play"),
            "step_trigger": lambda step: step == 0,
            "video_length": args_cli.video_length,
            "disable_logger": True,
        }
        print("[INFO] Recording video.")
        print_dict(video_kwargs, nesting=4)
        env = gym.wrappers.RecordVideo(env, **video_kwargs)

    env = RslRlVecEnvWrapper(env, clip_actions=agent_cfg.clip_actions)

    if agent_cfg.class_name == "OnPolicyRunner":
        runner = OnPolicyRunner(env, agent_cfg.to_dict(), log_dir=None, device=agent_cfg.device)
    elif agent_cfg.class_name == "DistillationRunner":
        runner = DistillationRunner(env, agent_cfg.to_dict(), log_dir=None, device=agent_cfg.device)
    else:
        raise ValueError(f"Unsupported runner class: {agent_cfg.class_name}")

    runner.load(resume_path)

    policy = runner.get_inference_policy(device=env.unwrapped.device)

    try:
        policy_nn = runner.alg.policy
    except AttributeError:
        policy_nn = runner.alg.actor_critic

    if hasattr(policy_nn, "actor_obs_normalizer"):
        normalizer = policy_nn.actor_obs_normalizer
    elif hasattr(policy_nn, "student_obs_normalizer"):
        normalizer = policy_nn.student_obs_normalizer
    else:
        normalizer = None

    if not args_cli.no_export:
        export_model_dir = os.path.join(os.path.dirname(resume_path), "exported")
        try:
            export_policy_as_jit(policy_nn, normalizer=normalizer, path=export_model_dir, filename="policy.pt")
            export_policy_as_onnx(policy_nn, normalizer=normalizer, path=export_model_dir, filename="policy.onnx")
            print(f"[INFO] Exported JIT/ONNX under: {export_model_dir}")
        except Exception as exc:
            logger.warning("Policy export skipped: %s", exc)

    dt = env.unwrapped.step_dt
    obs = env.get_observations()
    timestep = 0

    h5 = None
    h5_path = None
    h5_group = None
    h5_ep_idx = 0
    try:
        if args_cli.hdf5:
            import h5py

            h5_path = os.path.abspath(os.path.expanduser(args_cli.hdf5))
            os.makedirs(os.path.dirname(h5_path), exist_ok=True)
            h5 = h5py.File(h5_path, "w")
            h5.attrs["task"] = str(args_cli.task)
            h5.attrs["checkpoint"] = str(resume_path)
            h5.attrs["num_envs"] = int(env.unwrapped.num_envs)
            h5.attrs["step_dt"] = float(dt)
            h5.attrs["env_index"] = int(args_cli.hdf5_env_index)
            h5.attrs["episodic"] = bool(args_cli.hdf5_episodic)
            print(f"[INFO] Recording observations to HDF5: {h5_path}")

            env_i = int(args_cli.hdf5_env_index)
            if env_i < 0 or env_i >= int(env.unwrapped.num_envs):
                raise ValueError(f"--hdf5-env-index out of range: {env_i} (num_envs={env.unwrapped.num_envs})")

            if args_cli.hdf5_episodic:
                eps_root = h5.require_group("episodes")
                h5_group = eps_root.create_group(f"ep_{h5_ep_idx:06d}")
                h5_group.attrs["env_index"] = env_i
                h5_group.attrs["start_step"] = 0
                obj_idx, obj_name = _selected_target_object_name(env.unwrapped, env_i)
                if obj_idx is not None:
                    h5_group.attrs["target_object_index"] = int(obj_idx)
                h5_group.attrs["target_object_name"] = str(obj_name)
                _h5_record_hy_objects_initial_state(h5_group, env.unwrapped, env_i)
                # Save initial obs (t=0) for this episode.
                for k in obs.keys():
                    v = obs.get(k)
                    if isinstance(v, torch.Tensor):
                        v0 = v[env_i]
                        h5_group.create_dataset(f"obs0/{k}", data=v0.detach().to("cpu").numpy(), compression="gzip", compression_opts=4)
            else:
                h5_group = h5
                # Pre-create datasets from initial obs keys (env-index sliced)
                for k in obs.keys():
                    v = obs.get(k)
                    if isinstance(v, torch.Tensor):
                        _h5_ensure_dataset(h5_group, f"obs/{k}", v[env_i])

        while simulation_app.is_running():
            start = time.time()
            with torch.inference_mode():
                actions = policy(obs)
                obs, rew, dones, extras = env.step(actions)
                policy_nn.reset(dones)

            timestep += 1

            if h5 is not None:
                env_i = int(args_cli.hdf5_env_index)
                done_i = int(dones[env_i].item()) == 1

                # If episodic mode is enabled and this step ended the episode for env_i, Isaac Lab typically
                # returns the first observation of the *next* episode (post-reset) in `obs`.
                # To be strict about "reset后的第一帧obs", we store that as `obs0/*` for the next episode and
                # do NOT append it to the previous episode's `obs/*` sequence.
                if args_cli.hdf5_episodic and done_i:
                    _h5_append(_h5_ensure_dataset(h5_group, "actions", actions[env_i]), actions[env_i])
                    _h5_append(_h5_ensure_dataset(h5_group, "rewards", rew[env_i]), rew[env_i])
                    _h5_append(_h5_ensure_dataset(h5_group, "dones", dones[env_i]), dones[env_i])

                    if args_cli.hdf5_include_extras and isinstance(extras, dict):
                        for ek, ev in extras.items():
                            if isinstance(ev, torch.Tensor):
                                ev0 = ev[env_i] if ev.shape[0] == int(env.unwrapped.num_envs) else ev
                                _h5_append(_h5_ensure_dataset(h5_group, f"extras/{ek}", ev0), ev0)

                    h5_group.attrs["end_step"] = int(timestep)
                    h5_ep_idx += 1
                    eps_root = h5["episodes"]
                    h5_group = eps_root.create_group(f"ep_{h5_ep_idx:06d}")
                    h5_group.attrs["env_index"] = env_i
                    h5_group.attrs["start_step"] = int(timestep)
                    obj_idx, obj_name = _selected_target_object_name(env.unwrapped, env_i)
                    if obj_idx is not None:
                        h5_group.attrs["target_object_index"] = int(obj_idx)
                    h5_group.attrs["target_object_name"] = str(obj_name)
                    _h5_record_hy_objects_initial_state(h5_group, env.unwrapped, env_i)
                    for k in obs.keys():
                        v = obs.get(k)
                        if isinstance(v, torch.Tensor):
                            v0 = v[env_i]
                            h5_group.create_dataset(
                                f"obs0/{k}",
                                data=v0.detach().to("cpu").numpy(),
                                compression="gzip",
                                compression_opts=4,
                            )
                else:
                    # obs: TensorDict of tensors; record only env_i slice
                    for k in obs.keys():
                        v = obs.get(k)
                        if not isinstance(v, torch.Tensor):
                            continue
                        v0 = v[env_i]
                        dset = _h5_ensure_dataset(h5_group, f"obs/{k}", v0)
                        _h5_append(dset, v0)

                    _h5_append(_h5_ensure_dataset(h5_group, "actions", actions[env_i]), actions[env_i])
                    _h5_append(_h5_ensure_dataset(h5_group, "rewards", rew[env_i]), rew[env_i])
                    _h5_append(_h5_ensure_dataset(h5_group, "dones", dones[env_i]), dones[env_i])

                    if args_cli.hdf5_include_extras and isinstance(extras, dict):
                        for ek, ev in extras.items():
                            if isinstance(ev, torch.Tensor):
                                ev0 = ev[env_i] if ev.shape[0] == int(env.unwrapped.num_envs) else ev
                                _h5_append(_h5_ensure_dataset(h5_group, f"extras/{ek}", ev0), ev0)

            if args_cli.video and timestep >= args_cli.video_length:
                break
            if not args_cli.video and args_cli.max_steps > 0 and timestep >= args_cli.max_steps:
                break

            if args_cli.real_time and env_cfg.scene.num_envs == 1:
                sleep_time = dt - (time.time() - start)
                if sleep_time > 0:
                    time.sleep(sleep_time)
    finally:
        env.close()
        if h5 is not None:
            h5.close()
            print(f"[INFO] HDF5 saved: {h5_path}")


if __name__ == "__main__":
    main()
    simulation_app.close()
