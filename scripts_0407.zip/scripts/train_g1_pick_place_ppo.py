# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Train PPO (RSL-RL) on ``CXY-G1-Inspire-Pick-Lift-PPO-v0``.

Rewards: lift object toward 1.25 m world *z* + right-hand finger contact with the object.

From the Isaac Lab repo root (same pattern as ``scripts/reinforcement_learning/rsl_rl/train.py``)::

    ./isaaclab.sh -p cxy_project/scripts/train_g1_pick_place_ppo.py --headless --num_envs 4096

Ensure YCB meshes are extracted and USD cache exists (run the pick-place env once, or pre-run MeshConverter).
For the three-object task, also run ``cxy_project/scripts/extract_ycb_pointnet2_features.py`` so
``cxy_project/objects/object_pointnet2_msg_normals_256.npz`` exists (policy observation tail).

HY no-contact variant: pass ``--task CXY-G1-Inspire-Pick-Lift-PPO-HY-Nocontact-v0`` (geometry/height rewards only).

Play / checkpoint inference + optional video: ``cxy_project/scripts/play_g1_pick_place_ppo.py``
(conda ``env_isaaclab``: ``cxy_project/scripts/run_play_g1_pick_place_ppo_env_isaaclab.sh``).

This script registers the gym task via ``cxy_project.envs.g1_pick_place.task_registration``, loads env and
agent configs directly (not via Hydra) because Pink IK tasks embed numpy arrays that OmegaConf cannot store,
and reuses ``scripts/reinforcement_learning/rsl_rl/cli_args`` for RSL-RL / runner options.
"""

from __future__ import annotations

import pinocchio  # load before Isaac Lab / Pink (Pinocchio 3 import order); keep first after __future__

import argparse
import os
import sys

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

# Register gym task id before ``gym.make``.
import cxy_project.envs.g1_pick_place.task_registration  # noqa: F401

_RSL_RL_DIR = os.path.join(_REPO_ROOT, "scripts", "reinforcement_learning", "rsl_rl")
if _RSL_RL_DIR not in sys.path:
    sys.path.insert(0, _RSL_RL_DIR)

from isaaclab.app import AppLauncher

import cli_args  # isort: skip

parser = argparse.ArgumentParser(description="Train PPO (RSL-RL) on CXY G1 Inspire pick/lift.")
parser.add_argument("--video", action="store_true", default=False, help="Record videos during training.")
parser.add_argument("--video_length", type=int, default=200, help="Length of the recorded video (in steps).")
parser.add_argument("--video_interval", type=int, default=2000, help="Interval between video recordings (in steps).")
parser.add_argument("--num_envs", type=int, default=None, help="Number of environments to simulate.")
parser.add_argument(
    "--task",
    type=str,
    default="CXY-G1-Inspire-Pick-Lift-PPO-HY-v0",
    help="Gym task id (default: CXY G1 pick/lift).",
)
parser.add_argument("--seed", type=int, default=None, help="Seed used for the environment")
parser.add_argument("--max_iterations", type=int, default=None, help="RL policy training iterations.")
parser.add_argument(
    "--distributed",
    action="store_true",
    default=False,
    help="Run training with multiple GPUs or nodes.",
)
parser.add_argument("--export_io_descriptors", action="store_true", default=False, help="Export IO descriptors.")
parser.add_argument(
    "--cxy-net-use-full-force",
    action="store_true",
    default=False,
    help="HY task only: net contact fallback uses full ||F|| instead of horizontal ||(Fx,Fy)||.",
)
parser.add_argument(
    "--ray-proc-id",
    "-rid",
    type=int,
    default=None,
    help="Automatically configured by Ray integration, otherwise None.",
)
cli_args.add_rsl_rl_args(parser)
AppLauncher.add_app_launcher_args(parser)
args_cli = parser.parse_args()

if args_cli.video:
    args_cli.enable_cameras = True

app_launcher = AppLauncher(args_cli)
simulation_app = app_launcher.app

import importlib.metadata as metadata
import platform

from packaging import version

RSL_RL_VERSION = "3.0.1"
installed_version = metadata.version("rsl-rl-lib")
if version.parse(installed_version) < version.parse(RSL_RL_VERSION):
    if platform.system() == "Windows":
        cmd = [r".\isaaclab.bat", "-p", "-m", "pip", "install", f"rsl-rl-lib=={RSL_RL_VERSION}"]
    else:
        cmd = ["./isaaclab.sh", "-p", "-m", "pip", "install", f"rsl-rl-lib=={RSL_RL_VERSION}"]
    print(
        f"Please install the correct version of RSL-RL.\nExisting version is: '{installed_version}'"
        f" and required version is: '{RSL_RL_VERSION}'.\nTo install the correct version, run:"
        f"\n\n\t{' '.join(cmd)}\n"
    )
    raise SystemExit(1)

import logging
import time
from datetime import datetime

import gymnasium as gym
import torch
import rsl_rl.runners.on_policy_runner as rsl_on_policy_runner
from rsl_rl.runners import DistillationRunner, OnPolicyRunner

from cxy_project.envs.g1_pick_place.agents.actor_critic_pointnet_obs import ActorCriticPointNetObsEncoder

rsl_on_policy_runner.ActorCriticPointNetObsEncoder = ActorCriticPointNetObsEncoder

from isaaclab.envs import DirectMARLEnv, ManagerBasedRLEnvCfg, multi_agent_to_single_agent
from isaaclab.utils.dict import print_dict
from isaaclab.utils.io import dump_yaml

from isaaclab_rl.rsl_rl import RslRlVecEnvWrapper

from isaaclab_tasks.utils import get_checkpoint_path

from cxy_project.envs.g1_pick_place.agents.rsl_rl_ppo_cfg import G1PickPPORunnerCfg
from cxy_project.envs.g1_pick_place.pickplace_g1_inspire_ppo_hy_env_cfg import (
    G1InspirePickPPOHyEnvCfg,
    G1InspirePickPPOHyNoContactEnvCfg,
)

# Must match ``task_registration`` id for ``gym.make(..., cfg=...)`` — cfg class must match task.
HY_PPO_TASK_NOCONTACT = "CXY-G1-Inspire-Pick-Lift-PPO-HY-Nocontact-v0"

logger = logging.getLogger(__name__)

torch.backends.cuda.matmul.allow_tf32 = True
torch.backends.cudnn.allow_tf32 = True
torch.backends.cudnn.deterministic = False
torch.backends.cudnn.benchmark = False


def main():
    """Train with RSL-RL agent (configs constructed here to avoid Hydra/OmegaConf on Pink ndarrays)."""
    if args_cli.task == HY_PPO_TASK_NOCONTACT:
        env_cfg = G1InspirePickPPOHyNoContactEnvCfg()
        logger.info("HY env: %s (geometry/height rewards; no contact-force terms).", HY_PPO_TASK_NOCONTACT)
    else:
        env_cfg = G1InspirePickPPOHyEnvCfg()
        if args_cli.cxy_net_use_full_force:
            env_cfg.cxy_contact_net_use_horizontal = False
        logger.info(
            "HY net contact fallback: %s",
            "horizontal ||(Fx,Fy)||" if env_cfg.cxy_contact_net_use_horizontal else "full ||F||",
        )
    agent_cfg = G1PickPPORunnerCfg()
    agent_cfg = cli_args.update_rsl_rl_cfg(agent_cfg, args_cli)
    # Rollout: steps collected per environment each PPO iteration (RSL-RL ``num_steps_per_env``).
    agent_cfg.num_steps_per_env = 128
    # Checkpoint every N learning iterations (each iteration = one rollout + update; ``save_interval`` in runner).
    agent_cfg.save_interval = 60
    env_cfg.scene.num_envs = args_cli.num_envs if args_cli.num_envs is not None else env_cfg.scene.num_envs
    agent_cfg.max_iterations = (
        args_cli.max_iterations if args_cli.max_iterations is not None else agent_cfg.max_iterations
    )

    env_cfg.seed = agent_cfg.seed
    env_cfg.sim.device = args_cli.device if args_cli.device is not None else env_cfg.sim.device
    if args_cli.distributed and args_cli.device is not None and "cpu" in args_cli.device:
        raise ValueError(
            "Distributed training is not supported when using CPU device. "
            "Please use GPU device (e.g., --device cuda) for distributed training."
        )

    if args_cli.distributed:
        env_cfg.sim.device = f"cuda:{app_launcher.local_rank}"
        agent_cfg.device = f"cuda:{app_launcher.local_rank}"
        seed = agent_cfg.seed + app_launcher.local_rank
        env_cfg.seed = seed
        agent_cfg.seed = seed

    log_root_path = os.path.join("logs", "rsl_rl", agent_cfg.experiment_name)
    log_root_path = os.path.abspath(log_root_path)
    print(f"[INFO] Logging experiment in directory: {log_root_path}")
    log_dir = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    print(f"Exact experiment name requested from command line: {log_dir}")
    if agent_cfg.run_name:
        log_dir += f"_{agent_cfg.run_name}"
    log_dir = os.path.join(log_root_path, log_dir)

    if isinstance(env_cfg, ManagerBasedRLEnvCfg):
        env_cfg.export_io_descriptors = args_cli.export_io_descriptors
    else:
        logger.warning(
            "IO descriptors are only supported for manager based RL environments. No IO descriptors will be exported."
        )

    env_cfg.log_dir = log_dir

    env = gym.make(args_cli.task, cfg=env_cfg, render_mode="rgb_array" if args_cli.video else None)

    if isinstance(env.unwrapped, DirectMARLEnv):
        env = multi_agent_to_single_agent(env)

    if agent_cfg.resume or agent_cfg.algorithm.class_name == "Distillation":
        resume_path = get_checkpoint_path(log_root_path, agent_cfg.load_run, agent_cfg.load_checkpoint)

    if args_cli.video:
        video_kwargs = {
            "video_folder": os.path.join(log_dir, "videos", "train"),
            "step_trigger": lambda step: step % args_cli.video_interval == 0,
            "video_length": args_cli.video_length,
            "disable_logger": True,
        }
        print("[INFO] Recording videos during training.")
        print_dict(video_kwargs, nesting=4)
        env = gym.wrappers.RecordVideo(env, **video_kwargs)

    start_time = time.time()

    env = RslRlVecEnvWrapper(env, clip_actions=agent_cfg.clip_actions)

    if agent_cfg.class_name == "OnPolicyRunner":
        runner = OnPolicyRunner(env, agent_cfg.to_dict(), log_dir=log_dir, device=agent_cfg.device)
    elif agent_cfg.class_name == "DistillationRunner":
        runner = DistillationRunner(env, agent_cfg.to_dict(), log_dir=log_dir, device=agent_cfg.device)
    else:
        raise ValueError(f"Unsupported runner class: {agent_cfg.class_name}")
    runner.add_git_repo_to_log(__file__)
    if agent_cfg.resume or agent_cfg.algorithm.class_name == "Distillation":
        print(f"[INFO]: Loading model checkpoint from: {resume_path}")
        runner.load(resume_path)

    env_yaml = os.path.join(log_dir, "params", "env.yaml")
    try:
        dump_yaml(env_yaml, env_cfg)
    except Exception as exc:
        logger.warning("Skipping env.yaml dump (Pink/FrameTask fields are not YAML-serializable): %s", exc)
    dump_yaml(os.path.join(log_dir, "params", "agent.yaml"), agent_cfg)

    runner.learn(num_learning_iterations=agent_cfg.max_iterations, init_at_random_ep_len=True)

    print(f"Training time: {round(time.time() - start_time, 2)} seconds")

    env.close()


if __name__ == "__main__":
    main()
    simulation_app.close()
