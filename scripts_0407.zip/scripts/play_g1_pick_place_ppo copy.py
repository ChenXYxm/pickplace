# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Load an RSL-RL checkpoint and run inference (play) on CXY G1 Inspire HY pick/lift tasks.

Aligned with ``train_g1_pick_place_ppo.py`` (no Hydra; same env cfg construction + Pinocchio import order).

Use conda env ``env_isaaclab`` so ``./isaaclab.sh -p`` resolves Isaac Sim / Pinocchio (recommended)::

    ./cxy_project/scripts/run_play_g1_pick_place_ppo_env_isaaclab.sh \\
      --task CXY-G1-Inspire-Pick-Lift-PPO-HY-v0 \\
      --checkpoint /path/to/model.pt --num_envs 1

Or after ``conda activate env_isaaclab``, from the Isaac Lab repo root::

    ./isaaclab.sh -p cxy_project/scripts/play_g1_pick_place_ppo.py \\
      --task CXY-G1-Inspire-Pick-Lift-PPO-HY-v0 \\
      --load_run 2026-03-31_12-00-00 \\
      --checkpoint model_120.pt \\
      --num_envs 1

Record one video clip (under ``<run>/videos/play/``)::

    ./isaaclab.sh -p cxy_project/scripts/play_g1_pick_place_ppo.py \\
      --task CXY-G1-Inspire-Pick-Lift-PPO-HY-Nocontact-v0 \\
      --load_run <run_dir_name> \\
      --checkpoint model_120.pt \\
      --num_envs 1 --video --video_length 800 --video-closeup

Absolute path to a ``.pt`` file::

    ./isaaclab.sh -p cxy_project/scripts/play_g1_pick_place_ppo.py \\
      --task CXY-G1-Inspire-Pick-Lift-PPO-HY-v0 \\
      --checkpoint /abs/path/to/model_120.pt \\
      --num_envs 1
"""

from __future__ import annotations

import pinocchio  # load before Isaac Lab / Pink (Pinocchio 3 import order); keep first after __future__

import argparse
import os
import sys

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

import cxy_project.envs.g1_pick_place.task_registration  # noqa: F401

_RSL_RL_DIR = os.path.join(_REPO_ROOT, "scripts", "reinforcement_learning", "rsl_rl")
if _RSL_RL_DIR not in sys.path:
    sys.path.insert(0, _RSL_RL_DIR)

from isaaclab.app import AppLauncher

import cli_args  # isort: skip

parser = argparse.ArgumentParser(description="Play (inference) CXY G1 Inspire pick/lift PPO checkpoint.")
parser.add_argument("--video", action="store_true", default=False, help="Record a video clip under the checkpoint run.")
parser.add_argument(
    "--video_length",
    type=int,
    default=600,
    help="Env steps to record / play when --video is set (default: 600, longer clip).",
)
parser.add_argument(
    "--video-closeup",
    action="store_true",
    default=False,
    help="Use a close-up viewport: camera tracks right wrist (asset_body) with short eye/lookat offsets.",
)
parser.add_argument("--num_envs", type=int, default=1, help="Number of parallel environments.")
parser.add_argument(
    "--task",
    type=str,
    default="CXY-G1-Inspire-Pick-Lift-PPO-HY-v0",
    help="Gym task id (must match training).",
)
parser.add_argument("--seed", type=int, default=None, help="Seed for the environment.")
parser.add_argument(
    "--real-time",
    action="store_true",
    default=False,
    help="Sleep between steps to approximate real-time playback (single-env friendly).",
)
parser.add_argument(
    "--max-steps",
    type=int,
    default=0,
    help="Stop after this many env steps when not using --video (0 = run until the app closes).",
)
parser.add_argument(
    "--no-export",
    action="store_true",
    default=False,
    help="Skip exporting policy JIT/ONNX next to the checkpoint.",
)
parser.add_argument(
    "--cxy-net-use-full-force",
    action="store_true",
    default=False,
    help="HY task only: net contact fallback uses full ||F|| instead of horizontal ||(Fx,Fy)||.",
)
cli_args.add_rsl_rl_args(parser)
AppLauncher.add_app_launcher_args(parser)
args_cli = parser.parse_args()

if args_cli.video:
    args_cli.enable_cameras = True

app_launcher = AppLauncher(args_cli)
simulation_app = app_launcher.app

import importlib.metadata as metadata
import platform
import time

from packaging import version

RSL_RL_VERSION = "3.0.1"
installed_version = metadata.version("rsl-rl-lib")
if version.parse(installed_version) < version.parse(RSL_RL_VERSION):
    if platform.system() == "Windows":
        cmd = [r".\isaaclab.bat", "-p", "-m", "pip", "install", f"rsl-rl-lib=={RSL_RL_VERSION}"]
    else:
        cmd = ["./isaaclab.sh", "-p", "-m", "pip", "install", f"rsl-rl-lib=={RSL_RL_VERSION}"]
    print(
        f"Please install the correct version of RSL-RL.\nExisting version is: '{installed_version}'"
        f" and required version is: '{RSL_RL_VERSION}'.\nTo install the correct version, run:"
        f"\n\n\t{' '.join(cmd)}\n"
    )
    raise SystemExit(1)

import logging

import gymnasium as gym
import torch
import rsl_rl.runners.on_policy_runner as rsl_on_policy_runner
from rsl_rl.runners import DistillationRunner, OnPolicyRunner

from cxy_project.envs.g1_pick_place.agents.actor_critic_pointnet_obs import ActorCriticPointNetObsEncoder

rsl_on_policy_runner.ActorCriticPointNetObsEncoder = ActorCriticPointNetObsEncoder

from isaaclab.envs import DirectMARLEnv, multi_agent_to_single_agent
from isaaclab.envs.common import ViewerCfg
from isaaclab.utils.assets import retrieve_file_path
from isaaclab.utils.dict import print_dict

from isaaclab_rl.rsl_rl import RslRlVecEnvWrapper, export_policy_as_jit, export_policy_as_onnx

from isaaclab_tasks.utils import get_checkpoint_path

from cxy_project.envs.g1_pick_place.agents.rsl_rl_ppo_cfg import G1PickPPORunnerCfg
from cxy_project.envs.g1_pick_place.pickplace_g1_inspire_ppo_hy_env_cfg import (
    G1InspirePickPPOHyEnvCfg,
    G1InspirePickPPOHyNoContactEnvCfg,
)

HY_PPO_TASK_NOCONTACT = "CXY-G1-Inspire-Pick-Lift-PPO-HY-Nocontact-v0"

logger = logging.getLogger(__name__)


def _resolve_checkpoint_path(log_root_path: str, agent_cfg) -> str:
    """Resolve checkpoint: absolute file path, or ``get_checkpoint_path`` with load_run / regex."""
    ckpt = agent_cfg.load_checkpoint
    load_run = agent_cfg.load_run
    if ckpt:
        expanded = os.path.abspath(os.path.expanduser(ckpt))
        if os.path.isfile(expanded):
            return expanded
        try:
            return retrieve_file_path(ckpt)
        except (FileNotFoundError, OSError, RuntimeError):
            pass
    pattern = ckpt if ckpt else ".*"
    return get_checkpoint_path(log_root_path, load_run if load_run else ".*", pattern)


def main() -> None:
    if args_cli.task == HY_PPO_TASK_NOCONTACT:
        env_cfg = G1InspirePickPPOHyNoContactEnvCfg()
        logger.info("HY env: %s (no contact-force reward terms).", HY_PPO_TASK_NOCONTACT)
    else:
        env_cfg = G1InspirePickPPOHyEnvCfg()
        if args_cli.cxy_net_use_full_force:
            env_cfg.cxy_contact_net_use_horizontal = False

    agent_cfg = G1PickPPORunnerCfg()
    agent_cfg = cli_args.update_rsl_rl_cfg(agent_cfg, args_cli)
    agent_cfg.num_steps_per_env = 128

    env_cfg.scene.num_envs = args_cli.num_envs if args_cli.num_envs is not None else env_cfg.scene.num_envs
    env_cfg.seed = agent_cfg.seed
    env_cfg.sim.device = args_cli.device if args_cli.device is not None else env_cfg.sim.device

    log_root_path = os.path.abspath(os.path.join("logs", "rsl_rl", agent_cfg.experiment_name))
    print(f"[INFO] Experiment log root: {log_root_path}")

    resume_path = _resolve_checkpoint_path(log_root_path, agent_cfg)
    print(f"[INFO] Loading checkpoint: {resume_path}")

    log_dir = os.path.dirname(resume_path)
    env_cfg.log_dir = log_dir

    if args_cli.video and args_cli.video_closeup:
        # Camera eye/target are **offsets** added to the wrist body world position each render (see ViewportCameraController).
        env_cfg.viewer = ViewerCfg(
            origin_type="asset_body",
            asset_name="robot",
            body_name="right_wrist_yaw_link",
            env_index=0,
            eye=(0.52, -0.42, 0.32),
            lookat=(0.0, 0.18, -0.06),
            resolution=(1920, 1080),
        )
        logger.info("Viewer: close-up tracking right_wrist_yaw_link (1920x1080).")
    elif args_cli.video:
        # World-frame shot: x=-0.1 and pull back further along +y for a wider view of the workspace.
        env_cfg.viewer = ViewerCfg(
            eye=(-0.1, 2.5, 1.55),
            lookat=(-0.16, 0.36, 1.01),
            resolution=(1920, 1080),
        )
        logger.info("Viewer: world-frame wider shot at x=-0.1 with +y pullback (1920x1080).")

    env = gym.make(args_cli.task, cfg=env_cfg, render_mode="rgb_array" if args_cli.video else None)

    if isinstance(env.unwrapped, DirectMARLEnv):
        env = multi_agent_to_single_agent(env)

    if args_cli.video:
        video_kwargs = {
            "video_folder": os.path.join(log_dir, "videos", "play"),
            "step_trigger": lambda step: step == 0,
            "video_length": args_cli.video_length,
            "disable_logger": True,
        }
        print("[INFO] Recording video.")
        print_dict(video_kwargs, nesting=4)
        env = gym.wrappers.RecordVideo(env, **video_kwargs)

    env = RslRlVecEnvWrapper(env, clip_actions=agent_cfg.clip_actions)

    if agent_cfg.class_name == "OnPolicyRunner":
        runner = OnPolicyRunner(env, agent_cfg.to_dict(), log_dir=None, device=agent_cfg.device)
    elif agent_cfg.class_name == "DistillationRunner":
        runner = DistillationRunner(env, agent_cfg.to_dict(), log_dir=None, device=agent_cfg.device)
    else:
        raise ValueError(f"Unsupported runner class: {agent_cfg.class_name}")

    runner.load(resume_path)

    policy = runner.get_inference_policy(device=env.unwrapped.device)

    try:
        policy_nn = runner.alg.policy
    except AttributeError:
        policy_nn = runner.alg.actor_critic

    if hasattr(policy_nn, "actor_obs_normalizer"):
        normalizer = policy_nn.actor_obs_normalizer
    elif hasattr(policy_nn, "student_obs_normalizer"):
        normalizer = policy_nn.student_obs_normalizer
    else:
        normalizer = None

    if not args_cli.no_export:
        export_model_dir = os.path.join(os.path.dirname(resume_path), "exported")
        try:
            export_policy_as_jit(policy_nn, normalizer=normalizer, path=export_model_dir, filename="policy.pt")
            export_policy_as_onnx(policy_nn, normalizer=normalizer, path=export_model_dir, filename="policy.onnx")
            print(f"[INFO] Exported JIT/ONNX under: {export_model_dir}")
        except Exception as exc:
            logger.warning("Policy export skipped: %s", exc)

    dt = env.unwrapped.step_dt
    obs = env.get_observations()
    timestep = 0

    while simulation_app.is_running():
        start = time.time()
        with torch.inference_mode():
            actions = policy(obs)
            obs, _, dones, _ = env.step(actions)
            policy_nn.reset(dones)

        timestep += 1

        if args_cli.video and timestep >= args_cli.video_length:
            break
        if not args_cli.video and args_cli.max_steps > 0 and timestep >= args_cli.max_steps:
            break

        if args_cli.real_time and env_cfg.scene.num_envs == 1:
            sleep_time = dt - (time.time() - start)
            if sleep_time > 0:
                time.sleep(sleep_time)

    env.close()


if __name__ == "__main__":
    main()
    simulation_app.close()
