#!/usr/bin/env bash
# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# SPDX-License-Identifier: BSD-3-Clause
#
# Run ``play_g1_pick_place_ppo.py`` under conda env ``env_isaaclab`` so ``isaaclab.sh`` picks
# the Isaac Sim / Pinocchio Python (same idea as ``isaaclab.sh -c env_isaaclab``).
#
# Usage (from Isaac Lab repo root):
#   ./cxy_project/scripts/run_play_g1_pick_place_ppo_env_isaaclab.sh --num_envs 1 --checkpoint /path/to/model.pt

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
cd "${REPO_ROOT}"

CONDA_ENV_NAME="${CONDA_ENV_NAME:-env_isaaclab}"

if ! command -v conda >/dev/null 2>&1; then
    echo "[ERROR] conda is not on PATH. Initialize conda for your shell, then retry."
    exit 1
fi

eval "$(conda shell.bash hook)"
conda activate "${CONDA_ENV_NAME}"

# ``isaaclab.sh`` runs ``tabs 4``; dumb TERM (e.g. CI) fails unless we override.
if [[ -z "${TERM:-}" ]] || [[ "${TERM}" == "dumb" ]]; then
    export TERM=xterm
else
    export TERM="${TERM}"
fi

exec ./isaaclab.sh -p cxy_project/scripts/play_g1_pick_place_ppo.py "$@"
