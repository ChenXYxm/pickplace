# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Extract 256-D PointNet++ MSG features for HY USD assets under ``cxy_project/objects/hy_objects``.

This mirrors ``extract_ycb_pointnet2_features.py`` but loads geometry from **USD crate** files
(``UsdGeom.Mesh`` prims) instead of OBJ meshes.

We sample 1024 points + face normals, apply a fixed per-axis scale (default: 0.125, 0.125, 0.125)
in *geometry space*, apply the same ``pc_normalize`` on XYZ as ModelNet, and save the penultimate
PointNet2 embedding (256-D, after fc2+bn2+relu).

Default output:
  ``cxy_project/objects/hy_objects/hy_object_pointnet2_msg_normals_256.npz``
containing arrays:
  - ``names``: object names (dtype=object)
  - ``features``: float32 (K, 256)

Example (from Isaac Lab repo root)::

    ./isaaclab.sh -p cxy_project/scripts/extract_hy_usd_pointnet2_features.py \\
        --checkpoint pointnet2/Pointnet_Pointnet2_pytorch/log/classification/pointnet2_msg_normals/checkpoints/best_model.pth
"""

from __future__ import annotations

import argparse
import importlib
import json
import os
import sys
import warnings
from isaaclab.app import AppLauncher
app_launcher = AppLauncher()

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
_POINTNET2_MODELS = os.path.join(_REPO_ROOT, "pointnet2", "Pointnet_Pointnet2_pytorch", "models")
_DEFAULT_CHECKPOINT = os.path.join(
    _REPO_ROOT,
    "pointnet2",
    "Pointnet_Pointnet2_pytorch",
    "log",
    "classification",
    "pointnet2_msg_normals",
    "checkpoints",
    "best_model.pth",
)
_DEFAULT_OUTPUT = os.path.join(
    _REPO_ROOT, "cxy_project", "objects", "hy_objects", "hy_object_pointnet2_msg_normals_256.npz"
)

_DEFAULT_USD_REL_PATHS: tuple[str, ...] = (
    "cxy_project/objects/hy_objects/hy_cleaner_bottle/qsim_hy_cleaner_bottle.usd",
    "cxy_project/objects/hy_objects/hy_spray_bottle/qsim_hy_spray_bottle.usd",
    "cxy_project/objects/hy_objects/hy_whiteboard_cleaner/qsim_hy_whiteboard_cleaner.usd",
    "cxy_project/objects/hy_objects/hy_lotion_bottle/qsim_hy_lotion_bottle.usd",
    "cxy_project/objects/hy_objects/hy_lotion/qsim_hy_lotion_1.usd",
)

if _POINTNET2_MODELS not in sys.path:
    sys.path.insert(0, _POINTNET2_MODELS)


def pc_normalize(pc: "np.ndarray") -> "np.ndarray":
    """Same as ModelNetDataLoader.pc_normalize: centroid + unit ball scale.

    Returns:
        A tuple (pc_norm, m) where pc_norm is normalized point cloud and m is the scalar scale factor used:
        pc_norm = (pc - centroid) / m
    """
    import numpy as np

    centroid = np.mean(pc, axis=0)
    pc = pc - centroid
    m = np.max(np.sqrt(np.sum(pc**2, axis=1)))
    if m < 1e-8:
        m = 1.0
    pc = pc / m
    return pc, float(m)


def _triangulate_face_indices(face_counts: "np.ndarray", face_indices: "np.ndarray") -> "np.ndarray":
    """Fan triangulate polygon faces into (T, 3) triangle indices."""
    import numpy as np

    tris: list[list[int]] = []
    idx = 0
    for c in face_counts.tolist():
        c = int(c)
        if c < 3:
            idx += c
            continue
        v0 = int(face_indices[idx])
        for j in range(1, c - 1):
            tris.append([v0, int(face_indices[idx + j]), int(face_indices[idx + j + 1])])
        idx += c
    if not tris:
        return np.zeros((0, 3), dtype=np.int64)
    return np.asarray(tris, dtype=np.int64)


def usd_to_trimesh(usd_path: str) -> "trimesh.Trimesh":
    """Load all ``UsdGeom.Mesh`` prims in a USD file and merge into one triangle mesh in world space."""
    import numpy as np
    import trimesh
    from pxr import Usd, UsdGeom, Gf

    stage = Usd.Stage.Open(usd_path)
    if stage is None:
        raise FileNotFoundError(f"Unable to open USD stage: {usd_path}")

    xcache = UsdGeom.XformCache()

    all_vertices: list[np.ndarray] = []
    all_faces: list[np.ndarray] = []
    v_offset = 0

    for prim in stage.Traverse():
        if not prim.IsA(UsdGeom.Mesh):
            continue
        mesh = UsdGeom.Mesh(prim)

        pts = mesh.GetPointsAttr().Get()
        if pts is None or len(pts) == 0:
            continue

        face_counts = mesh.GetFaceVertexCountsAttr().Get()
        face_indices = mesh.GetFaceVertexIndicesAttr().Get()
        if face_counts is None or face_indices is None:
            continue

        pts_np = np.asarray([tuple(p) for p in pts], dtype=np.float64)
        counts_np = np.asarray(face_counts, dtype=np.int64)
        indices_np = np.asarray(face_indices, dtype=np.int64)

        # Apply local-to-world xform to points so nested prim transforms are respected.
        xf: Gf.Matrix4d = xcache.GetLocalToWorldTransform(prim)
        mat = np.asarray([[xf[i][j] for j in range(4)] for i in range(4)], dtype=np.float64)
        homog = np.concatenate([pts_np, np.ones((pts_np.shape[0], 1), dtype=np.float64)], axis=1)
        pts_np = (homog @ mat.T)[:, 0:3]

        # Ensure triangles.
        if counts_np.size > 0 and int(counts_np.max()) == 3 and int(counts_np.min()) == 3:
            faces = indices_np.reshape(-1, 3).astype(np.int64, copy=False)
        else:
            faces = _triangulate_face_indices(counts_np, indices_np)
        if faces.shape[0] == 0:
            continue

        all_vertices.append(pts_np)
        all_faces.append(faces + v_offset)
        v_offset += pts_np.shape[0]

    if not all_vertices:
        raise RuntimeError(f"No UsdGeom.Mesh with points found in: {usd_path}")

    vertices = np.concatenate(all_vertices, axis=0)
    faces = np.concatenate(all_faces, axis=0)
    mesh = trimesh.Trimesh(vertices=vertices, faces=faces, process=False)
    if mesh.faces.shape[0] == 0:
        raise RuntimeError(f"USD produced empty triangle mesh: {usd_path}")
    return mesh


def usd_to_pointcloud_xyz_normals(
    usd_path: str,
    num_points: int,
    seed: int | None,
    scale_xyz: tuple[float, float, float] = (0.125, 0.125, 0.125),
) -> tuple["np.ndarray", "np.ndarray", "np.ndarray"]:
    """Sample surface points + normals from USD mesh, apply scale, then ModelNet-style normalization on XYZ."""
    import numpy as np

    if seed is not None:
        np.random.seed(seed)

    mesh = usd_to_trimesh(usd_path)
    if scale_xyz is not None:
        mesh = mesh.copy()
        mesh.apply_scale(np.asarray(scale_xyz, dtype=np.float64))

    points, face_idx = mesh.sample(num_points, return_index=True)
    xyz = np.asarray(points, dtype=np.float32)
    xyz_before_normalize = xyz.copy()
    normals = np.asarray(mesh.face_normals[face_idx], dtype=np.float32)
    nrm = np.linalg.norm(normals, axis=1, keepdims=True)
    nrm = np.where(nrm > 1e-8, nrm, 1.0)
    normals = normals / nrm

    pc6 = np.concatenate([xyz, normals], axis=1)
    xyz_norm, m = pc_normalize(pc6[:, 0:3].astype(np.float64))
    pc6[:, 0:3] = xyz_norm.astype(np.float32)
    # return m as float32 array for easy stacking
    return pc6, xyz_before_normalize, np.asarray(m, dtype=np.float32)


def extract_feature_256(model: "torch.nn.Module", points_b6n: "torch.Tensor") -> "torch.Tensor":
    """Penultimate 256-D vector (post fc2, bn2, relu, dropout in eval). Input: [B, 6, N]."""
    import torch
    import torch.nn.functional as F

    model.eval()
    xyz = points_b6n
    B, _, _ = xyz.shape
    if model.normal_channel:
        norm = xyz[:, 3:, :]
        xyz_only = xyz[:, :3, :]
    else:
        norm = None
        xyz_only = xyz

    with torch.no_grad():
        l1_xyz, l1_points = model.sa1(xyz_only, norm)
        l2_xyz, l2_points = model.sa2(l1_xyz, l1_points)
        _l3_xyz, l3_points = model.sa3(l2_xyz, l2_points)
        x = l3_points.view(B, 1024)
        x = model.drop1(F.relu(model.bn1(model.fc1(x))))
        x = model.drop2(F.relu(model.bn2(model.fc2(x))))
    return x


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Extract 256-D PointNet2 MSG features for HY USD objects.")
    p.add_argument(
        "--checkpoint",
        type=str,
        default=_DEFAULT_CHECKPOINT,
        help="Path to best_model.pth (expects key 'model_state_dict').",
    )
    p.add_argument("--output", type=str, default=_DEFAULT_OUTPUT, help="Output .npz path.")
    p.add_argument("--device", type=str, default="cuda", help="cuda | cpu | cuda:0, ...")
    p.add_argument("--seed", type=int, default=0, help="NumPy seed for surface sampling (per-run reproducibility).")
    p.add_argument("--num-points", type=int, default=1024, help="Must match training (1024).")
    p.add_argument(
        "--scale",
        type=float,
        nargs=3,
        default=(0.125, 0.125, 0.125),
        help="Per-axis geometry scale applied before sampling: sx sy sz.",
    )
    p.add_argument(
        "--usd-scale",
        type=float,
        nargs=3,
        action="append",
        default=None,
        help=(
            "Optional per-USD override for --scale (repeatable, must match number/order of --usd). "
            "Example: --usd a.usd --usd b.usd --usd-scale 0.125 0.125 0.125 --usd-scale 0.14 0.14 0.14"
        ),
    )
    p.add_argument(
        "--usd",
        action="append",
        default=None,
        help="USD path to process (repeatable). If omitted, uses the 3 default HY USD paths.",
    )
    return p.parse_args()


def main() -> None:
    args = parse_args()

    import numpy as np
    import torch

    if not os.path.isfile(args.checkpoint):
        raise FileNotFoundError(
            f"Checkpoint not found: {args.checkpoint}\n"
            "Copy best_model.pth from your PointNet2 training run into that path, or pass --checkpoint."
        )

    usd_paths = args.usd if args.usd is not None else [os.path.join(_REPO_ROOT, p) for p in _DEFAULT_USD_REL_PATHS]
    usd_paths = [p if os.path.isabs(p) else os.path.abspath(os.path.join(_REPO_ROOT, p)) for p in usd_paths]
    for p in usd_paths:
        if not os.path.isfile(p):
            raise FileNotFoundError(f"USD not found: {p}")

    if str(args.device).startswith("cuda") and not torch.cuda.is_available():
        warnings.warn("CUDA requested but not available; using CPU.", stacklevel=1)
        device = torch.device("cpu")
    else:
        device = torch.device(args.device)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=FutureWarning)
        ckpt = torch.load(args.checkpoint, map_location=device, weights_only=False)

    if "model_state_dict" not in ckpt:
        raise KeyError(f"Checkpoint missing 'model_state_dict' keys: {list(ckpt.keys())}")

    pointnet2_cls_msg = importlib.import_module("pointnet2_cls_msg")
    model = pointnet2_cls_msg.get_model(40, normal_channel=True)
    model.load_state_dict(ckpt["model_state_dict"], strict=True)
    model = model.to(device)

    names_list: list[str] = []
    feats_list: list[np.ndarray] = []
    m_list: list[np.ndarray] = []

    default_scale_xyz = tuple(float(x) for x in args.scale)
    if args.usd_scale is not None:
        if len(args.usd_scale) != len(usd_paths):
            raise ValueError(
                f"--usd-scale must be repeated exactly len(--usd) times. Got {len(args.usd_scale)} scales for "
                f"{len(usd_paths)} usd paths."
            )
        per_usd_scales = [tuple(float(x) for x in s) for s in args.usd_scale]
    else:
        per_usd_scales = [default_scale_xyz for _ in usd_paths]

    scales_list: list[tuple[float, float, float]] = []
    for usd_path, scale_xyz in zip(usd_paths, per_usd_scales):
        name = os.path.basename(os.path.dirname(usd_path))
        pc6, _xyz_raw, pc_normalize_m = usd_to_pointcloud_xyz_normals(
            usd_path, args.num_points, args.seed, scale_xyz=scale_xyz
        )
        pts = torch.from_numpy(pc6).float().to(device).transpose(1, 0).unsqueeze(0)
        feat = extract_feature_256(model, pts).squeeze(0).detach().cpu().numpy().astype(np.float32)

        if feat.shape != (256,):
            raise RuntimeError(f"Expected feature shape (256,), got {feat.shape} for {usd_path}")

        names_list.append(name)
        feats_list.append(feat)
        m_list.append(pc_normalize_m)
        scales_list.append(scale_xyz)

    features = np.stack(feats_list, axis=0)
    names_arr = np.array(names_list, dtype=object)
    pc_normalize_m_arr = np.stack(m_list, axis=0).astype(np.float32, copy=False).reshape(-1)
    # Store a scaled version for downstream compatibility (requested): m_saved = 10 * m
    pc_normalize_m_arr = pc_normalize_m_arr * np.float32(10.0)

    out_dir = os.path.dirname(os.path.abspath(args.output))
    if out_dir and not os.path.exists(out_dir):
        os.makedirs(out_dir, exist_ok=True)

    np.savez_compressed(args.output, names=names_arr, features=features, pc_normalize_m=pc_normalize_m_arr)

    meta_path = os.path.splitext(args.output)[0] + "_meta.json"
    meta = {
        "checkpoint_path": os.path.abspath(args.checkpoint),
        "output_npz": os.path.abspath(args.output),
        "usd_paths": [os.path.abspath(p) for p in usd_paths],
        "num_points": int(args.num_points),
        "normal_channel": True,
        "scale_xyz_default": [float(x) for x in default_scale_xyz],
        "scale_xyz_per_object": [[float(x) for x in s] for s in scales_list],
        "model": "pointnet2_cls_msg",
        "num_class": 40,
        "feature_dim": 256,
        "object_count": int(features.shape[0]),
        "feature_dtype": "float32",
        "pc_normalize_m": {
            "description": (
                "Saved value is 10*m where m is ModelNet-style pc_normalize scale factor in "
                "pc_norm=(pc-centroid)/m (XYZ only)."
            ),
            "shape": [int(pc_normalize_m_arr.shape[0])],
            "dtype": "float32",
        },
    }
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)

    print(f"[INFO] Wrote {args.output}  features={features.shape}  meta={meta_path}")


if __name__ == "__main__":
    if _REPO_ROOT not in sys.path:
        sys.path.insert(0, _REPO_ROOT)
    main()

